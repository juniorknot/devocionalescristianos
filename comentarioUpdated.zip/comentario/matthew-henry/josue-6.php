<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Josué 6</h2>
<p class="text-justify">Vv. 1-5.Jericó resuelve que Israel no será su amo. Se encerró poderosamente fortificada por la técnica y la naturaleza. Así de necios eran y endurecieron el corazón para destrucción de ellos; es el caso miserable de todos los que se hacen los fuertes contra el Todopoderoso. Dios resuelve que Israel sea el amo y pronto. No había que hacer preparativos bélicos. Por el método nada corriente de dar vueltas alrededor de la ciudad, el Señor honró el arca como símbolo de su presencia, y demostró que todas las victorias eran suyas. La fe y la paciencia del pueblo fueron probadas y aumentadas.</p>
<br/>
<p class="text-justify">Vv. 6-16.Doquiera fuera el arca el pueblo la atendía. Los ministros de Dios, por la trompeta del evangelio eterno, que proclama libertad y victoria, deben exhortar a los seguidores de Cristo en su guerra espiritual. Como debe esperarse las prometidas liberaciones a la manera de Dios, así debe esperársela en su tiempo. Por último, el pueblo debía gritar: lo hicieron y se derrumbaron los muros. Este fue un grito de fe; ellos creían que los muros de Jericó caerían. Fue un grito de oración; clamaron al Cielo por ayuda y llegó el socorro.</p>
<br/>
<p class="text-justify">Vv. 17-27.Jericó iba a ser un sacrificio solemne y espantoso a la justicia de Dios, sobre aquellos que habían colmado la medida de sus pecados. De esa manera Él señala de quien, como criaturas, recibieron la vida y, a quien, como pecadores, habían abandonado. Rahab no pereció con los que no creyeron, Hebreos xi, 31. Toda su familia fue salvada con ella; así, la fe en Cristo trae salvación a la casa, Hechos xvi, 31. Ella, y ellos con ella, fueron sacados como tizones de la hoguera.
Con Rahab, o con los hombres de Jericó, debe ser nuestra porción, si recibimos o desechamos la señal de salvación: la fe en Cristo, que obra por amor. Recordemos lo que depende de nuestra elección y escojamos en forma adecuada. Dios muestra el peso de una maldición divina; donde esta reposa, no hay forma de escapar de ella porque trae ruina irremediable.</p>
<br/>




</div>
