<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Miqueas 2</h2>
<p class="text-justify">Vv. 1-5.¡Ay del pueblo que maquina el mal durante la noche y se levanta temprano para ejecutarlo! Malo es hacer el mal por un impulso súbito, mucho peor es hacerlo con premeditación y alevosía. Gran momento es aprovechar y usar las horas de retiro y soledad en forma apropiada. Si la codicia reina en el corazón, desaparece la compasión; y cuando el corazón está así comprometido, corrientemente la violencia y el fraude ocupan las manos.
El más altivo y seguro de su prosperidad suele ser el que está más listo para desesperarse en la adversidad. ¡Ay de los que Dios abandona! -Las calamidades más dolorosas son las que nos sacan de la congregación del Señor o nos apartan del deleite de sus privilegios.</p>
<br/>
<p class="text-justify">Vv. 6-11.Puesto que dicen, “no profeticéis”. Dios les cobrará la palabra y su pecado será su castigo. Que el médico no atienda más al paciente que no será sanado. Enemigos no sólo de Dios sino de su país, son los que silencian a los buenos ministros y detienen los medios de gracia. ¿Qué lazos retendrán a los que no tienen reverencia por la palabra de Dios? Los pecadores no pueden esperar el reposo en una tierra que han contaminado. No sólo serás obligado a irte de esta tierra, sino que ella te destruirá. Aplíquese esto a nuestro estado en este mundo presente. Hay corrupción en el mundo por la lujuria, y debemos mantenernos alejados de ella. No es nuestro reposo: fue designado para nuestro peregrinar, pero no como porción nuestra; nuestra posada, pero no nuestra casa; aquí no tenemos ciudad permanente; por tanto, levantémonos y partamos, busquemos la ciudad permanente de lo alto.
Puesto que quieren ser engañados, sean engañados. Los maestros que recomiendan la auto indulgencia por medio de su doctrina y ejemplo, son los que convienen a tales pecadores.</p>
<br/>
<p class="text-justify">Vv. 12, 13.Estos versículos pueden referirse al cautiverio de Israel y Judá. Pero el pasaje también es una profecía de la conversión a Cristo de los judíos. El Señor no sólo los sacaría del cautiverio y los multiplicaría, sino que el Señor Jesús les abriría el camino hacia Dios, tomando la naturaleza de hombre, y por la obra de su Espíritu en sus corazones, rompiendo las cadenas de Satanás. De esta manera, Él ha ido adelante y la gente sigue, irrumpiendo con su poder por entre los enemigos que detendrían el camino de ellos al cielo.</p>
<br/>




</div>
