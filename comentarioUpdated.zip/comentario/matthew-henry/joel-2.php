<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Joel 2</h2>
<p class="text-justify">Vv. 1-14.Los sacerdotes tenían que alarmar a la gente con la cercana llegada de los juicios divinos. Obra de los ministros es advertir de las consecuencias fatales del pecado y revelar la ira del cielo contra la impiedad e injusticia de los hombres.
La descripción impactante que sigue muestra lo que acompañará a las devastaciones causadas por las langostas, pero también puede describir los efectos de la desolación de la tierra a manos de los caldeos. Si se advierte de los juicios temporales con voz de alarma a las naciones ofensoras, ¡cuánto más se debe advertir a los pecadores que busquen liberación de la ira venidera! Por tanto, nuestro negocio en la tierra debe ser especialmente asegurar un interés en nuestro Señor Jesucristo; y procuraremos ser separados de los objetos que pronto serán arrancados de todos los que ahora hacen ídolos de ellos.
Debe haber expresiones externas de dolor y vergüenza, ayuno, llanto y duelo; las lágrimas por el trastorno deben volverse lágrimas por el pecado que lo causó. Pero romperse las vestiduras será en vano, salvo que los corazones hayan sido desgarrados por la humillación y el aborrecimiento de sí mismos; por la pena por sus pecados y la separación de ellos. Incuestionable es que si nos arrepentimos verdaderamente de nuestros pecados, Dios los perdonará; no se promete que deba quitar la aflicción, pero esa probabilidad debe exhortarnos al arrepentimiento.</p>
<br/>
<p class="text-justify">Vv. 15-27.Los sacerdotes y los reyes tienen que convocar un ayuno solemne.
La súplica del pecador es: Sálvanos, buen Señor.
Dios está listo para socorrer a su pueblo; y espera para ser bondadoso. Ellos oraron que Dios los salvase y Él les contestó. Sus promesas son respuestas reales a las oraciones de fe; decir y hacer no son dos cosas diferentes para Dios. Algunos entienden estas promesas en forma figurada, como que señalan la gracia del evangelio, y cumplidas en los consuelos abundantes atesorados para los creyentes en el pacto de gracia.</p>
<br/>
<p class="text-justify">Vv. 28-32.La promesa empezó a ser cumplida el día de Pentecostés, cuando fue derramado el Espíritu Santo, y continuó en la gracia que convierte y los dones milagrosos conferidos a judíos y gentiles.
Los juicios de Dios para el mundo pecador solo preceden al juicio del mundo en el día final. Clamar a Dios supone conocimiento de Él, fe en Él, deseo de Él, dependencia de Él, y como prueba de la sinceridad de todo esto, obediencia consciente a Él. Sólo serán librados en el gran día, quienes ahora reciben el llamamiento eficaz para apartarse del pecado a Dios, desde el yo a Cristo, desde las cosas de abajo a las cosas de arriba.</p>
<br/>




</div>
