<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 20</h2>
<p class="text-justify">Vv. 1-8.Las políticas torcidas no prosperarán: nos ponen en peligro a nosotros y a los demás. Dios da aviso a Abimelec de su peligro de pecar, y del peligro de muerte por su pecado. Todo pecador voluntario es un hombre muerto, pero Abimelec alega ignorancia. Si nuestra conciencia atestigua que, por haber sido de alguna manera engañados con una trampa, no hemos pecado a sabiendas contra Dios, será nuestro regocijo en el día malo. Es consolador para quienes son honestos que Dios conozca su honestidad y la reconozca. Es gran misericordia que se nos impida cometer pecado; Dios debe llevar la gloria en esto. Pero si hemos hecho mal por ignorancia, eso no nos excusará si persistimos en ello a sabiendas. El que hace mal, sea quien fuere, príncipe o campesino, ciertamente recibirá su paga por el mal que ha hecho, a menos que se arrepienta y, en lo posible, haga restitución.</p>
<br/>
<p class="text-justify">Vv. 9-13.Véase en esto mucha culpa, aun en el padre de los fieles. Note su desconfianza de Dios, el indebido temor por su vida, su intento de engañar. Él también puso tentación en el camino de los demás, causándoles aflicción, exponiéndose él mismo y a Sara a las justas reprimendas, y sin embargo, intentó excusarse. Estas cosas quedaron escritas para nuestra advertencia, no para que las imitemos. Hasta Abraham no tiene de qué gloriarse. Él no puede justificarse por sus obras, sino que debe estar agradecido por la justificación, a esa justicia que está sobre todos y que es para todos los que creen. No debemos condenar por hipócritas a todos los que caen en pecado si no continúan en él. Deje que el impenitente orgulloso se dé cuenta que no debe seguir pecando, si piensa que la gracia puede abundar.
Abimelec, advertido por Dios, acepta la advertencia; y estando verdaderamente asustado del pecado y sus consecuencias, se levanta pronto para seguir las órdenes de Dios.</p>
<br/>
<p class="text-justify">Vv. 14-18.A menudo nos perturbamos y hasta somos llevados a la tentación y el pecado por sospechas sin fundamento; y encontramos el temor de Dios donde no lo esperábamos. Los acuerdos para engañar suelen terminar generalmente en vergüenza y pena; y las restricciones del pecado, aunque sea por el sufrimiento, deben ser reconocidas con gratitud. Aunque el Señor reprende, no obstante, Él perdonará y librará a su pueblo, y les dará gracia ante los ojos de aquellos con quienes ellos están; y vencerá sus enfermedades cuando sean humillados por ellas, de modo que resulten útiles para sí mismos y para los demás.</p>
<br/>




</div>
