<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Proverbios 18</h2>
<p class="text-justify">V. 1.Si queremos obtener conocimiento y gracia, debemos probar todos los métodos para mejorar nosotros mismos.</p>
<br/>
<p class="text-justify">V. 2.Quienes tienen como único propósito hacer algo para ser vistos, nada útil hacen para el conocimiento o la religión.</p>
<br/>
<p class="text-justify">V. 3.Tan pronto como entró el pecado, siguió la vergüenza.</p>
<br/>
<p class="text-justify">V. 4.El manantial de la sabiduría del corazón del creyente provee palabras de sabiduría en forma continua.</p>
<br/>
<p class="text-justify">V. 5.Se debe considerar los méritos de una causa, no la persona.</p>
<br/>
<p class="text-justify">Vv. 6, 7.¡Cuánto mal se hacen los hombres malos por sus lenguas descontroladas!</p>
<br/>
<p class="text-justify">V. 8.¡Cuán bajos son los que siembran controversia, y qué fatales efectos pueden esperarse del pequeño comienzo de los celos!</p>
<br/>
<p class="text-justify">V. 9.Las omisiones del deber y en el deber son fatales para el alma, al igual que cometer pecado.</p>
<br/>
<p class="text-justify">Vv. 10, 11.El poder divino dado a conocer en nuestro Señor Jesucristo y por medio de Él, forma una torre fuerte para el creyente que confía en el Señor. ¡Cuán engañosa es la defensa del rico que tiene su porción y tesoro en este mundo! Ciudad fortificada y muro alto es en su propia presunción, porque caerá cuando más lo necesite. Ellos quedarán expuestos a la ira justa de aquel Juez al cual despreciaron como Salvador.</p>
<br/>
<p class="text-justify">V. 12.Después que el corazón se ha elevado con el orgullo, viene una caída. Pero la honra será la recompensa de la humildad.</p>
<br/>
<p class="text-justify">V. 13.La ansiedad junto con el engaño de sí mismo, expone a la vergüenza.</p>
<br/>
<p class="text-justify">V. 14.La firmeza de mente sustenta bajo muchos dolores y pruebas, pero cuando a la conciencia la tortura el remordimiento, ninguna fortaleza humana puede tolerar la desgracia; entonces, ¿cómo será el infierno?</p>
<br/>
<p class="text-justify">V. 15.Debemos obtener conocimiento no sólo para nuestra cabeza, sino para nuestro corazón.</p>
<br/>
<p class="text-justify">V. 16.Bendito sea el Señor que nos recibe bien ante su trono, sin dinero y sin precio. Que sus dones le hagan lugar en nuestra alma.</p>
<br/>
<p class="text-justify">V. 17.Bueno es escuchar a nuestros enemigos para formarnos un mejor juicio de nosotros mismos.</p>
<br/>
<p class="text-justify">V. 18.Era costumbre, a veces, referir a Dios las cosas echando suertes, con oración solemne. Profanar la suerte usándola como cuestión de diversión, o para codiciar lo que pertenece a otros, ahora es motivo de objeción.</p>
<br/>
<p class="text-justify">V. 19.Debe ponerse mucho cuidado para evitar peleas entre los parientes y entre quienes están obligados entre sí. La sabiduría y la gracia hacen que sea fácil perdonar, pero la corrupción lo hace difícil.</p>
<br/>
<p class="text-justify">V. 20.Aquí el estómago es puesto en lugar del corazón, como en todas partes; y lo que lo llena concordará con nuestra satisfacción y nuestra paz interior.</p>
<br/>
<p class="text-justify">V. 21.Más de uno ha causado su propia muerte o la muerte del prójimo por una lengua falsa o injuriosa.</p>
<br/>
<p class="text-justify">V. 22.Una buena esposa es una gran bendición para el hombre y es señal del favor divino.</p>
<br/>
<p class="text-justify">V. 23.La pobreza dice a los hombres que no deben ordenar ni demandar. Ante el trono de la gracia todos somos pobres y debemos hacer peticiones fervientes.</p>
<br/>
<p class="text-justify">V. 24.Cristo Jesús nunca abandonará a los que confían en Él y le aman. Que así seamos amigos con otros, por amor a nuestro Señor. Habiendo amado a los suyos que estaban en el mundo, los amó hasta lo sumo; y nosotros somos sus amigos si hacemos todo lo que Él nos manda, Juan xv, 14.</p>
<br/>




</div>
