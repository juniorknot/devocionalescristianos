<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 19</h2>
<p class="text-justify">Vv. 1-29.Lot era bueno pero no había nadie más del mismo carácter en la ciudad. Toda la gente de Sodoma era muy mala y vil. Por tanto, se tomó el cuidado de salvar a Lot y su familia.
Lot se demoró, actuó frívolamente. Así pues, muchos que están convictos de su estado espiritual y de la necesidad de un cambio, difieren esa obra necesaria. La salvación de los hombres más justos es de la misericordia de Dios, no por sus propios méritos. Somos salvados por gracia. El poder de Dios debe también reconocerse al sacar almas de un estado de pecado. Si Dios no hubiera sido misericordioso con nosotros, nuestra demora hubiera sido nuestra ruina.
Lot debe correr por su vida. Él no debe anhelar Sodoma. Se dan órdenes como estas a quienes, por medio de la gracia, son librados de un estado y condición de pecado. No volváis al pecado ni a Satanás. No descanséis en el yo ni en el mundo. Acudid a Cristo y al cielo, pues eso es escapar a la montaña, no debiendo deteneros antes de llegar. En cuanto a esta destrucción, obsérvese que es una revelación de la ira de Dios contra el pecado y los pecadores de todas las edades. Aprendamos de aquí lo malo de pecar y su naturaleza dañina; conduce a la ruina.</p>
<br/>
<p class="text-justify">Vv. 30-38.Véase el peligro de la seguridad. Lot, que se mantuvo casto en Sodoma, que se lamentaba de la maldad del lugar, y era un testigo contra ella, cuando está solo en la montaña y, según creía, fuera de la tentación, es vencido vergonzosamente. Aquel que piensa que está alto y firme, cuídese que no caiga. Véase el peligro de la embriaguez; no solamente es un gran pecado en sí misma, sino que lleva a muchos pecados, los cuales producen heridas y deshonra perdurables. Muchos hombres cuando están ebrios hacen aquello que, cuando están sobrios, no podrían pensar sin horrorizarse.
También véase el peligro de la tentación, aun de parte de parientes y amistades, a quienes amamos y estimamos, y esperamos bondad de parte de ellos. Debemos temer una trampa, donde estemos y siempre estar en guardia. No puede haber excusas para las hijas ni para Lot. Difícilmente puede darse razón del asunto, salvo esta: el corazón es engañoso más que todas las cosas y perverso: ¿quién lo conoce? Por el silencio de las Escrituras sobre Lot de ahí en adelante, apréndase que la ebriedad, así como hacer olvidadizos a los hombres, también hace que sean olvidados.</p>
<br/>




</div>
