<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Corintios 2</h2>
<p class="text-justify">Vv. 1-4.El apóstol deseaba tener una alegre reunión con ellos, y les había escrito confiando que ellos hicieran lo que fuera para su beneficio y consuelo y que, por tanto, ellos se alegrarían al eliminar toda causa de inquietud para él. Siempre causaremos dolor sin quererlo, aun cuando así lo requiera el deber.</p>
<br/>
<p class="text-justify">Vv. 5-11.El apóstol deseaba que ellos recibieran nuevamente en su comunión a la persona que había hecho mal, porque tenía conciencia de su falta y estaba muy afligido por el castigo. Hasta la tristeza por el pecado no debe impedir otros deberes ni llevar a la desesperación. No sólo había peligro que Satanás sacara ventaja tentando al penitente a pensar mal de Dios y de la religión, y así llevarlo a la desesperación, y pensara contra las iglesias y los ministros de Cristo, dando una mala imagen de los cristianos por no perdonar. De este modo causaría divisiones e impediría el éxito del ministerio. En esto, como en otras cosas, la sabiduría debe usarse para que el ministerio no sea culpado por permitir, por un lado el pecado, y por el otro, por exagerada severidad contra los pecadores. Satanás tiene muchos planes para engañar y sabe usar para mal nuestros errores.</p>
<br/>
<p class="text-justify">Vv. 12-17.Los triunfos del creyente son todos en Cristo. A Él sea la alabanza y la gloria de todos mientras el éxito del evangelio es una buena razón para el gozo y júbilo del cristiano. En los triunfos antiguos se usaban mucho perfume y olores gratos; De esta manera, el nombre y la salvación de Jesús, como ungüento derramado, era un olor grato, difundido en todo lugar. Para algunos el evangelio es olor de muerte para muerte. Ellos lo rechazan para su ruina. Para otros, el evangelio es un olor de vida para vida: como los vivificó al principio, cuando estaban muertos en delitos y pecados, así les da más vida, y los lleva a la vida eterna.
Obsérvese las impresiones sobrecogedoras que este asunto hizo en el apóstol y que debiera también hacer en nosotros. La obra es grande, y no tenemos fuerza de nosotros mismos en absoluto; toda nuestra suficiencia viene de Dios. Pero lo que hacemos en religión, a menos que sea hecho con sinceridad, como ante Dios, no es de Dios, no viene de Él y no llegará a Él. Velemos cuidadosamente en este aspecto; y busquemos el testimonio de nuestra conciencia, sometidos a la enseñanza del Espíritu Santo, para que con sinceridad hablemos así en Cristo y de Cristo.</p>
<br/>




</div>
