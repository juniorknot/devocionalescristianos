<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Apocalipsis 10</h2>
<p class="text-justify">Vv. 1-7.El apóstol vio otra visión. La persona que comunica este descubrimiento probablemente era nuestro Señor y Salvador Jesucristo, o era para mostrar su gloria. Él vela su gloria, que es demasiado grande para que la contemplen los ojos morales; y pone un velo sobre sus dispensaciones. Un arco iris estaba sobre su cabeza; nuestro Señor siempre se interesa por su pacto. Su voz sobrecogedora tuvo el eco de siete truenos; forma solemne y terrible de revelar la mente de Dios. No sabemos los temas de los siete truenos ni las razones para no escribirlas. Hay grandes acontecimientos en la historia, relacionados quizás con la iglesia cristiana, que no se notan en la profecía revelada. La salvación final del justo, y el éxito final de la verdadera religión de la tierra, son presentados por la palabra del Señor que no falla. Aunque todavía no sea el tiempo, no puede estar lejos. Muy pronto, para nosotros, el tiempo no será más, pero si somos creyentes, seguirá una eternidad dichosa; desde el cielo, contemplaremos los triunfos de Cristo, y de su causa en la tierra, y nos regocijaremos en ellos.</p>
<br/>
<p class="text-justify">Vv. 8-11.La mayoría de los hombres se complacen mirando los acontecimentos futuros y a todos los hombres buenos les gusta recibir una palabra de Dios. Pero cuando este libro de la profecía fue digerido completamente por el apóstol, su contenido resultó amargo; había cosas tan terribles y espantosas, persecuciones tan dolorosas del pueblo de Dios, tales estragos en la tierra que verlos y saberlos por anticipado sería doloroso para su mente. Procuremos ser enseñados por Cristo y obedezcamos sus órdenes; meditemos diariamente en su palabra para que nutra nuestras almas; y, luego, declarémosla conforme a nuestros diversos emplazamientos. La dulzura de las contemplaciones estará, a menudo, mezclada con amargura cuando comparamos las Escrituras con el estado del mundo y la iglesia, o hasta con el de nuestros propios corazones.</p>
<br/>




</div>
