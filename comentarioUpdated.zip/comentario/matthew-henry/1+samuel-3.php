<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Samuel 3</h2>
<p class="text-justify">Vv. 1-10.El llamamiento que se hace según el propósito de la gracia divina es eficaz; será repetido hasta que así sea, hasta que respondamos al llamado. Al darse cuenta que era la voz de Dios lo que Samuel había oído, Elí le instruye acerca de lo que debía decir. Aunque era una desgracia para Elí, porque el llamado de Dios iba dirigido a Samuel, le enseñó a contestar. De esa manera, el anciano debe hacer lo mejor y lo más que pueda para ayudar y mejorar a los más jóvenes que van surgiendo. No dejemos nunca de enseñar a los que vienen detrás de nosotros, aunque ellos pronto sean preferidos en nuestro lugar, Juan i, 30. Las buenas palabras deben ser puestas oportunamente en la boca de los niños, para que estén preparados para aprender cosas divinas y ser educados para tenerlas en consideración.</p>
<br/>
<p class="text-justify">Vv. 11-18.Cuán gran cantidad de culpa y corrupción hay en nosotros, acerca de lo que podemos decir: ¡es la iniquidad que nuestro corazón sabe; nosotros mismos estamos conscientes de ella! Los que no reprimen los pecados del prójimo, cuando pueden, se hacen partícipes de la culpa y les será cargada por unirse a ella.
En su notable respuesta a esta espantosa sentencia, Elí reconoce que el Señor tenía el derecho a hacer lo que bien le pareciera, estando seguro de que nada malo haría. La mansedumbre, la paciencia y la humildad contenidas en esas palabras demuestran que él está verdaderamente arrepentido; él aceptó el castigo de su pecado.</p>
<br/>
<p class="text-justify">Vv. 19-21.Todo incremento de sabiduría y gracia se debe a la presencia de Dios junto a nosotros. Dios repetirá bondadosamente sus visitas a quienes las reciben bien. La temprana piedad será la honra más grande de la juventud. Dios honrará a los que le honran.
Que la gente joven considere la piedad de Samuel y de él aprendan a acordarse de su Creador en los días de su juventud. Los niños pequeños pueden ser religiosos. Samuel es la prueba de que agrada al Señor que los niños le escuchen y esperen en Él. Samuel es un patrón de todos los temperamentos amables que son el ornamento más esplendoroso de la juventud y fuente segura de dicha.</p>
<br/>




</div>
