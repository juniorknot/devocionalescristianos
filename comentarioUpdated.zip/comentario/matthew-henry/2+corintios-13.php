<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Corintios 13</h2>
<p class="text-justify">Vv. 1-6.Aunque el método de la gracia de Dios es soportar por mucho tiempo a los pecadores, no siempre tolera; finalmente vendrá y no perdonará a los que siguen obstinados e impenitentes. Cristo en su crucifixión parecía solamente un hombre débil e indefenso, pero su resurrección y su vida demostraron su poder divino. Así los apóstoles, por más viles y despreciables que parecieran ante el mundo, como instrumentos manifestaban, no obstante, el poder de Dios.
Prueben ellos sus temperamentos, conducta y experiencia, como el oro es probado o ensayado por la piedra de toque. Si podían demostrar que no eran réprobos, que no eran rechazados por Cristo, confiaba que sabrían que él no era un réprobo ni un desconocido de Cristo. Debían saber si Cristo Jesús estaba o no en ellos, por la influencia, la gracia y la morada de su Espíritu, por su reino establecido en sus corazones. Preguntemos a nuestras almas; somos cristianos verdaderos o somos engañadores. A menos que Cristo esté en nosotros por su Espíritu, y el poder de su amor, nuestra fe está muerta, y aún estamos reprobados por nuestro Juez.</p>
<br/>
<p class="text-justify">Vv. 7-10.Lo más deseable que podemos pedir a Dios es ser resguardados del pecado, que ni nosotros y ni ellos hagamos el mal. Necesitamos mucho más orar para no hacer lo malo que para no sufrir el mal. El apóstol no sólo desea que sean guardados del pecado, pero también crezcan en gracia y santidad. Tenemos que orar fervientemente a Dios por aquellos a quienes amonestamos para que dejen de hacer el mal y aprendan a hacer el bien; hemos de alegrarnos por los otros que son fuertes en la gracia de Cristo, aunque puedan ser el medio de demostrarnos nuestra propia debilidad. Oremos también que podamos usar adecuadamente todos nuestros talentos.</p>
<br/>
<p class="text-justify">Vv. 11-14.Aquí hay varias exhortaciones buenas. Dios es el Autor de la paz y el Amante de la concordia; Él que nos ha amado, y quiere estar en paz con nosotros. Que sea nuestra mira constante andar en tal forma que la separación de nuestros amigos sea sólo por un tiempo, y podamos reunirnos en aquel mundo dichoso donde no habrá separación. Desea que ellos participen de todos los beneficios que Cristo ha adquirido de su gracia y favor gratuitos; que se ha propuesto el Padre por su libre amor, y que el Espíritu Santo aplica y otorga.</p>
<br/>




</div>
