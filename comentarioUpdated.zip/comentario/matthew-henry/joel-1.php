<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Joel 1</h2>
<p class="text-justify">Vv. 1-7.Los más viejos no recordaban que hubieran ocurrido alguna vez tales calamidades. Ejércitos de insectos venían a la tierra para comerse sus frutos. Se expresa como para aplicarlo también a la destrucción del país por parte de un enemigo extranjero, y parece referirse a las devastaciones hechas por los caldeos.
Dios es el Señor de los ejércitos, tiene a toda criatura a sus órdenes, y cuando le place, puede humillar y mortificar a un pueblo orgulloso y rebelde, por medio de las criaturas más débiles y más despreciables. Justo es que Dios quite las comodidades que resultaron en abuso al extremo del lujo y los excesos; mientras más depositen los hombres su felicidad en el deleite de los sentidos, más graves serán sus aflicciones temporales. Mientras más deleites terrenales necesitemos para satisfacernos, a mayores problemas nos exponemos.</p>
<br/>
<p class="text-justify">Vv. 8-13.Todos los que trabajan sólo por la carne que perece, tarde o temprano, serán avergonzados de su esfuerzo. Quienes ponen su felicidad en los deleites de los sentidos, pierden su gozo cuando se les priva de ellos o se les interrumpe su goce; en cambio, el gozo espiritual florece entonces más que nunca. Véase cuán perecederos e inciertos son nuestros consuelos humanos. Véase cuánto necesitamos vivir en continua dependencia de Dios y su providencia. Véase qué obra destructora hace el pecado. En cuanto a la pobreza que ocasiona el deterioro de la piedad, y hambrea la causa de la religión de un pueblo, es un juicio muy doloroso. Pero, ¡cuán benditos son los juicios vivificantes de Dios que levantan a su pueblo y llaman a casa el corazón, a Cristo, y a su salvación!</p>
<br/>
<p class="text-justify">Vv. 14-20.El dolor de un pueblo se convierte en arrepentimiento y humillación ante Dios. Con todas las marcas del dolor y la vergüenza, el pecado debe ser confesado y lamentado. Hay un día designado para ese propósito; un día en que el pueblo debe dejar sus ocupaciones corrientes para atender más estrictamente el servicio de Dios; tiene que haber abstención de carne y bebida. Cada uno ha sumado a la culpa nacional, todos comparten en la calamidad nacional, por tanto, cada uno debe unirse al arrepentimiento.
Cuando el gozo y la dicha son cortados de la casa de Dios, cuando la santidad seria decae y el amor se enfría, entonces es hora de clamar al Señor. El profeta describe cuán penosa es la calamidad. Véase que hasta las criaturas inferiores sufren por nuestra transgresión. ¿Y cuánto mejor que las bestias son los que nunca claman a Dios, sino al trigo y al vino, y se quejan de la falta de deleites sensuales? Clamar a Dios en esos casos, avergüenza la estupidez de los que no claman en ningún caso.
Sea lo que sea que lleguen a ser las naciones e iglesias que persistan en la impiedad, los creyentes encontrarán el consuelo de la aceptación de Dios cuando el impío sea quemado con su indignación.</p>
<br/>




</div>
