<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Lucas 8</h2>
<p class="text-justify">Vv. 1-3.Aquí se nos dice que Cristo hizo de la enseñanza del evangelio la actividad constante de su vida. Las noticias del reino de Dios son buenas noticias, y es lo que Cristo vino a traer.
Algunas mujeres lo asistían y le ministraban de su sustancia. Esto muestra la baja condición a la cual se humilló el Salvador, que necesitaba de la bondad de ellas, y su gran humildad para aceptarles. Siendo rico se hizo pobre por nosotros.</p>
<br/>
<p class="text-justify">Vv. 4-21.En la parábola del sembrador hay muchas reglas y excelentes advertencias muy necesarias para oír la palabra, y aplicarla. Bienaventurados somos, y por siempre endeudados con la libre gracia, si lo que para otros es sólo un cuento que los divierte, es una verdad clara para nosotros por la cual se nos enseña y gobierna. Debemos cuidarnos de las cosas que nos impidan recibir provecho de la palabra que oímos; cuidarnos, no sea que oigamos con negligencia y ligereza; no sea que alberguemos prejuicios contra la palabra que oímos; y cuidar nuestros espíritus después que hayamos oído la palabra, no sea que perdamos lo que ganamos. Los dones que tenemos nos serán o no continuados según los usemos para la gloria de Dios y el bien de nuestros hermanos. Tampoco basta sostener la verdad con injusticia; debemos desear tener en alto la palabra de vida, y que resplandezca iluminando todo nuestro entorno. Se da gran ánimo a los que son oidores fieles de la palabra y hacedores de la obra. Cristo los reconocerá como sus familiares.</p>
<br/>
<p class="text-justify">Vv. 22-40.Los que se hacen a la mar cuando está calma, a la palabra de Cristo, deben, no obstante, prepararse para una tormenta y para gran peligro en medio de la tormenta. No hay alivio para las almas sometidas al sentido de culpa, y al temor de la ira, si no acuden a Cristo, le llaman Señor, y le dicen: Estoy acabado si no me socorres. Cuando terminan nuestros peligros, nos corresponde reconocer la vergüenza de nuestros temores, y dar a Cristo la gloria por nuestra liberación.
Podemos aprender mucho en este relato respecto del mundo de los espíritus malignos infernales, porque aunque no obren exactamente de la misma manera ahora que entonces, todos debemos resguardarnos contra ellos. Los espíritus malignos son muy numerosos. Tienen enemistad contra el hombre y contra todas sus consolaciones. Los que se someten al gobierno de Cristo son dulcemente guiados con lazos de amor; los que se someten al gobierno del diablo son obligados con furor. ¡Ah, qué consuelo es para el creyente que todas las potestades de las tinieblas estén sometidas al dominio del Señor Jesús! Milagro de misericordia es si los poseídos por Satanás no son llevados a la destrucción y ruina eternas.
Cristo no se quedará con quienes lo toman a la ligera; puede ser que no regrese más a ellos, mientras otros le esperan felices de recibirlo.</p>
<br/>
<p class="text-justify">Vv. 41-56.No nos quejemos de la gente, ni de una multitud, ni de lo urgente si estamos en el camino de nuestro deber y haciendo el bien, pero de lo contrario, todo hombre sabio se mantendrá lo más alejado que pueda de tales cosas. Más de una pobre alma sanada, socorrida y salvada por Cristo se halla oculta entre la gente y nadie la nota. Esta mujer vino temblando, pero su fe la salvó. Puede que haya temblor donde aún hay fe salvadora.
Observa las consoladoras palabras de Cristo para Jairo: No temas, tan sólo cree, y tu hija será salva. No era menos duro no llorar la pérdida de una hija única que no temer la continuación de ese dolor; pero en la fe perfecta no hay temor; mientras más temor, menos creemos. La mano de la gracia de Cristo va con el llamado de su palabra para hacerla eficaz.
Cristo mandó darle solamente carne. Como bebés recién nacidos así desean alimento espiritual los recién resucitados del pecado, para crecer.</p>
<br/>




</div>
