<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Miqueas 1</h2>
<p class="text-justify">Vv. 1-7.La tierra con todo lo que en ella hay es llamada a oír al profeta. El santo templo de Dios no protegerá a los falsos profesantes. Tampoco los hombres de alto rango, como las montañas, ni los hombres de baja condición, como los valles pueden asegurarse a sí mismos o a la tierra contra los juicios de Dios. Si se encuentra pecado en el pueblo de Dios, no los perdonará; y sus pecados son más provocadores para Él, porque merecen el mayor de los reproches.
Cuando sentimos el pinchazo del pecado nos corresponde indagar cuál es el pecado por el cual somos asaeteados. Las personas y los lugares más elevados son los más expuestos a las enfermedades espirituales. Los vicios de los líderes y reyes serán castigados segura y agudamente.
El castigo responde al pecado. Lo que dieron a los ídolos nunca prosperará ni les hará ningún bien. Lo que se logra por una lujuria se desperdicia en otra.</p>
<br/>
<p class="text-justify">Vv. 9-16.El profeta lamenta que el caso de Israel sea desesperado; pero no lo declara en Gat. No deis complacencia a los que se alegran con los pecados o con las penas del Israel de Dios. Revuélcate en el polvo, como acostumbraban los de duelo; que cada casa de Jerusalén se haga casa de Afra, “una casa de polvo”. Cuando Dios hace polvo la casa, corresponde que nos humillemos hasta el polvo bajo su mano poderosa.
Muchos lugares deben compartir este duelo. Los nombres tienen significados que apuntaban a las miserias venideras para ellos; para despertar por ellas al pueblo a un santo temor por la ira divina.
Todos los refugios, excepto Cristo, deben ser refugios de mentira para los que confían en sí; otros herederos recibirán cada herencia, pero no el cielo, y toda la gloria será vergüenza, excepto la honra que sólo procede de Dios. Ahora pueden los pecadores despreciar los sufrimientos de sus vecinos, pero pronto les llegará el turno de ser castigados.</p>
<br/>




</div>
