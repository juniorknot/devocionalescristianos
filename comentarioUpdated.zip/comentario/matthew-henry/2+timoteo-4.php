<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Timoteo 4</h2>
<p class="text-justify">Vv. 1-5.La gente se alejará de la verdad, se cansarán del claro evangelio de Cristo, desearán las fábulas y se complacerán en ellas. La gente hace eso cuando no soporta la predicación penetrante, sencilla y que va al grano. Los que aman las almas deben estar siempre alertas, arriesgarse, soportar todos los efectos dolorosos de su fidelidad, y aprovechar todas las oportunidades para dar a conocer el puro evangelio.</p>
<br/>
<p class="text-justify">Vv. 6-8.La sangre de los mártires, aunque no era un sacrificio expiatorio, sin embargo, fue un sacrificio de reconocimiento de la gracia de Dios y de su verdad. La muerte para el hombre bueno es su liberación de la prisión de este mundo, y su partida a disfrutar del otro mundo. Como cristiano y ministro, Pablo había guardado la fe, sostenido con firmeza las doctrinas del evangelio. ¡Qué consuelo es poder hablar de esta manera al fin de nuestros días! La corona de los creyentes es una corona de justicia adquirida por la justicia de Cristo. Los creyentes no la tienen actualmente, pero es segura porque está puesta para ellos. El creyente, en medio de la pobreza, el dolor, la enfermedad y las agonías de la muerte, puede regocijarse; pero si un hombre descuida los deberes de su cargo y lugar, se oscurece la prueba de su interés en Cristo, y se puede esperar que la incertidumbre y la angustia oscurezcan y asedien sus últimas horas.</p>
<br/>
<p class="text-justify">Vv. 9-13.El amor a este mundo suele ser la causa para apostatar de las verdades y caminos de Jesucristo.
Pablo fue guiado por inspiración divina, pero él tenía sus libros. Debemos seguir aprendiendo mientras vivamos. Los apóstoles no descuidaron los medios humanos al procurar las necesidades de la vida o su propia instrucción. Agradezcamos a la bondad divina por habernos dado tantos escritos de hombres sabios y piadosos de todas las épocas; y procuremos que sea nuestro el provecho de su lectura y ello se haga evidente para todos.</p>
<br/>
<p class="text-justify">Vv. 14-18.Hay tanto peligro de parte de los hermanos falsos, como de los enemigos declarados. Peligroso es tener que ver con los enemigos de un hombre como Pablo. Los cristianos de Roma fueron a encontrarle, Hechos xxviii, pero todos lo abandonaron cuando pareció que había peligro de sufrir con él; entonces. Dios pudo justamente enojarse con ellos, pero él oró a Dios que los perdonara. El apóstol fue librado de las fauces del león, esto es, de Nerón o de algunos de sus jueces. Si el Señor está por nosotros, nos fortalecerá en las dificultades y los peligros, y su presencia suplirá con creces la ausencia de cada uno y de todos.</p>
<br/>
<p class="text-justify">Vv. 19-22.Para ser felices no necesitamos más que tener al Señor Jesucristo con nuestro espíritu, porque en Él se resumen todas las bendiciones espirituales. La mejor oración que podemos ofrecer por nuestros amigos es que el Señor Jesucristo esté con sus espíritus que los santifique y los salve, y que al final los reciba junto a Él. Muchos que creyeron, como Pablo, están ahora ante el trono, dando gloria a su Señor: seamos sus seguidores.</p>
<br/>




</div>
