<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Crónicas 2</h2>
<br/>
<div class="alert callout">
<p>La Versión(Comentario Bíblico de Matthew Henry) no posee información para el capítulo 2 Crónicas 2. </p>

<p class="text-justify">Le recomendamos que consulte en nuestra lista de comentarios bíblicos uno distinto para obtener más información. Gracias por usar " BibliaDC Comentarios".</p>




</div>
