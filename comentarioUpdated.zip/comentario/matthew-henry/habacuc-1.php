<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Habacuc 1</h2>
<p class="text-justify">Vv. 1-11.Los siervos del Señor están profundamente afligidos por ver que prevalecen la impiedad y la violencia; especialmente entre los que profesan la verdad. Ningún hombre tenía escrúpulos de hacer el mal a su prójimo. Debemos anhelar irnos a aquel mundo donde reinan por siempre la santidad y el amor, y donde no habrá violencia ante nosotros. Dios tiene buenas razones para ser paciente con los malos y de reprender a los hombres buenos. Llegará el día en que el clamor del pecado será oído contra los que hacen el mal, y el clamor de la oración de quienes sufren el mal.
Tenían que notar lo que estaba pasando entre los paganos a manos de los caldeos y considerarse a sí mismos como nación próxima a ser azotada por ellos. Pero la mayoría de los hombres presumen de la continuada prosperidad o que las calamidades no llegarán en su tiempo. Son nación amarga y presurosa, fiera, cruel y derriba todo lo que está delante de ellos. Ellos vencerán a todo el que se les oponga. Pero darse la gloria a uno mismo es una gran ofensa y ofensa corriente del pueblo orgulloso.
Las palabras finales dan un atisbo de consuelo.</p>
<br/>
<p class="text-justify">Vv. 12-17.Sean como sean las cosas, Dios es el Señor, nuestro Dios, nuestro Santo. Somos un pueblo ofensor; Él es un Dios ofendido, pero nosotros no albergamos pensamientos malos de Él o de su servicio. Gran consuelo es que, cualquiera sea la maldad que conciban los hombres, el Señor concibe el bien, y estamos seguros de que su consejo resistirá. Aunque la maldad pueda prosperar por un rato, Dios es santo y no aprueba esa maldad. Como Él mismo no puede hacer iniquidad, así sus ojos son muy puros como para contemplarla con aprobación. Por este principio debemos guiarnos, aunque las dispensaciones de su providencia puedan, por un tiempo, en algunos casos, parecernos que no concuerdan con eso.
El profeta se queja de que se abusaba de la paciencia de Dios; y como la sentencia contra estas malas obras y malos obreros no fue ejecutada velozmente, sus corazones estaban más plenamente dispuestos para hacer el mal. A algunos los toman como con anzuelo, uno por uno; otros, son tomados en las aguas bajas como con red y los reúne en su red, que todo lo encierra. Ellos admiran su propia destreza y capacidad inventiva: hay una gran proclividad en nosotros para adueñarnos de la gloria de la prosperidad externa. Esto es idolizarnos a nosotros mismos, sacrificando a la red porque es nuestra.
Dios terminará pronto los robos espléndidos y exitosos. La muerte y el juicio harán que los hombres cesen de ser predadores del prójimo, y serán sus propias presas. Recordemos que sin importar las ventajas que poseamos, debemos dar toda la gloria a Dios.</p>
<br/>




</div>
