<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Miqueas 5</h2>
<p class="text-justify">Vv. 1-6.Habiendo mostrado cuánto se rebajaría a la casa de David, se agrega una predicción del Mesías y su reino para exhortar a la fe del pueblo de Dios. Se comentan su existencia desde la eternidad como Dios y su oficio como Mediador. Aquí se predice que Belén será su lugar de nacimiento. De ahí que fuera universalmente conocido entre los judíos, Mateo ii, 5.
El gobierno de Cristo será muy feliz para sus súbditos; ellos estarán seguros y tranquilos. Bajo la sombra de la protección contra los asirios está la promesa de la protección para la Iglesia del evangelio y todos los creyentes, contra los designios e intentos de las potestades de las tinieblas. Cristo es nuestra Paz como Sacerdote, que expía el pecado y nos reconcilia con Dios; y es nuestra Paz como Rey que vence a nuestros enemigos: de ahí que nuestras almas puedan habitar tranquilas en Él.
Cristo encontrará instrumentos para proteger y librar. Los que amenazan con destruir la Iglesia de Dios, pronto se acarrean ruina a sí mismos. Esto puede incluir los pasados efectos poderosos del evangelio predicado, su futura difusión y la destrucción de todas las potestades anticristianas.
Esta es, quizá, la profecía específica más importante del Antiguo Testamento: se refiere al carácter personal del Mesías y la revelación de sí mismo al mundo. Distingue entre el nacimiento humano y su existencia desde la eternidad; predice el rechazo de los israelitas y los judíos por una temporada, su restauración final y la paz universal que prevalecerá en toda la tierra durante los últimos días. Mientras tanto, confiemos en el cuidado y poder de nuestro Pastor. Si permite el ataque de nuestros enemigos, Él nos suplirá ayudantes y asistencia para nosotros.</p>
<br/>
<p class="text-justify">Vv. 7-15.El remanente de Israel, convertido a Cristo en tiempos primitivos, estaba entre muchas naciones como gotas de rocío y fueron hechos instrumentos para convocar a un gran aumento de los adoradores espirituales. Pero a los que despreciaron o se opusieron a esta salvación, como leones les iba a causar terror, condenándolos su doctrina.
El Señor declara también que hará no sólo la reforma de los judíos, sino la purificación de la iglesia cristiana. De manera semejante, se nos asegura la victoria en nuestros conflictos personales al depender simplemente del Señor nuestra salvación, adorarlo y servirle con diligencia.</p>
<br/>




</div>
