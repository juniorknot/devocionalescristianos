<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Jeremías 52</h2>
<p class="text-justify">Vv. 1-11.Por encima de cualquier cosa debemos orar contra este fruto de pecado: No me eches de delante de ti, Salmo li, 11. Nadie es echado de la presencia de Dios sino los que, por su pecado, primero se ponen fuera ellos mismos.
La fuga de Sedequías fue en vano, porque no hay escapatoria de los juicios de Dios; ellos sobrevienen al pecador y lo vencen, dejándole huir dondequiera.</p>
<br/>
<p class="text-justify">Vv. 12-23.El ejército caldeo hizo mucha destrucción. Pero nada se relata con tanto detalle aquí como el traslado de los utensilios del templo. El recuerdo de su belleza y valor hace resaltar la maldad del pecado.</p>
<br/>
<p class="text-justify">Vv. 24-30.Los líderes de los judíos les hicieron cometer yerros, pero ahora ellos son, en particular, hechos monumentos de la justicia divina.
He aquí un relato de dos cautiverios anteriores. Este pueblo fue a menudo prodigio de juicio y de misericordia.</p>
<br/>
<p class="text-justify">Vv. 31-34.Véase la historia del rey Joaquín en 2 Reyes xxv, 27-30. Los que están bajo opresión hallarán que no es en vano tener esperanza y esperar en silencio por la salvación del Señor. Nuestros tiempos están en la mano de Dios, porque los corazones de todos con quienes tenemos que tratar lo están.
Que seamos capacitados, más y más para reposar en la Roca de los siglos y esperar con santa fe la hora en que el Señor restaurará a Sion, y vencerá a todos los enemigos de la Iglesia.</p>
<br/>




</div>
