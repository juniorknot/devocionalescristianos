<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Reyes 4</h2>
<p class="text-justify">Vv. 1-19.Indudablemente manifestó su sabiduría en la elección de los grandes dignatarios de la corte de Salomón. Varios son los mismos que estaban en la época de su padre. Se establece un programa para abastecer la corte por el cual ninguna parte del país se agote, aunque cada una mandaba su porción.</p>
<br/>
<p class="text-justify">Vv. 20-28.Nunca resplandeció con tanto brillo la corona de Israel como cuando Salomón la llevó. Tuvo paz por todos lados. Aquí, su reino fue tipo del reino del Mesías; porque se le promete que tendrá a los gentiles por heredad y príncipes le adorarán.
La paz espiritual, el gozo y la santa seguridad de todos los fieles súbditos del Señor Jesús fueron tipificados por los de Israel.
El reino de Dios no es, como el de Salomón, cosa de comida y bebida sino, de lo que es infinitamente mejor, de justicia, paz y gozo en el Espíritu Santo. El vasto número de sus ayudantes y la gran cantidad de personas que recurrían a él se muestran por el monto de la provisión diaria. Aquí Cristo supera lejos a Salomón, porque alimenta a todos sus súbditos, no con el pan que perece, sino con el que para vida eterna permanece.</p>
<br/>
<p class="text-justify">Vv. 29-34. Fue más gloria para Salomón su sabiduría que su riqueza. Él tenía lo que aquí se llama anchura de corazón, porque a menudo se pone el corazón para referirse a los poderes de la mente. Tenía el don de la palabra y la sabiduría. Muy deseable es que quienes tienen grandes dones de cualquier clase, tengan anchura de corazón para usarlos para el bien del prójimo. -¡Qué tesoros de sabiduría y conocimiento se pierden! Pero cada clase de conocimiento que sea necesario para la salvación se halla en las Sagradas Escrituras.
A él vinieron personas de todas partes, que apreciaron más el conocimiento que sus vecinos, para oír la sabiduría de Salomón. En esto Salomón es tipo de Cristo, en quien están escondidos todos los tesoros de la sabiduría y del conocimiento; y escondidos para nosotros, pues Él es hecho por Dios sabiduría para nosotros. La fama de Cristo se difundirá por toda la tierra y los hombres de todas las naciones acudirán a Él, aprenderán de Él y tomarán su yugo que es liviano, y hallarán reposo para su alma.</p>
<br/>




</div>
