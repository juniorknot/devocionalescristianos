<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Lamentaciones 1</h2>
<p class="text-justify">Vv. 1-11.A veces el profeta habla en primera persona; otras, quien habla es Jerusalén, como mujer angustiada, o algunos de los judíos. La descripción muestra las miserias de la nación judía. Jerusalén llegó a estar cautiva y esclava, debido a la grandeza de sus pecados; y no tuvo reposo en el sufrimiento. Si permitimos que el pecado, nuestro adversario más grande, tenga dominio en nosotros, justamente soportaremos que otros enemigos también nos dominen.
El pueblo soportó los extremos del hambre y la angustia. En esta triste condición Jerusalén reconoció su pecado y rogó al Señor que mirara su caso. Este es el único camino para aliviarnos bajo la carga; porque es la justa ira de Jehová por las transgresiones del hombre, que ha llenado la tierra de tristeza, lamentos, enfermedad y muerte.</p>
<br/>
<p class="text-justify">Vv. 12-22.Jerusalén, sentada en el suelo, deprimida, llama a los que pasan para que consideren si su caso no les concierne. Sus sufrimientos externos eran grandes, pero sus sufrimientos internos eran más difíciles de soportar, por el sentido de culpa. La tristeza por el pecado debe ser pesar grande y debe afectar el alma. Aquí vemos el mal del pecado y podemos ser advertidos para huir de la ira venidera. Lo que se aprenda de los sufrimientos de Jerusalén, puede aprenderse mucho más de los sufrimientos de Cristo. ¿No nos habla Él desde la cruz a cada uno de nosotros? ¿No dice: Es nada para vosotros, todos los que pasáis? Que todas nuestras penas nos guíen a la cruz de Cristo, que nos guíen para notar su ejemplo y seguirle alegremente.</p>
<br/>




</div>
