<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Jeremías 33</h2>
<p class="text-justify">Vv. 1-13.Los que esperan recibir consuelo de Dios deben invocarlo. Se dan promesas no de destruir, sino de vivificar y alentar la oración. Estas promesas nos guían al evangelio de Cristo; y en él Dios ha revelado su verdad para dirigirnos, su paz para tranquilizarnos. Todos los que son limpiados de la inmundicia del pecado por la gracia santificadora, por la misericordia perdonadora son liberados de la culpa. Cuando los pecadores reciben la justicia, y son lavados y santificados en el nombre del Señor Jesús, y por el Espíritu Santo, son capacitados para andar delante de Dios en paz y pureza. Muchos son llevados a notar la diferencia real entre el pueblo de Dios y el mundo que los rodea, y a temer la ira divina.
Se promete que el pueblo que estuvo entristecido por mucho tiempo, de nuevo se llenará de gozo. Donde el Señor da justicia y paz, dará todo lo necesario para las necesidades temporales; y todo lo que tenemos serán consolaciones como santificados por la palabra y la oración.</p>
<br/>
<p class="text-justify">Vv. 14-26. Para coronar las bendiciones que Dios tiene guardadas, he aquí una promesa del Mesías. Él imparte justicia a su Iglesia, porque Él es hecho justicia nuestra por Dios; y los creyentes son hechos justicia de Dios en Él. Cristo es nuestro Señor Dios, justicia nuestra, nuestra santificación y nuestra redención. Su reino es reino eterno. Pero en este mundo la prosperidad y la adversidad se suceden una a otra como la luz y las tinieblas, el día y la noche.
El pacto del sacerdocio será asegurado. Todoslos creyentes verdaderos son un sacerdocio santo, un sacerdocio real, ellos ofrecen sacrificios espirituales, aceptables a Dios; ellos mismos, en primer lugar, como sacrificios vivos.
Las promesas del pacto tendrán cumplimiento pleno en el Israel del evangelio. En Gálatas vi, 16, todos los que andan conforme a la regla del evangelio son hechos Israel de Dios, en quien habrá paz y misericordia. No despreciemos las familias que de antes fueron el pueblo escogido de Dios, aunque por un tiempo parezcan desechados.</p>
<br/>




</div>
