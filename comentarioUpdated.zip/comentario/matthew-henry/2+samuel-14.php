<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Samuel 14</h2>
<p class="text-justify">Vv. 1-20.Aquí podemos advertir cómo ruega esta viuda la misericordia de Dios y su clemencia para con pobres pecadores culpables. El estado de los pecadores es el de estar destituidos de Dios. Dios no perdona a nadie que deshonre de su ley y justicia, a nadie que sea impenitente, ni a quienes estimulen el delito, ni al que causa daño al prójimo.</p>
<br/>
<p class="text-justify">Vv. 21-24.David se inclinaba en favor de Absalón, pero por la honra de su justicia, no podía hacerlo regresar si no se le solicitaba, lo cual puede mostrar los métodos de la gracia divina. Verdad es que Dios piensa compasivamente en cuanto a los pobres pecadores, y no quiere que ninguno perezca; pero se reconcilia con ellos a través de un Mediador que ruega por ellos. Dios estaba en Cristo reconciliando consigo al mundo, y Cristo vino a la tierra de nuestro exilio para llevarnos a Dios.</p>
<br/>
<p class="text-justify">Vv. 25-27.Nada se dice de la sabiduría y piedad de Absalón. Todo lo que se dice de él es que era muy bien parecido. Pobre recomendación para un hombre que no tenía otra cosa de valor en él. Muchas almas contaminadas y deformadas habitan un cuerpo hermoso. Leemos que tenía un cabello muy bello, que era una carga para él, pero no se lo cortaba mientras soportara el peso. Nadie se queja de eso que estimula y gratifica al orgullo, aunque sea incómodo. ¡Quiera el Señor concedernos la belleza de la santidad, y el adorno de un espíritu manso y apacible! Sólo quienes temen a Dios son verdaderamente felices.</p>
<br/>
<p class="text-justify">Vv. 28-33.Por su actitud insolente con Joab, Absalón hizo que aquel rogara por él. Obtuvo su deseo por su mensaje insolente al rey. Cuando los padres y los gobernantes toleran tales personalidades, pronto sufrirán los efectos más fatales. Pero la compasión de padre prevaleció para reconciliarlo con su hijo impenitente, y ¿cuestionarán los pecadores arrepentidos la compasión de Aquel que es el Padre de las misericordias?</p>
<br/>




</div>
