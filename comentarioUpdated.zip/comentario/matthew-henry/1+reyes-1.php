<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Reyes 1</h2>
<p class="text-justify">Vv. 1-4.Tenemos aquí a David hundiéndose bajo las enfermedades. Fue castigado por sus pecados recientes y sintió los efectos de los esfuerzos y las duras labores del pasado.</p>
<br/>
<p class="text-justify">Vv. 5-10. Los padres indulgentes suelen ser castigados con hijos desobedientes, ansiosos por apoderarse de su fortuna. Ninguna sabiduría mundana, experiencia ni santidad de carácter pueden asegurar la continuidad de una carrera de quienes permanecen bajo el poder del amor propio. Pero bien podemos preguntarnos por medio de cuáles artes podría dejarse de un lado a Joab y Abiatar.</p>
<br/>
<p class="text-justify">Vv. 11-31.Obsérvense las palabras de Natán a Betsabé: Toma mi consejo, para que salves tu vida, y la de tu hijo Salomón. Semejante a este es el consejo que nos dan los ministros de Cristo en su nombre, para que pongamos toda diligencia no sólo para que nadie tome nuestra corona, Apocalipsis iii, 11, sino para que salvemos nuestra vida, sí, la vida de nuestra alma. David declaró solemnemente su firme adhesión a la anterior resolución de que Salomón fuera su sucesor. Aun el recuerdo del desastre del cual lo rescató el Señor, aumentó su consuelo, inspiró sus esperanzas y le animó a su deber, a pesar del deterioro de la edad y la proximidad de la muerte.</p>
<br/>
<p class="text-justify">Vv. 32-53. El pueblo expresó gran gozo y satisfacción con la ascensión de Salomón. Todo israelita verdadero se regocija en la exaltación del Hijo de David.
Pronto se disolverán las combinaciones formadas sobre malos principios, cuando el interés propio llame a cambiar de rumbo. ¿Cómo pueden esperar buenas nuevas quienes hacen malas obras? Adonías había despreciado a Salomón, pero pronto le tuvo temor.
Aquí vemos, como por espejo, a Jesús, el Hijo de David e Hijo de Dios, exaltado al trono de gloria, a pesar de todos sus enemigos. Su Reino es mucho más grande que el de su padre David y allí se regocija cordialmente todo el verdadero pueblo de Dios. La prosperidad de su causa es insulto y terror para sus enemigos. Ningún cuerno de altar, ninguna forma de piedad, y ninguna religión simulada, pueden servir de provecho a quienes no se sometan a su autoridad, y acepten su salvación; y si la sumisión de ellos es hipócrita, perecerán sin remedio.</p>
<br/>




</div>
