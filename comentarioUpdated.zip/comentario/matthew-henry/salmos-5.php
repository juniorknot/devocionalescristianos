<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Salmos 5</h2>
<p class="text-justify">Vv. 1-6. Dios es un Dios que oye la oración. Siempre ha sido así, y sigue como siempre dispuesto a oír la oración. El principio más alentador de la oración y el ruego más poderoso es mirarlo a Él como nuestro Rey y nuestro Dios. David también ora a un Dios que odia el pecado. El pecado es necedad y los pecadores son los más grandes de los necios; necios por propia hechura. La gente mala odia a Dios; son justamente odiados por Él, y esta será su miseria y su ruina eterna. Aprendamos la importancia de la verdad y de la sinceridad en todos los asuntos de la vida. Los mentirosos y los asesinos se parecen al diablo y son sus hijos, por tanto, bien puede esperarse que Dios los aborrezca. Este era el carácter de los enemigos de David y, como tales, siguen siendo enemigos de Cristo y de su pueblo.</p>
<br/>
<p class="text-justify">Vv. 7-12. David solía orar a solas, aunque era muy constante para ir a la adoración pública. La misericordia de Dios siempre debe ser el fundamento de nuestra esperanza y de nuestro gozo en todo que tengamos que hacer con Él.
Aprendamos a orar, no sólo por nosotros, también por los demás; que la gracia sea con todos los que aman a Cristo con sinceridad. La divina bendición desciende sobre nosotros por medio de Jesucristo, el recto o el justo, de la manera que antes venía sobre Israel por medio de David, a quien Dios protegió y puso en el trono. Tú, oh Cristo, eres el Salvador justo, eres el Rey de Israel, eres la fuente de bendición para todos los creyentes; tu favor es la defensa y la protección de tu iglesia.</p>
<br/>




</div>
