<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Ezequiel 2</h2>
<p class="text-justify">Vv. 1-5.Para que Ezequiel no se envanezca con la abundancia de las revelaciones, se le pone en la mente que aún es un hijo de hombre, criatura débil y mortal. Como Cristo habitualmente se llamaba el Hijo del Hombre, también fue una distinción honrosa.
La postura de Ezequiel muestra reverencia, pero levantarse sería una postura de mayor disposición y aptitud para entrar en acción. Dios nos hablará cuando estemos listos para hacer lo que nos manda. Como Ezequiel no tenía fuerza propia, el Espíritu entró en él. Dios se complace en su gracia de obrar en nosotros lo que sea que requiera de nosotros. El Espíritu Santo nos pone de pie inclinando nuestras voluntades a nuestro deber. Así, pues, cuando el Señor llama al pecador que se despierte, y atienda a los intereses de su alma, el Espíritu de vida y gracia trae el llamamiento.
Ezequiel es enviado con un mensaje a los hijos de Israel. Muchos podrían tratar con desprecio este mensaje, pero debieran saber por el acontecimiento, que un profeta había sido enviado a ellos. Dios será glorificado y su palabra honrada, sea sabor de vida para vida o de muerte para muerte.</p>
<br/>
<p class="text-justify">Vv. 6-10.Los que quieren hacer cualquier cosa con el propósito del servicio de Dios, no deben temer a los hombres. Los impíos son como cardos y espinos, pero están para la maldición y su final es ser quemados. El profeta debe ser fiel a las almas de aquellos a quienes fue enviado. Todos los que hablan de parte de Dios al prójimo, deben obedecer su voz. Los descubrimientos del pecado y las advertencias de la ira deben ser materia de lamento. Los que están familiarizados con la palabra de Dios percibirán claramente que está llena de ayes para los pecadores no arrepentidos; y que todas las promesas preciosas del evangelio son para los siervos creyentes y arrepentidos del Señor.</p>
<br/>




</div>
