<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Samuel 31</h2>
<p class="text-justify">Vv. 1-7.No podemos juzgar el estado espiritual o eterno de nadie por la forma en que muere, porque en ésta, un mismo hecho ocurre para el justo y el impío.
Saúl no expresó preocupación por su alma eterna cuando estaba mal herido e incapaz de resistir o huir; sino sólo deseó que los filisteos no le insultaran ni le causaran dolor y se volvió en su propio asesino. Como el gran engaño del diablo es convencer a los pecadores, sometidos a grandes dificultades, que se refugien en este último acto de desesperación, bueno es fortalecer la mente contra esto, considerando seriamente su grave pecaminosidad ante Dios y sus consecuencias desgraciadas para la sociedad. Porque nuestra seguridad no está en nosotros mismos. Busquemos la protección del que guarda a Israel. Estemos alerta y orando; y pongámonos toda la armadura de Dios para soportar en el día malo y, habiendo hecho todo eso, resistir.</p>
<br/>
<p class="text-justify">Vv. 8-13.La Escritura no menciona qué pasó con las almas de Saúl y sus hijos después que murieron; sólo se refiere a sus cuerpos: las cosas secretas no nos corresponden. Tiene poca importancia saber por qué medios morimos o lo que se hace con nuestros cuerpos muertos. Si nuestras almas son salvas, nuestros cuerpos resucitarán incorruptibles y gloriosos; pero no temer su ira, que es capaz de destruir cuerpo y alma en el infierno, es la suprema necedad y maldad. ¡Qué inútil es el respeto de los congéneres de los que están sufriendo la ira de Dios! ¡Aunque funerales pomposos, grandes monumentos y alabanzas humanas honren la memoria del difunto, el alma puede estar sufriendo en las regiones de las tinieblas y la desesperación! ¡Procuremos aquel honor que sólo viene de Dios.</p>
<br/>




</div>
