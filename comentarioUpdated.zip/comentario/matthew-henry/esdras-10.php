<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Esdras 10</h2>
<p class="text-justify">Vv. 1-5.Secanías admitió la culpa nacional. El caso es triste pero no desesperado; la enfermedad es amenazante pero no incurable. Ahora que el pueblo empieza a lamentarse, parecer que es derramado un espíritu de arrepentimiento; ahora hay esperanza que Dios perdone y tenga misericordia. El pecado que rectamente nos perturba no nos destruirá. En momentos melancólicos debemos observar que está por nosotros como también que está en contra nuestra. Y puede que haya buenas esperanzas por medio de la gracia aun donde haya un sentido de gran culpa ante Dios.
El caso es simple: lo que se hizo mal debe deshacerse de nuevo en la mayor medida posible; nada menos que esto es el arrepentimiento verdadero. El pecado debe quitarse resueltos a no tener nunca nada más que hacer con eso. Lo que se ha obtenido injustamente, debe restaurarse. Levántate y ten buen ánimo. Llorar es bueno en este caso pero reformar es mejor. En cuanto a estar desigualmente uncido con incrédulos, tales matrimonios son ciertamente pecadores y no deben hacerse pero ahora no son nulos como lo eran antes que el evangelio terminara la separación de judíos y gentiles.</p>
<br/>
<p class="text-justify">Vv. 6-14.Hay esperanzas concernientes al pueblo cuando ellos estén convencidos de no sólo es bueno separarse de sus pecados sino que es necesario; debemos hacerlo o somos deshechos. Tan rica es la misericordia y tan abundante la redención de Dios que hay esperanza para el más vil que oiga el evangelio y esté dispuesto a aceptar la salvación gratuita.
Cuando los pecadores se lamentan de sus pecados y tiemblan a la palabra de Dios, hay esperanza que los abandonen. Para afectar a los demás con pena o amor santos para con Dios, debemos nosotros mismos estar afectados.
Se acordó cuidadosamente cómo debía realizarse este asunto. Eso que se resuelve apresuradamente rara vez resulta duradero.</p>
<br/>
<p class="text-justify">Vv. 15-44.Los mejores reformadores no pueden sino hacer su empresa; cuando el Redentor mismo venga a Sion efectivamente quitará la impiedad de Jacob. Cuando se arrepiente y se abandona el pecado Dios lo perdonará pero la sangre de Cristo, nuestra ofrenda por el pecado, es la única expiación que quita nuestra culpa. Ningún arrepentimiento o enmienda aparentes beneficiará a los que le rechazan a Él pues la dependencia de sí mismos les demuestra aún sin humillarse. Todos los nombres escritos en el libro de la vida son los de pecadores penitentes, no de personas con justicia propia que piensan que no necesitan arrepentirse.</p>
<br/>




</div>
