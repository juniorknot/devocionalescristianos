<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Jueces 15</h2>
<p class="text-justify">Vv. 1-8.Cuando hay diferencias entre familiares, cuéntense como los más sabios y los mejores, los que están más dispuestos a perdonar y a olvidar y se muestran más dispuestos a inclinarse y ceder en aras de la paz. En los medios que Sansón empleó debemos observar el poder de Dios para suplirlos, y hacerlos triunfar, para mortificar el orgullo y castigar la maldad de los filisteos. Estos amenazaron a la esposa de Sansón que la quemarían a ella y la casa de su padre. Para salvarse y hacerle un servicio a sus compatriotas, ella traicionó a su marido; y lo mismo que temía, y que procuró evitar pecando, ¡le sobrevino! Ella y la casa de su padre fueron quemadas con fuego y por sus compatriotas a quienes ella creyó servir con el mal que hizo a su esposo. El daño del cual procuramos escapar por prácticas ilícitas, a menudo lo acarreamos sobre nuestra cabeza.</p>
<br/>
<p class="text-justify">Vv. 9-17.El pecado deprime a los hombres y oculta de sus ojos las cosas que pertenecen a su paz. Los israelitas culparon a Sansón por lo que había hecho contra los filisteos como si les hubiera hecho un gran daño. De la misma manera, nuestro Señor Jesús hizo muchas obras buenas y por ellas los judíos estaban dispuestos a apedrearlo. Cuando el Espíritu del Señor descendió sobre Sansón, se soltaron sus cuerdas: donde está el Espíritu del Señor hay libertad y son verdaderamente libres quienes han sido así libertados. De este modo Cristo triunfó sobre las potestades de las tinieblas que clamaban en su contra, como si lo tuvieran en su poder.
Sansón ocasionó mucha destrucción entre los filisteos. Tomar el hueso de un asno para esto, era hacer maravillas con las cosas necias del mundo para que la excelencia del poder sea de Dios, no del hombre. Esta victoria no fue a causa del arma, ni por el brazo, sino en el Espíritu de Dios que movió el arma por medio del brazo. Podemos hacer todo por medio del que nos fortalece. Ved a un pobre cristiano capacitado para vencer una tentación por un consejo débil y frágil, y he ahí al filisteo vencido por una miserable quijada.</p>
<br/>




</div>
