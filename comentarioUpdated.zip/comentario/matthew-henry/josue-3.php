<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Josué 3</h2>
<p class="text-justify">Vv. 1-6.Los israelitas llegaron al Jordán con fe, habiéndoseles dicho que debían cruzarlo. En el camino del deber prosigamos tan lejos como podamos y dependamos del Señor. Josué los guiaba. Se nota en particular su levantada temprano, lo cual demuestra, como después en otras ocasiones, cuán poco buscaba él su propia comodidad. Aquellos que harán pasar grandes cosas, deben levantarse temprano. No ame el dormir, no sea que se empobrezca. Todos los que están en puestos públicos siempre deben atender al deber de su posición. El pueblo tenía que seguir al arca. Así, pues, nosotros debemos andar en todo conforme a la regla de la Palabra y a la dirección del Espíritu; así será la paz sobre nosotros, como sobre el Israel de Dios; pero debemos seguir a nuestros ministros solamente como ellos sigan a Cristo.
Todo el camino de ellos por el desierto fue una senda no hollada pero principalmente éste por el Jordán. Mientras estemos aquí debemos esperar y prepararnos para pasar por caminos que no pasamos antes; pero en la senda del deber podemos proceder con osadía y alegría. Sea que estemos llamados a sufrir pobreza, dolor, trabajos, persecución, reproche o muerte, estamos siguiendo al Autor y Consumador de nuestra fe; ni podemos sentar planta en ningún punto peligroso o difícil en todo nuestro viaje pues la fe verá allí las huellas de los pies del Redentor, que pasó por esa misma senda a la gloria en lo alto, y que nos llama a seguirle, para que donde Él está nosotros también podamos estar. Ellos tenían que santificarse. Si queremos experimentar los efectos del amor y poder de Dios, debemos abandonar al pecado y tener cuidado de no contristar al Espíritu Santo de Dios.</p>
<br/>
<p class="text-justify">Vv. 7-13.Las aguas del Jordán serán cortadas. Esto debe hacerse en forma tal que nunca se hizo, salvo al partir el Mar Rojo. Aquí se repite el milagro; Dios tiene el mismo poder para finalizar la salvación de Su pueblo como para empezarla; la Palabra del Señor estaba tan verdaderamente con Josué como con Moisés.
Las apariciones de Dios para Su pueblo debieran estimular la fe y la esperanza. La obra de Dios es perfecta, Él guardará a Su pueblo. La inundación del Jordán no pudo mantener fuera a Israel, la fuerza de Canaán no pudo hacerlos devolverse.</p>
<br/>
<p class="text-justify">Vv. 14-17. El Jordán anegaba todas sus riberas. Esto magnificaba el poder de Dios y Su bondad para con Israel. Aunque aquellos que se oponen a la salvación del pueblo de Dios tengan todas las ventajas, sin embargo, Dios puede vencer y lo hará.
Este cruce del Jordán, como entrada a Canaán, después de sus largos vagabundeos agotadores por el desierto, son una sombra del paso del creyente por la muerte camino al cielo, después que haya terminado su deambular por este mundo pecador. Jesús, tipificado por el arca, había ido adelante y cruzó el río cuando más inundaba el territorio que lo rodeaba. Atesoremos las experiencias de Su cuidado fiel y tierno para que podamos asistir a nuestra fe y esperanza en el conflicto final.</p>
<br/>




</div>
