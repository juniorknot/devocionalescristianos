<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Samuel 2</h2>
<p class="text-justify">Vv. 1-7.Después de morir Saúl, muchos se unieron a David en Siclag, 1 Crónicas xii, 22, pero él confió en Dios, que le prometió el reino, que se lo iba a dar a su tiempo y a su manera. Sin embargo, la segura esperanza de la promesa de Dios iniciará buenas empresas. Si yo fuese elegido para la corona de vida, no se sigue que, ‘entonces, no hago nada’sino, ‘entonces haré todo lo que Dios me mande’. Este buen uso hizo David de su elección y así actuarán todos los elegidos de Dios.
En todos nuestros viajes y cambios es consolador ver que Dios va delante nuestro; y podemos hacerlo, si por fe y la oración lo ponemos por delante de nosotros. Él dirigió el sendero de David conforme a la promesa. David ascendió paulatinamente: de esta manera, el reino del Mesías, el Hijo de David, se establece gradualmente; Él es el Señor de todo, pero aún no vemos todas las cosas sometidas a Él.</p>
<br/>
<p class="text-justify">Vv. 8-17.En general, la nación rechazó a David. Por este medio, preparó el Señor a su siervo para su futuro honor y utilidad; y quedó demostrada la tendencia de la verdadera piedad en su conducta, a pesar de experimentar diversas dificultades. David fue en esto un tipo de Cristo, porque Israel no se sometería a Él, aunque había sido ungido por el Padre para ser Príncipe y Salvador de ellos.
Abner quiso decir, que los jóvenes luchen delante de nosotros, cuando dijo “levántense ahora los jóvenes, y maniobren delante de nosotros”: así los necios se burlan del pecado. Pero es indigno de ser llamado humano el que puede jugar así con la sangre humana.</p>
<br/>
<p class="text-justify">Vv. 18-24.La muerte suele llegar por los caminos menos sospechados. ¡A menudo somos traicionados por las hazañas que nos enorgullecen! La velocidad de Asael, de la cual tanto presumía, no le sirvió; más bien apresuró su final.</p>
<br/>
<p class="text-justify">Vv. 25-32.Abner llama la atención a Joab sobre las malas consecuencias de una guerra civil. Quienes se toman a la ligera tales luchas antinaturales, hallarán que son amargura para todos los involucrados. ¡Cuán fácil es que los hombres usen la razón cuando les conviene, pero no la usan si les resulta inconveniente! -¡Véase cómo el curso de los acontecimientos altera el propósito de los hombres! Lo mismo que parecía grato en la mañana, por la noche se ve deprimente.
Los más dado a entablar una contienda, se arrepentirán antes que haya terminado, y hubiera sido mejor dejarla antes de meterse en ella, como aconseja Salomón. Esto vale para todo pecado: ¡oh, que los hombres consideraran a tiempo lo que al final traerá amargura! -Aquí se menciona el funeral de Asael. Aquí se hace distinción entre el polvo de algunos y el de otros, pero en la resurrección no habrá diferencia sino entre los santos y los impíos, la cual perdurará.</p>
<br/>




</div>
