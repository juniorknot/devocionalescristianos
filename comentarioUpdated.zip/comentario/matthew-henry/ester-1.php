<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Ester 1</h2>
<p class="text-justify">Vv. 1-9.El orgullo del corazón de Asuero se acrecienta con la grandeza de su reino y organiza una fiesta extravagante. Esto es vanagloria. Mejor es comer hierbas con tranquilidad que este banquete de vino con todo el bullicio y el tumulto que debe de haberle acompañado. Pero si la gracia no prevalece en el corazón, el principio rector será una u otra forma de la exaltación e indulgencia de sí mismo.
Pero nadie obliga, de modo que si alguien bebe excesivamente, es su propia falta. Esta precaución de un príncipe pagano, aunque demuestra su generosidad, puede avergonzar a muchos que se dicen cristianos que, con el pretexto de beber a la salud, beben pecado y con ello, la muerte. Este es un ¡ay! para los que hacen así; que lo lean y tiemblen, Habacuc ii, 15, 16.</p>
<br/>
<p class="text-justify">Vv. 10-22.La fiesta de Asuero termina mal por su propia necedad. Las temporadas de festividades peculiares suelen terminar en vejación. Los superiores debieran cuidarse de no mandar lo que razonablemente no pueda obedecerse. Pero cuando se ha ingerido vino, se va la razón de los hombres.
El que gobernaba 127 provincias no gobernaba su propio espíritu. Pero si la pasión o la política del rey fue servida con este decreto, la providencia de Dios abrió el camino a Ester hacia la corona y derrotó el malvado proyecto de Amán, aun antes que entrara en su corazón y accediera al poder. Regocijémonos que el Señor reina y vence la locura o necedad de la humanidad, para promover su propia gloria y la seguridad y felicidad de su pueblo.</p>
<br/>




</div>
