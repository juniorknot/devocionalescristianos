<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Números 12</h2>
<p class="text-justify">Vv. 1-9.La paciencia de Moisés fue probada en su propia familia como asimismo por el pueblo. El pretexto fue que se había casado con una extranjera; pero probablemente el orgullo de ellos había sido herido y excitada la envidia por su mayor autoridad. La oposición de nuestros familiares cercanos y de los amigos religiosos es sumamente dolorosa. Pero hay que tener esto en consideración y será bueno que en tales circunstancias podamos conservar la bondad y la mansedumbre de Moisés, el cual estaba de ese modo equipado para la obra a que estaba llamado. Dios no sólo declaró inocente a Moisés, sino que lo elogió. Moisés tenía el espíritu de profecía en un grado que lo coloca muy por encima de todos los otros profetas; pero aquel que es el menor en el reino de los cielos es mayor que él; y nuestro Señor Jesús lo excede infinitamente, Hebreos iii, 1.
Que María y Aarón consideren a quien era que insultaban. Nosotros tenemos motivos para temer de decir o hacer algo contra los siervos de Dios. Indudablemente son presuntuosos quienes no temen hablar mal de las potestades superiores, 2 Pedro ii, 10. Ser quitados de la presencia de Dios es la señal más cierta y triste del desagrado de Dios. ¡Ay de nosotros si Él se aparta! Él nunca se aleja hasta que por el pecado y la necedad nosotros lo alejamos.</p>
<br/>
<p class="text-justify">Vv. 10-16.La nube se apartó, y María se puso leprosa. Cuando Dios se va, llega el mal: no esperéis el bien cuando Dios se va. La inmunda lengua de ella, como dice el obispo Hall, fue justamente castigada con rostro inmundo.
Aarón, como sacerdote, era el juez de la lepra. Él no podía declararla leprosa sin temblar, sabiendo que él mismo era igualmente culpable. Pero si ella fue de esa manera castigada por hablar contra Moisés, ¿qué va a ser de quienes pecan contra Cristo? Aarón, que se unió a su hermana para hablar contra Moisés, se ve forzado por sí mismo y su hermana, a suplicar y hablar con altura de aquel a quien habían tan recientemente culpado. Quienes pisotean a los santos y siervos de Dios, un día se alegrarán de ser parte de su séquito. Bueno es cuando la reprensión produce confesión de pecado y arrepentimiento. Tales ofensores, aunque derrotados y deshonrados, serán perdonados.
Moisés hizo evidente que él perdonaba la injuria infligida. Debemos conformarnos a esta pauta de Moisés y a la de nuestro Salvador que dijo: “Padre, perdónalos”.
Se da una razón para el alejamiento de María del campamento por siete días, porque de esa manera ella debía aceptar el castigo de su pecado. Cuando estamos bajo la señal del desagrado de Dios por el pecado, nos corresponde aceptar la vergüenza. Esto obstaculizó el avance del pueblo en su marcha hacia Canaán. Muchas cosas se nos oponen, pero nada nos estorba tanto en el camino al cielo como el pecado.</p>
<br/>




</div>
