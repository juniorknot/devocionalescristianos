<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Reyes 3</h2>
<p class="text-justify">Versículos 1-5. Joram, rey de Israel.6-19. Guerra con Moab-La intercesión de Eliseo.20-27. Provisión de agua-Moab vencido.</p>
<br/>
<p class="text-justify">Vv. 6-19.El rey de Israel lamenta la angustia de ellos y el peligro en que estaban. Él convocó a los tres reyes, pero lo cargó a la Providencia. Así la insensatez del hombre tuerce su camino y, luego contra Jehová se irrita su corazón, Proverbios xix, 3.
Bueno fue que Josafat consultara al Señor ahora, pero hubiera sido mucho mejor si lo hubiera hecho antes de meterse en esta guerra. A veces los hombres buenos descuidan su deber hasta que la necesidad y la aflicción los impele a ello. La gente mala suele andar mejor por la amistad con los buenos y su asociación con ellos.
Eliseo les dice, para probar la fe y obediencia de ellos, que caven zanjas en el valle para recibir agua. Los que esperan las bendiciones de Dios deben cavar cisternas para que la lluvia las llene, como en el valle de Baca y, así, hacer un estanque para ellas, Salmo lxxxiv, 6. No tenemos que preguntar de dónde vino el agua. Dios no está atado a causas secundarias. Quienes sinceramente buscan el rocío de la gracia de Dios, lo tendrán y será hechos más que vencedores.</p>
<br/>
<p class="text-justify">Vv. 20-27.Es una bendición ser favorecido con la compañía de quienes tienen poder de Dios y pueden predominar por sus oraciones. Un reino puede ser sostenido y prosperar como consecuencia de las oraciones fervorosas de quienes son amados por Dios. Demos nuestra más alta consideración a los que son preciosos a sus ojos.
Cuando los pecadores dicen, paz, paz, les sobreviene la destrucción: la desesperación seguirá a su loca presunción. Al servicio de Satanás, y por sugerencia de éste, se han hecho obras tan horrendas que hacen que se estremezcan los sentimientos naturales del corazón; como el rey de Moab que sacrificó a su hijo. Bueno es no estimular lo peor de los hombres a extremos; más bien, debemos dejarlos al juicio de Dios.</p>
<br/>




</div>
