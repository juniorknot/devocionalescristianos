<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Joel 3</h2>
<p class="text-justify">Vv. 1-8.Aquí se predice la restauración de los judíos y la victoria final de la religión verdadera sobre todos sus enemigos. Se comenta el desprecio y la burla con que los judíos han sido frecuentemente tratados como pueblo, y el poco valor dado a ellos. Nadie que haya endurecido su corazón contra Dios y contra su Iglesia ha prosperado por mucho tiempo.</p>
<br/>
<p class="text-justify">Vv. 9-17.He aquí un reto para todos los enemigos del pueblo de Dios. No hay escapatoria de los juicios de Dios; los pecadores encallecidos serán cortados de todo consuelo y gozo en el día de la ira.
La mayoría de los profetas predijeron la misma victoria final de la Iglesia de Dios sobre todo lo que se le opusiera. Para el impío será un día terrible, pero para el justo será un día de júbilo. ¡Qué causa tienen los que poseen un interés en Cristo para gloriarse en quien es su Fuerza y su Redentor! El año aceptable del Señor, un día de tan grande favor para algunos, será un día de terrible venganza para otros; despierte quien esté fuera de Cristo y huya de la ira venidera.</p>
<br/>
<p class="text-justify">Vv. 18-21.Habrá abundantes influencias divinas y el evangelio se difundirá rápidamente a los confines más remotos de la tierra. Esos sucesos están anunciados bajo emblemas significativos; hay un día que viene en que toda cosa mala será enmendada. La fuente de esta abundancia está en la casa de Dios, desde donde comienzan los arroyos. Cristo es la Fuente; sus sufrimientos, sus méritos y su gracia, limpian, refrescan y fertilizan. La gracia del evangelio, fluyendo desde Cristo, llegará al mundo gentil, a las regiones más remotas, y las hará abundar en frutos de justicia; y desde la casa del Señor de lo alto, desde su templo celestial, fluye todo el bien que saboreamos diariamente y esperamos disfrutar eternamente.</p>
<br/>




</div>
