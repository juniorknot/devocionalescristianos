<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Proverbios 16</h2>
<p class="text-justify">V. 1.Solo la gracia renovadora de Dios prepara el corazón para toda buena obra. Esto nos enseña que no somos suficientes por nosotros mismos para pensar o decir algo que sea sabio y bueno.</p>
<br/>
<p class="text-justify">V. 2.La ignorancia, el orgullo y la jactancia nos vuelven jueces parciales respecto de nuestra propia conducta.</p>
<br/>
<p class="text-justify">V. 3.Descarga el peso de tu afán en Dios y déjalo con Él, por fe y confianza en Él.</p>
<br/>
<p class="text-justify">V. 4.Dios usa al impío para ejecutar la justa venganza de uno contra el otro; y al final, Él será glorificado por la destrucción de ellos.</p>
<br/>
<p class="text-justify">V. 5.Aunque los pecadores se fortalecen a sí mismos y unos a otros, no escaparán de los juicios de Dios.</p>
<br/>
<p class="text-justify">V. 6.Por la misericordia y la verdad de Dios en Cristo Jesús, los pecados de los creyentes son quitados y quebrantado el poder del pecado.</p>
<br/>
<p class="text-justify">V. 7.Aquel que tiene todos los corazones en su mano, puede hacer que los enemigos de un hombre estén en paz con éste.</p>
<br/>
<p class="text-justify">V. 8.Un patrimonio pequeño honestamente logrado, resultará mejor cuenta que un patrimonio grande logrado a la mala.</p>
<br/>
<p class="text-justify">V. 9.Si los hombres hacen de la gloria de Dios su fin, y de su voluntad su regla, Él dirigirá sus pasos por su Espíritu y su gracia.</p>
<br/>
<p class="text-justify">V. 10.Que los reyes y jueces de la tierra sean justos y gobiernen en el temor de Dios.</p>
<br/>
<p class="text-justify">V. 11.Observar justicia en los tratos entre los hombres es designio de Dios.</p>
<br/>
<p class="text-justify">V. 12.El rey que usa bien su poder verá que es su mejor seguridad.</p>
<br/>
<p class="text-justify">V. 13.Poned en el poder a los que saben hablar acerca del propósito.</p>
<br/>
<p class="text-justify">Vv. 14, 15.Necios son los que se apartan del favor de Dios para obtener el favor de un príncipe terrenal.</p>
<br/>
<p class="text-justify">V. 16.Hay gozo y satisfacción del espíritu sólo en lograr sabiduría.</p>
<br/>
<p class="text-justify">V. 17.El hombre sinceramente religioso se mantiene lejos de toda apariencia de mal. Dichoso el hombre que anda en Cristo y es dirigido por el Espíritu de Cristo.</p>
<br/>
<p class="text-justify">V. 18.Cuando los hombres desafían los juicios de Dios, y creen que están lejos de ellos, es señal de que se hallan a la puerta. No temamos el orgullo del prójimo; temamos el orgullo en nosotros mismos.</p>
<br/>
<p class="text-justify">V. 19.Aunque se exponga al desprecio del mundo, la humildad es mucho mejor que la altivez de espíritu, que hace enemigo a Dios. El que entiende la palabra de Dios, encontrará el bien.</p>
<br/>
<p class="text-justify">V. 21.El hombre cuya sabiduría habita en su corazón, será hallado mucho más prudente que muchos que poseen talentos brillantes.</p>
<br/>
<p class="text-justify">V. 22.Como agua para tierra reseca es el hombre sabio para sus amistades y vecinos.</p>
<br/>
<p class="text-justify">V. 23.El conocimiento propio del hombre sabio siempre sugiere algo apropiado para decir a los demás.</p>
<br/>
<p class="text-justify">V. 24.La palabra de Dios cura las enfermedades que debilitan nuestra alma.</p>
<br/>
<p class="text-justify">V. 25.Esto es advertencia para todos: cuidar de engañarse a sí mismos y a sus almas.</p>
<br/>
<p class="text-justify">V. 26.Debemos trabajar por la comida que permanece para la vida eterna o perecer.</p>
<br/>
<p class="text-justify">Vv. 27, 28.Los impíos realizan más esfuerzos para hacer el mal de los que serían necesarios para hacer el bien. ¡El chismoso separa a las amistades; qué carácter odioso, pero cuán común es!</p>
<br/>
<p class="text-justify">Vv. 29, 30.Algunos hacen todo el mal que pueden por la fuerza y la violencia, y están ciegos en cuanto al resultado.</p>
<br/>
<p class="text-justify">V. 31.La gente anciana debiera ser especialmente hallada en el camino de la religión y la santidad.</p>
<br/>
<p class="text-justify">V. 32.Vencer nuestras pasiones requiere una administración más firme que para obtener la victoria sobre un enemigo.</p>
<br/>
<p class="text-justify">V. 33.Todos los ordenamientos de la Providencia acerca de nuestros asuntos, debemos considerarlos como determinantes de lo que referimos a Dios; y debemos reconciliarnos con ellos en forma consecuente. Benditos sean los que se entregan a la voluntad de Dios, porque Él sabe lo que es bueno para ellos.</p>
<br/>




</div>
