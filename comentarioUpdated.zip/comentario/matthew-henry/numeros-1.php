<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Números 1</h2>
<p class="text-justify">Vv. 1-43.Se censó al pueblo para mostrar la fidelidad de Dios al aumentar la descendencia de Jacob, para que ellos fuesen los mejores entrenados para las guerras y la conquista de Canaán, y para organizar a las familias con miras al reparto de la tierra. Se dice que se censaron de cada tribu los que eran capaces de ir a la guerra; tenían guerras por delantes aunque ahora no hallaran oposición. Que el creyente sea preparado para resistir a los enemigos de su alma aunque todo parezca estar en paz.</p>
<br/>
<p class="text-justify">Vv. 44-46.Aquí tenemos la suma total. ¡Cuánto se necesitaba para mantener a todos estos en el desierto! Todos eran satisfechos por Dios cada día. Cuando observamos la fidelidad de Dios, por improbable que parezca el cumplimiento de Su promesa, podemos cobrar valor con respecto a las promesas que aún tienen que ser cumplidas para la iglesia de Dios.</p>
<br/>
<p class="text-justify">Vv. 47-54.Aquí se cuida de distinguir a la tribu de Leví que se había distinguido por sí misma en el asunto del becerro de oro. Los servicios singulares serán recompensados con honores singulares. Fue para honor de los levitas que se les encomendara el cuidado del tabernáculo y sus tesoros en sus campamentos y marchas. Fue para honor de las cosas sagradas que nadie las viera ni las tocara sino los llamados por Dios al servicio. Todos somos ineptos e indignos de tener comunión con Dios, hasta que seamos llamados por Su gracia a la comunión de Su Hijo Jesucristo, nuestro Señor; y de ese modo, siendo la descendencia espiritual de este gran Sumo Sacerdotre, seamos hechos sacerdotes para nuestro Dios. Debe tenerse sumo cuidado en evitar el pecado pues evitar el pecado es evitar la ira. Los levitas no fueron contados con los demás israelitas por ser una tribu santa. Los que ministran cosas sagradas no deben enredarse ni ser enredados en los asuntos mundanos. Y que cada creyente procure hacer lo que el Señor ha mandado.</p>
<br/>




</div>
