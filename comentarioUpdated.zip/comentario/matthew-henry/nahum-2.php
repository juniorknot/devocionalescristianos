<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Nahum 2</h2>
<p class="text-justify">Vv. 1-10.Nínive no desechará este juicio; no hay consejo ni fuerza contra el Señor. Dios mira la ciudad orgullosa, y la derriba.
Se da un recuento particular de los terrores con que el enemigo invasor vendrá contra Nínive. El imperio de Asiria es representado como una reina por ser llevada cautiva a Babilonia. La culpa de la conciencia llena de terror a los hombres en el día malo; ¿y qué harán los tesoros o la gloria por nosotros en momentos de angustia o en el día de la ira? Pero, por tales cosas, ¡cuántos pierden su alma!</p>
<br/>
<p class="text-justify">Vv. 11-13.Los reyes de Asiria habían sido terribles y crueles con sus vecinos durante mucho tiempo, pero el Señor destruirá su poder. Muchos alegan como excusa para la rapiña y el fraude que tienen familias que mantener, pero lo que así se obtiene nunca les hará ningún bien. Los que temen al Señor y obtienen honestamente lo que tienen, no tendrán necesidades ellos mismos ni los suyos. Justo es que Dios prive de hijos o del consuelo de ellos a los que siguen rumbos pecaminosos para enriquecerse. No son dignos de ser oídos de nuevo los que han hablado reprochando a Dios. Entonces, vamos a Dios en su trono de la gracia, que teniendo paz con Él por nuestro Señor Jesucristo, podemos saber que está por nosotros, y que todas las cosas ayudarán a bien para nuestra eterna bienaventuranza.</p>
<br/>




</div>
