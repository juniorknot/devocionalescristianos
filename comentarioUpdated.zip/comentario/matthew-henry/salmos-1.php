<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Salmos 1</h2>
<p class="text-justify">Vv. 1-3.Meditar en la palabra de Dios es discurrir con nosotros mismos acerca de las grandes cosas en ella contenidas, con una íntima aplicación de la mente y concentración en el pensar. Debemos referirnos constantemente a la palabra de Dios como regla de nuestras acciones, y fuente de nuestro consuelo; y hemos de tenerla en nuestros pensamientos noche y día. Con este propósito no hay momento que no sea oportuno.</p>
<br/>
<p class="text-justify">Vv. 4-6.Los impíos son el revés de los justos, tanto en carácter como en estado. Los impíos no son así , versículo 4; son guiados por el consejo del malo, por el camino de los pecadores hacia la sede del escarnecedor; no se deleitan en la ley de Dios; no dan fruto, sino lo que es malo. Los justos son como árboles fértiles y útiles: los impíos son como tamo que el viento se lleva; el polvo que el dueño del suelo desea eliminar, porque no sirve para nada. No son valiosos según Dios, por muy alto que se valoren a sí mismos. Son fácilmente llevados de aquí para allá por todo viento de tentación. La cizaña puede estar entre el trigo por un tiempo pero con la hoz aguda en su mano viene Aquel que purgará cabalmente su suelo. Quienes, por su propio pecado y necedad son como cizaña, se encontrarán ante el torbellino y el fuego de la ira divina. El destino del impío está fijado, pero cada vez que el pecador se sensibiliza en cuanto a su culpa y miseria, puede ser admitido por Cristo, el camino vivo, en la compañía de los justos y llegar a ser nueva criatura en Cristo. Ahora tiene nuevos deseos, nuevos placeres, esperanzas, temores, penas, compañías y ocupaciones. Sus pensamientos, palabras y acciones son cambiados. Entra en un nuevo estado y tiene un carácter nuevo. He aquí, todas las cosas son hechas nuevas por la gracia divina, que cambia su alma a la imagen del Redentor. ¡Cuán diferente es el carácter y el final del impío!</p>
<br/>




</div>
