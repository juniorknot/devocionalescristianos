<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Esdras 1</h2>
<p class="text-justify">Vv. 1-4.El Señor despertó el espíritu de Ciro. Los corazones de los reyes están en la mano del Señor. Dios gobierna al mundo por su influencia en los espíritus de los hombres; cualesquiera sea el bien que hagan, Dios estimula sus espíritus para hacerlo.
Durante el cautiverio de los judíos, Dios los empleó principalmente como medio para llamar la atención de los paganos hacia Él.
Ciro dio por sentado que entre los judíos capaces, habría quienes ofrecieran de su libre voluntad ofrendas para la casa de Dios. Él también haría que los abastecieran desde su reino. Los que desean bien para el Templo, deben ser los benefactores del Templo.</p>
<br/>
<p class="text-justify">Vv. 5-11.El mismo Dios que despertó el espíritu de Ciro para proclamar la libertad a los judíos, despertó sus espíritus para aceptar el beneficio. La tentación de algunos fue quedarse en Babilonia, pero otros temían no retornar y fueron sus espíritus los que levantó Dios, por su Espíritu y gracia. Cualquiera sea el bien que hagamos, se debe a la gracia de Dios. Nuestro espíritu por naturaleza se inclina hacia esta tierra y a sus cosas; si se mueven hacia lo alto, en cualquier buen afecto o buena acción, es Dios que los levanta.
Las llamadas y ofrendas del evangelio son como la proclama de Ciro. Los que están atados por el poder del pecado pueden ser libertados por Jesucristo. A quien desee, arrepentido y por fe, volver a Dios, Jesucristo le abre el camino y le eleva de la esclavitud del pecado a la gloriosa libertad de los hijos de Dios. Muchos de los que oyen este sonido alegre optan por quedarse quietos en Babilonia, enamorados de sus pecados no se aventuran a una vida santa; pero algunos irrumpen por entre todos los desalientos, cualquiera sea el costo; esos son los espíritus que Dios ha levantado por encima del mundo y la carne, a quienes Él ha dado una buena disposición. Así se llenará la Canaán celestial, aunque muchos perezcan en Babilonia; y la ofrenda del evangelio no habrá sido en vano. Traer de vuelta a los judíos del cautiverio representa la redención de los pecadores hecha por Jesucristo.</p>
<br/>




</div>
