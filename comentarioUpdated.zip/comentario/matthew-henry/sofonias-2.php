<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Sofonías 2</h2>
<p class="text-justify">Vv. 1-3.El profeta llama al arrepentimiento nacional como único camino para impedir la ruina nacional. La nación que no desea , que no tiene deseos de Dios, no está deseosa de su favor y su gracia, no tiene intenciones de arrepentirse ni reformarse. O, no deseable , no tiene nada que la recomiende a Dios; a quien Dios puede con justicia decir, Apártate de mí; pero les dice, Congregaos para que podáis buscar mi rostro. Sabemos lo que traerá el decreto de Dios contra los pecadores impenitentes, por tanto, debe preocuparnos mucho el arrepentirnos en el tiempo aceptable. ¡Cuán cuidadosos debemos ser todos para buscar la paz con Dios antes que el Espíritu Santo se vaya de nosotros, o cese de contender con nosotros; antes que se acabe el día de gracia o el día de vida; ¡antes que nuestro estado eterno sea determinado! Que el pobre, despreciado y afligido busque al Señor, y procure entender y obedecer mejor sus mandamientos, que sean más humillados por sus pecados. La principal esperanza de liberación de los juicios nacionales descansa en la oración.</p>
<br/>
<p class="text-justify">Vv. 4-15.Realmente están en un estado lamentable los que tienen en contra la palabra de Dios, porque ninguna palabra suya caerá al suelo. Dios restaurará a su pueblo a sus derechos, aunque les han sido retenidos por mucho tiempo. Ha sido la suerte corriente del pueblo de Dios de todas las épocas ser reprochados e injuriados.
Dios será adorado no sólo por todo Israel y los extranjeros que se les unan, sino por los paganos.
Las naciones remotas deben ser tratadas por los males hechos al pueblo de Dios. Los sufrimientos del insolente y altivo en prosperidad no son compadecidos ni lamentados. Pero todas las desolaciones de las naciones florecientes harán camino para la caída del reino de Satanás. Mejoremos nuestras ventajas y esperemos el cumplimiento de cada promesa, orando que el nombre de nuestro Padre sea santificado por doquiera sobre toda la tierra.</p>
<br/>




</div>
