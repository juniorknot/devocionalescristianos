<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Rut 4</h2>
<p class="text-justify">Vv. 1-8.Toda la cuestión dependía de las leyes dadas por Moisés sobre la herencia e indudablemente, todo fue arreglado de la manera regular y legal. El pariente rechazó la oferta cuando supo las condiciones. En forma parecida muchos rechazan la gran redención; no están dispuestos a esposar la religión; han oído buenas cosas de ella y nada tienen que decir en su contra; hablan bien de ella pero están dispuestos a desligarse de ella, y no quieren unirse a ella por miedo de perder su propia herencia en este mundo.
Renunció a su derecho en favor de Booz. El trato justo y honesto en todos lo referente a contratos y negocios es algo de lo que deben tomar conciencia todos los que se reconocen como verdaderos israelitas, en quienes no hay engaño. Hallarán que la mejor política es la honestidad.</p>
<br/>
<p class="text-justify">Vv. 9-12.Los hombres están dispuestos a aprovechar las oportunidades de aumentar su fortuna, pero pocos conocen el valor de la piedad. Tales son los sabios de este mundo a quienes el Señor acusa de necedad. Ellos no se preocupan de la necesidad de su alma y rechazan la salvación de Cristo por temor de perder su herencia. Pero Dios dio a Booz la honra de incluirlo en el linaje del Mesías, mientras del pariente que temió rebajarse y perder su herencia, se olvidó su nombre, familia y herencia.</p>
<br/>
<p class="text-justify">Vv. 13-22.Rut tuvo un hijo a través del cual nacieron miles y miríadas para Dios; parte del linaje de Cristo, fue instrumento para la felicidad de todos los que serán salvados por Él: nosotros los gentiles y los de origen judío. Ella fue un testigo ante el mundo gentil de que Dios no los había desamparado del todo sino que, a su debido tiempo, llegarían a ser uno con su pueblo escogido y partícipes de su salvación. La oración a Dios estuvo presente en el matrimonio y la alabanza asistió al nacimiento del niño. ¡Qué pena que ese lenguaje piadoso ya no se use entre los cristianos o que se le haya dejado para caer en el formalismo! -Aquí está el linaje de David por parte de Rut. Vino el tiempo en que Belén de Judá exhibió maravillas más grandes que las de la historia de Rut, cuando de otra pobre mujer de la misma raza nació el bebé despreciado, que dirigió los consejos del amo romano del mundo e hizo venir a príncipes y sabios del oriente, para poner tesoros de oro, mirra e incienso a sus pies. Su nombre permanecerá por siempre y todas las naciones le dirán bendito. En esa Simiente será benditas todas las naciones de la tierra.</p>
<br/>




</div>
