<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 17</h2>
<p class="text-justify">Vv. 15-22.Aquí se hace a Abraham la promesa de un hijo con Sarai, en el cual se cumpliría la promesa hecha. La prenda de esta promesa fue el cambio del nombre de Sarai a Sara. Sarai significa mi princesa , como si su honor estuviera limitado a una sola familia; Sara significa una princesa. Mientras más favores Dios nos otorgue, más debemos rebajarnos a nuestros propios ojos.
Abraham demostró gran gozo; se rió, era una risa de alegría, no de desconfianza. Ahora era que Abraham se gozó de que habría de ver el día de Cristo; ahora lo vio y se gozó, Juan viii, 56.
Temiendo que Ismael fuera abandonado y dejado de Dios, Abraham hizo una petición a su favor. Dios nos da permiso para que cuando oramos seamos específicos en nuestras peticiones. Cualesquiera sean nuestras preocupaciones y temores, deben ser expuestos ante Dios en oración. Los padres tienen el deber de orar por sus hijos, y lo más grande que debiéramos desear es que ellos sean guardados en su pacto, y que puedan tener la gracia de andar con él en justicia.
A Ismael se le garantizan las bendiciones comunes . Los hijos de padres piadosos nacidos en la carne suelen recibir buenas cosas exteriores, por amor a sus padres. Las bendiciones del pacto están reservadas para Isaac y él toma posesión de ellas.</p>
<br/>
<p class="text-justify">Vv. 23-27.Abraham y toda su familia fueron circuncidados recibiendo así la señal del pacto y se distinguieron de otras familias que no tenían arte ni parte en el asunto. Fue obediencia implícita ; él hizo como Dios le mandó sin preguntar por qué ni para qué. Lo hizo porque Dios se lo ordenó. Fue obediencia pronta ; en el mismo día. La obediencia sincera no demora. No sólo las doctrinas de la revelación sino los sellos del pacto de Dios nos recuerdan que somos pecadores culpables corruptos. Nos muestran la necesidad de la sangre de la expiación; apuntan al Salvador prometido y nos enseñan a ejercer la fe en él. Nos muestran que sin la regeneración, la santificación por su Espíritu y la mortificación de nuestras inclinaciones carnales y corruptas, no podemos estar en el pacto con Dios. Pero recordemos que la circuncisión verdadera es la del corazón, por el Espíritu, Romanos ii, 28, 29. Bajo ambas dispensaciones, la antigua y la nueva, muchos han hecho la profesión exterior y han recibido el sello sin haber sido sellados nunca por el Espíritu Santo de la promesa.</p>
<br/>




</div>
