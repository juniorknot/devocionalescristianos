<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Proverbios 2</h2>
<p class="text-justify">Vv. 1-9.Quienes buscan fervorosamente la sabiduría celestial nunca se quejarán de haber perdido su esfuerzo; la libertad del don no elimina la necesidad de nuestra diligencia, Juan vi, 27.
Buscad y hallaréis; pedid y se os dará. Obsérvese a los que así son favorecidos. Ellos son los justos, en quienes es renovada la imagen de Dios que consiste en justicia. Si dependemos de Dios y vamos en pos de la sabiduría, Él nos capacitará para guardar las sendas del juicio.</p>
<br/>
<p class="text-justify">Vv. 10-22.Si somos verdaderamente sabios tendremos cuidado para evitar a toda mala compañía y las malas costumbres. Cuando la sabiduría nos domina, entonces no sólo llena la cabeza; entra en el corazón, y preserva contra las corrupciones de adentro y de las tentaciones de afuera.
Los caminos del pecado con caminos de tinieblas, incómodos e inseguros; ¡qué necios son los que dejan las sendas sencillas, placenteras e iluminadas de la rectitud para andar en semejantes caminos! Ellos se complacen en el pecado; en cometerlo y ver que los demás lo cometen. Todo hombre sabio evitará tal compañía. La sabiduría verdadera también preservará de quienes guían a las lujurias carnales que corrompen el cuerpo, ese templo vivo, y que batallan contra el alma. Estos son males que excitan la tristeza de toda mente seria y hacen que cada padre o madre reflexivo mire a sus hijos con ansiedad, no sea que ellos se enreden en tales trampas fatales. Que el sufrimiento del prójimo nos sirva de advertencia. Nuestro Señor Jesús disuade de esos placeres pecaminosos por los tormentos eternos que les siguen. Muy raro es que se recupere alguien que está agarrado en esta trampa del diablo; tan endurecido está el corazón, tan ciega la mente por el engaño de este pecado.
Muchos piensan que esta advertencia, además de su sentido literal, debe entenderse como advertencia contra la idolatría, y someter el alma al cuerpo, en la búsqueda de cualquier objeto prohibido.
El justo debe dejar la tierra como el malo, pero la tierra es cosa muy diferente para ellos. Para el malo es todo el cielo que tendrán jamás; para el justo es el lugar de preparación para el cielo. ¿Es toda una para nosotros, sea que la compartamos con el malo las miserias de su fin postrero o con el deleite eternos que coronará a los creyentes?</p>
<br/>




</div>
