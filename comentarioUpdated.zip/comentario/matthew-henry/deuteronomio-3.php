<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Deuteronomio 3</h2>
<p class="text-justify">Vv. 1-11.Og era muy poderoso, pero no se dio por advertido con la destrucción de Sehón, y no pidió condiciones de paz. Confió en su propia fuerza y, de ese modo, se endureció para su propia destrucción. Quienes no son alertados por los juicios de Dios contra los demás, esperan el momento oportuno para que les sobrevengan juicios semejantes.</p>
<br/>
<p class="text-justify">Vv. 12-20.Este territorio fue poblado por las tribus de Rubén, Gad y la media tribu de Manasés: véase Números xxxii. Moisés repite la condición de la cesión que habían acordado. Cuando tengamos reposo debiéramos desear también el reposo para nuestros hermanos, y estar dispuestos a hacer lo que podamos en ese sentido; porque no nacemos para nosotros mismos, sino somos miembros los unos de los otros.</p>
<br/>
<p class="text-justify">Vv. 21-29.Moisés dio aliento a Josué que iba a sucederlo. De este modo, el anciano y experto en el servicio de Dios debiera hacer todo lo que puede para fortalecer las manos de los jóvenes y principiantes en la fe. Considérese lo que Dios ha hecho, lo que Dios ha prometido. Si Dios está por nosotros, ¿quién podrá vencernos? Nosotros somos un reproche para nuestro Capitán, si lo seguimos con temblor.
Moisés oró que si era la voluntad de Dios, Él iría delante de Israel para atravesar el Jordán y entrar a Canaán. No debemos permitir en nuestro corazón deseos que no podamos por fe ofrendar a Dios en oración. La respuesta de Dios a esta oración fue una mezcla de misericordia y juicio. Dios considera bueno negar muchas cosas que deseamos. Puede aceptar nuestras oraciones, pero no concedernos precisamente aquello por lo cual oramos. Si Dios, en su providencia, no nos da lo que deseamos, pero por su gracia hace que estemos contentos sin eso, el resultado viene a ser lo mismo. Contentaos con tener a Dios como vuestro Padre, y el cielo por porción vuestra, aunque no tengáis todo lo que quisiérais en este mundo.
Dios prometió a Moisés que vería Canaán desde la cumbre del Pisga. Aunque él no tendría la posesión de ella, tendría una visión panorámica. Hasta los grandes creyentes en el estado presente ven el cielo, pero en lontananza.
Dios le proveyó un sucesor. Es consolador para los amigos de la iglesia de Cristo que la obra de Dios tenga la probabilidad de ser continuada por otros, cuando ello descansen silenciosos en el polvo. Y si tenemos las arras y la visión del cielo, que nos basten; sometámonos a la voluntad del Señor y no le hablemos más de asuntos que Él considera bueno no concedernos.</p>
<br/>




</div>
