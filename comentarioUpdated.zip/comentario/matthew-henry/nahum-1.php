<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Nahum 1</h2>
<p class="text-justify">Vv. 1-8.Unos cien años antes, por la prédica de Jonás, los ninivitas se arrepintieron y fueron perdonados, pero, pronto después, empeoraron más que nunca. Nínive no conoce a Dios que contiende con ella, pero le dicen qué Dios es. Bueno es que todos mezclen fe con lo que aquí se dice acerca de Él, que debiera comunicar gran terror al impío, y consuelo a los creyentes. Cada uno tome su porción de aquí: que los pecadores lean y tiemblen; que los santos lean y triunfen.
La ira de Jehová se pone en contraste con su bondad para con su pueblo. Quizá sean oscuros y poco considerados en el mundo, pero el Señor los conoce.
El carácter escritural de Jehová no concuerda con los criterios de los racionalistas orgullosos. El Dios y Padre de nuestro Señor Jesucristo es lento para la ira y presto para perdonar, pero de ninguna manera dará por inocente al impío; hay tribulación y angustia para toda alma que hace el mal: ¿pero quién considera debidamente el poder de su ira?</p>
<br/>
<p class="text-justify">Vv. 9-15.Hay una tremenda confabulación contra el Señor y contra su reino en este mundo, armada por las puertas del infierno; pero resultará en vano. Con algunos pecadores Dios hace consumación rápida; y de una u otra manera, exterminará a todos sus enemigos. Aunque estén quietos y muy seguros, y sin temor, serán cortados como pasto y trigo cuando pase el ángel exterminador. Dios obrará así una gran liberación para su pueblo. Pero a los que se envilecen por pecados escandalosos, Dios los envilecerá por castigos vergonzosos.
Las noticias de esta gran liberación serán bien recibidas, con mucho gozo. Estas palabras se aplican a la gran redención obrada por nuestro Señor Jesús, el eterno evangelio, Romanos x, 15. Mensajeros de la buena nueva son los ministros de Cristo que predican paz por Jesucristo. ¡Cuán bienvenidos son quienes ven su miseria y peligro por el pecado! La promesa que hacen en el día del mal debe ser cumplida. Agradezcamos las ordenanzas de Dios y participemos alegremente en ellas. Miremos adelante con jubilosa esperanza a un mundo donde el impío nunca puede entrar, y el pecado y la tentación ya no serán más conocidas.</p>
<br/>




</div>
