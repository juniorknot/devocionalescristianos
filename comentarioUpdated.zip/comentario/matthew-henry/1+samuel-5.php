<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Samuel 5</h2>
<p class="text-justify">Vv. 1-5.Nótese el triunfo del arca sobre Dagón. Ciertamente así caerá el reino de Satanás delante del reino de Cristo, el error ante la verdad, lo profano ante lo piadoso y la corrupción ante la gracia, en el corazón del fiel. Cuando el interés por la religión parecen a punto de hundirse, aun entonces podemos confiar en que vendrá el día de su triunfo. Cuando Cristo, el Arca verdadera del pacto, entra realmente en el corazón del hombre caído, que indudablemente es templo de Satanás, todos los ídolos caen, todo esfuerzo para ponerlos de nuevo en pie será vano, el pecado será abandonado, y se hará restitución de toda ganancia injusta; el Señor reclamará el trono y tomará posesión de él. Pero el orgullo, el amor propio y las concupiscencias del mundo, aunque destronados y crucificados, aún persisten dentro de nosotros, como el trono de Dagón. Velemos y oremos que no puedan prevalecer. Procuremos destruirlas por completo.</p>
<br/>
<p class="text-justify">Vv. 6-12.La mano del Señor pesó mucho sobre los filisteos; no sólo los convenció de su necedad; también castigó severamente su insolencia. Pero ellos no renunciaron a Dagón y, en lugar de buscar la misericordia de Dios, desearon librarse del arca. Cuando los corazones carnales despiertan ante la realidad del juicio de Dios, prefieren alejar a Dios de ellos, si eso fuera posible, antes que entrar en pacto, tener comunión con Él y buscarlo como amigo de ellos. Pero sus artimañas para eludir los juicios divinos sólo logran acrecentarlos. Quienes luchan contra la voluntad de Dios pronto se cansarán.</p>
<br/>




</div>
