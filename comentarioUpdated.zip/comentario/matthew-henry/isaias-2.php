<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Isaías 2</h2>
<p class="text-justify">Vv. 1-9.Se anuncia el llamamiento a los gentiles, la difusión del evangelio y su predicación mucho más extensa, aun por venir.
Fortalézcanse cristianos unos a otros, y sosténganse unos a otros. Dios es quien enseña a su pueblo por su palabra y su Espíritu. Cristo promueve la paz y la santidad. Si todos los hombres fueran cristianos de verdad, no habría guerra; pero nada que responda a tales expresiones ha ocurrido aun en la tierra.
No importa lo que otros hagan, andemos nosotros en la luz de esta paz. Recordemos que cuando florece la verdadera religión, los hombres se deleitan en subir a la casa de Jehová y en instar a otros a que los acompañen. Peligran los que se complacen con compañías ajenas a Dios; porque pronto aprendemos a seguir los caminos de las personas cuya compañía conservamos.
No es el tener plata u oro, caballos y carruajes, lo que desagrada a Dios, sino depender de ellos como si no estuviéramos a salvo, tranquilos y felices sin ellos, y no pudiéramos serlo sin ellos. El pecado es una desgracia para los más pobres y para los más bajos. Aunque las tierras llamadas cristianas no estén llenas de ídolos, en el sentido literal, ¿no están llenas de riquezas idolatradas? ¿No están los hombres tan ocupados con sus ganancias y liberalidades que, el Señor, sus verdades y sus preceptos son olvidados o desdeñados?</p>
<br/>
<p class="text-justify">Vv. 10-22.La toma de Jerusalén por los caldeos aquí parece significar, primero cuando la idolatría de los judíos fue quitada, pero nuestros pensamientos van a la destrucción de todos los enemigos de Cristo. Para quienes son perseguidos por la ira de Dios es necedad pensar en esconderse o ampararse de ella. El remezón de la tierra será terrible para quienes ponen su afecto en las cosas de la tierra. La altivez del hombre será derribada, sea por la gracia de Dios, que los acusa del mal del orgullo, o por la providencia de Dios que los priva de todo cuanto los enorgullecía.
El día de Jehová será contra las cosas en que ellos pusieron su confianza. Quienes no se apartaron de sus pecados por el razonamiento, tarde o temprano se apartarán de ellos por el temor. Los hombres codiciosos hacen su dios del dinero, pero viene el día en que lo sentirán tanto como su carga. Todo este pasaje puede aplicarse al caso del pecador vivificado, listo para dejar todo eso para que su alma sea salva.
Los judíos se inclinaban a confiar en sus vecinos paganos; pero aquí son llamados a dejar de depender del hombre mortal. Todos somos proclives al mismo pecado. Entonces, que ningún hombre te atemorice, ninguno sea tu esperanza, sino sea tu esperanza en Jehová tu Dios. Hagamos de esto nuestra gran preocupación.</p>
<br/>




</div>
