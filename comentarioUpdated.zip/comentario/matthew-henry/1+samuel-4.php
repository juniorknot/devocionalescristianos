<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Samuel 4</h2>
<p class="text-justify">Vv. 1-9.Israel es azotado por los filisteos. El pecado, la cosa maldita, estaba en el campamento y dio a los enemigos toda la ventaja que podían desear. Reconocieron la mano de Dios en su tribulación, pero en vez de someterse, hablaron con enojo, como si no se dieran cuenta de ninguna provocación que hubieran hecho. La insensatez del hombre tuerce su camino, y luego contra Jehová se irrita su corazón, Proverbios xix, 3, y lo culpan a Él. Supusieron que podían comprometer a Dios a manifestarse en favor de ellos, llevando el arca a su campamento. Quienes han regresado a la vida de la religión, a veces demuestran un gran afecto por las observancias externas, como si estas pudieran salvarlos y como si el arca, el trono de Dios, en el campamento los llevara al cielo, aunque el mundo y la carne estén entronizados en el corazón.</p>
<br/>
<p class="text-justify">Vv. 10-11.La captura del arca fue un gran juicio contra Israel y señal cierta del desagrado de Dios. Que nadie piense en escudarse contra la ira de Dios bajo el manto de una profesión externa de la fe.</p>
<br/>
<p class="text-justify">Vv. 12-18.La derrota del ejército fue muy penosa para Elí por cuanto era el juez; las noticias de la muerte de sus dos hijos, con quienes había sido tan indulgente, y que murieron sin arrepentimiento, como tenía razón para temer, le conmovieron como padre; pero había una preocupación más grande aun en su espíritu. Cuando el mensajero concluyó su relato diciendo ‘el arca de Dios fue capturada’, él fue golpeado en el corazón y murió instantáneamente. Un hombre puede morir en forma miserable, pero no morir eternamente; puede llegar a un final inoportuno, pero el final será paz.</p>
<br/>
<p class="text-justify">Vv. 19-22.La esposa de Finees parece haber sido una persona piadosa. Su lamento de moribunda fue por la pérdida del arca, y el traspaso de la gloria de Israel. ¿Qué es un gozo terrenal para quien está moribunda? Ningún gozo sino el que es espiritual y divino resistirá entonces; la muerte es algo demasiado grave para reconocer el sabor de un goce terrenal. ¿Qué es eso para quien lamenta la pérdida del arca? ¿Qué placer podemos hallar en nuestras consolaciones y deleites de criaturas, si necesitamos la palabra y las ordenanzas de Dios, especialmente si queremos el consuelo de su presencia bondadosa y la luz de su rostro? Si Dios se va, la gloria se va, y todo lo bueno se va. ¡Ay de nosotros si Él se va! Pero aunque la gloria sea trapasada de una nación, ciudad, o aldea pecadoras tras otra, sin embargo, nunca se irá del todo, pues brilla en un lugar, cuando se eclipsa en otro.</p>
<br/>




</div>
