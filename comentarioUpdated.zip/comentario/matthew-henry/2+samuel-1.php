<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Samuel 1</h2>
<p class="text-justify">Vv. 1-10.El golpe que abrió el camino de David hacia el trono fue dado en la época en que estuvo gravemente afligido. Quienes encomiendan sus asuntos al Señor, afirmarán tranquilamente su voluntad. Esto demuestra que David no deseaba la muerte de Saúl ni que estaba impaciente por llegar al trono.</p>
<br/>
<p class="text-justify">Vv. 11-16.David era sincero en su duelo por Saúl y todos se humillaron, junto con él, bajo la mano de Dios, puesta tan pesadamente sobre Israel con esta derrota.
El hombre que trajo la noticia fue ejcutado por orden de David, por asesinar a su príncipe. David no actuó con injusticia en este caso; el amalecita confesó el crimen. Si hizo como dijo, merecía morir por traición; y su mentira a David, si verdaderamente era mentira, demostró, como ese pecado demuestra tarde o temprano, que mentía contra sí mismo. Aquí David se demostró celoso de la justicia pública sin tomar en cuenta su interés particular.</p>
<br/>
<p class="text-justify">Vv. 17-27.Probablemente el título de este fúnebre cántico de dolor fuera ‘kasheth’o ‘el arco’. David no elogia a Saúl por lo que no fue y nada dice de su piedad o bondad. Jonatán fue un hijo obediente; Saúl, un padre afectuoso; por tanto, ambos se querían. David tiene razón para decir que el amor de Jonatán por él fue maravilloso. Después del amor entre Cristo y su pueblo, el afecto que surge de Él, produce la amistad más firme. Los problemas del pueblo del Señor y los triunfos de sus enemigos siempre dolerán a los creyentes verdaderos, sean cuales fueren las ventajas que obtuvieren de ellos.</p>
<br/>




</div>
