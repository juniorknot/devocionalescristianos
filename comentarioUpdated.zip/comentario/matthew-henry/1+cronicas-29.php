<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Crónicas 29</h2>
<p class="text-justify">Vv. 1-9.Lo que se haga en obras de piedad y caridad debe realizarse voluntariamente y no por obligación, porque Dios ama al dador alegre. David dio un buen ejemplo. David ofrendó, no por obligación ni para exhibirse, sino porque había puesto su afecto en la casa de Dios y pensaba que nunca haría bastante para fomentar esa buena obra. Quienes quieran atraer a otros al bien, deben ir adelante ellos mismos.</p>
<br/>
<p class="text-justify">Vv. 10-19.No podemos formarnos una idea correcta de la magnificencia del templo y de los edificios que lo rodeaban, en los cuales se usaron tales cantidades de oro y plata. Pero las inescrutables riquezas de Cristo exceden el esplendor del templo, infinitamente más de lo que aquel superaba a la choza más pobre de la tierra. En lugar de jactarse de óbolos tan grandes, David agradeció solemnemente a Dios. Todo lo que ellos dieron para el templo del Señor, era de Él; si ellos intentaban retenerlo, la muerte los hubiera quitado prontamente de eso. El único uso que podían hacer de eso para su beneficio real, era consagrarlo al servicio de Aquel que lo dio.</p>
<br/>
<p class="text-justify">Vv. 20-25.Esta gran asamblea se unió a David para adorar a Dios. Quienquiera sea la boca de la congregación, quienes se le unan sólo se benefician, no tanto por inclinar la cabeza como por elevar el alma.
Salomón se sentó en el trono del Señor. El reinado de Salomón tipifica el reinado del Mesías cuyo trono es el trono del Señor.</p>
<br/>
<p class="text-justify">Vv. 26-30. Cuando leímos el segundo libro de Samuel escasamente podíamos esperar que David apareciera tan ilustre en su escena final. Pero su arrepentimiento había sido tan notable como su pecado; y su conducta durante sus aflicciones, y hacia el final de su vida, parece haber tenido un buen efecto en sus súbditos. Bendito sea Dios, porque hasta el principal de los pecadores puede esperar una partida gloriosa cuando es llevado al arrepentimiento, y huye a refugiarse en la sangre expiadora del Salvador. Marquemos la diferencia entre el espíritu y el carácter del hombre que era conforme al corazón de Dios, en la vida y en la muerte, y los de los profesantes indignos que se le parecen sólo en sus pecados, y que tratan malamente de justificar sus crímenes por los pecados de aquel. Velemos y oremos, para que no seamos vencidos por la tentación, y tomados por el pecado para la deshonra de Dios y perjuicio de nuestra conciencia. Cuando sintamos que hemos ofendido, sigamos el ejemplo del arrepentimiento y la paciencia de David, a la espera de una resurrección gloriosa por medio de nuestro Señor Jesucristo.</p>
<br/>




</div>
