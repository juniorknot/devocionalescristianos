<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Tesalonicenses 1</h2>
<p class="text-justify">Vv. 1-5.Como todo lo bueno viene de Dios no puede esperarse nada bueno para los pecadores sino de Dios en Cristo. El mejor bien puede esperarse de Dios, como Padre nuestro, por amor de Cristo. Debemos orar no sólo por nosotros mismos, sino también por el prójimo, recordándolo sin cesar. Dondequiera que hay una fe verdadera, obra afectando el corazón y la vida. La fe obra en amor: se demuestra en amor a Dios y amor a nuestro prójimo. Dondequiera que haya una esperanza de vida eterna bien fundada, se verá por el ejercicio de la paciencia; y es señal de sinceridad, cuando en todo lo que hacemos procuramos ser aprobados por Dios. Por esto podemos conocer nuestra elección si no sólo hablamos de las cosas de Dios con nuestros labios, sino sentimos su poder en nuestros corazones, mortificando nuestras concupiscencias, apartándonos del mundo, y elevándonos a las cosas celestiales. A menos que el Espíritu de Dios venga, la palabra de Dios se nos volverá letra muerta. Así la recibieron por el poder del Espíritu Santo. Ellos estaban plenamente convencidos de su verdad como para no ser perturbados en su mente por objeciones y dudas, y estaban dispuestos a dejar todo por Cristo, y a arriesgar sus almas y su estado eterno en la verdad de la revelación del evangelio.</p>
<br/>
<p class="text-justify">Vv. 6-10.Cuando personas descuidadas, ignorantes e indolentes son apartadas de sus esfuerzos y conexiones carnales, para creer en el Señor Jesús y obedecerle, para vivir con sobriedad, rectitud y piedad, los hechos hablan por sí mismos.
Los creyentes del Antiguo Testamento esperaban la venida del Mesías y los creyentes esperan ahora su segunda venida. Él tiene que venir aún. Dios le levantó de entre los muertos, lo cual es la plena seguridad para todos los hombres de que Él vendrá a juzgar. Él vino a adquirir la salvación, y cuando vuelva otra vez, traerá salvación consigo, liberación plena y definitiva de la ira venidera. Todos, sin demora, deben huir de la ira venidera y buscar refugio en Cristo y su salvación.</p>
<br/>




</div>
