<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Oseas 1</h2>
<p class="text-justify">Vv. 1-7.Israel era próspero, pero entonces, Oseas les habla directamente de sus pecados y anuncia su destrucción. Los hombres no tienen que ser halagados en sus caminos pecaminosos porque triunfan en el mundo; ni tampoco les durará mucho si siguen en sus transgresiones.
El profeta debe mostrarle a Israel su pecado; mostrar que es excesivamente odioso. Su idolatría es el pecado del cual aquí se les acusa. Dar a la criatura esa gloria que sólo se debe a Dios, es una injuria y una afrenta a Dios, como una esposa que tome a un extraño lo sería para su esposo.
Sin duda el Señor tiene buenas razones para mandar tal cosa al profeta: eso conformaría un cuadro efectivo de la inmerecida bondad y la paciencia inagotable del Señor, y de la perversidad e ingratitud de Israel. Nos quebrantamos y agotamos con la perversidad de los demás, que es la mitad de aquella con que nosotros probamos la paciencia del Señor y contristamos el Espíritu de nuestro Dios. Estemos listos también para llevar cualquier cruz que el Señor asigne.
El profeta debe mostrar la ruina del pueblo en los nombres puestos a sus hijos. Predice la caída de la familia real con el nombre de su primer hijo: Lo llama Jezreel que significa “dispersión”.
Predice que Dios abandonará a la nación con el nombre de la segunda: Lo-ruhama, “no amada”o “no compadecida”. Dios mostró gran misericordia, pero Israel abusó de sus favores. El pecado aleja la misericordia de Dios, aun de Israel, su pueblo profesante. Si se niega la misericordia que perdona, no se puede esperar ninguna otra misericordia.
Aunque por la incredulidad algunos son cortados, Dios tendrá, de todos modos, una Iglesia en este mundo hasta el fin del tiempo. Nuestra salvación se debe a la misericordia de Dios, no a ningún mérito nuestro. Segura es la salvación de la cual Él es el autor; y si Él obra, nadie puede impedirlo.</p>
<br/>
<p class="text-justify">Vv. 8-11.El rechazo temporal de Israel está representado por el nombre de otro hijo: llámalo Lo-ami, “no mi pueblo”. El Señor desconoce toda relación con ellos. Nosotros lo amamos porque Él nos amó primero, pero ser sacados del pacto se debe a nosotros y a nuestra necedad.
La misericordia es recordada en el medio de la ira; el rechazo que no será total, tampoco es definitivo. La misma mano que hirió se estira para sanar. Aquí se dan promesas muy preciosas acerca del Israel de Dios, y que ahora nos sirven a nosotros.
Algunos piensan que estas promesas no se cumplirán por completo sino hasta la conversión general de los judíos en los tiempos postreros. También aplican esta promesa al evangelio y al hecho de judíos y gentiles serán alcanzados, San Pablo, Romanos ix, 25, 26, y San Pedro, 1 Pedro ii, 10. Creer en Cristo es tenerlo por Cabeza y voluntariamente consagrarnos a su dirección y gobierno. Oremos por la venida de ese día glorioso, cuando habrá un solo Señor en toda la tierra.</p>
<br/>




</div>
