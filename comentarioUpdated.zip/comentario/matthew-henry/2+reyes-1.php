<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Reyes 1</h2>
<p class="text-justify">Vv. 1-8.Cuando Ocozías se rebeló contra Jehová, Moab se rebeló contra él. El pecado nos debilita y empobrece. La rebelión del hombre contra Dios suele ser castigada por la rebelión de los que le deben sujeción.
Ocozías cayó por una ventana. Dondequiera vayamos solo hay un paso entre nosotros y la muerte. La casa del hombre es su castillo, pero no lo asegura contra los juicios de Dios. A la larga, toda la creación, que gime bajo la carga del pecado del hombre, cederá y se hundirá bajo ese peso, como esa ventana. Nunca está a salvo el que tenga a Dios como su enemigo. Los que no inquieren en la palabra de Dios para consuelo de ellos, la oirán para terror de ellos, quiéranlo o no.</p>
<br/>
<p class="text-justify">Vv. 9-18.Elías pidió fuego del cielo para consumir a los pecadores altivos y atrevidos; no para seguridad personal, sino para probar su misión y revelar la ira de Dios desde el cielo contra toda impiedad e injusticia de los hombres. Elías hizo esto por impulso divino, pero nuestro Salvador no permite que sus discípulos hagan lo mismo, Lucas ix, 54. La dispensación del Espíritu y de la gracia no lo permitió de manera alguna. Elías estaba preocupado por la gloria de Dios, aquéllos por su propia reputación. El Señor juzga las costumbres humanas por sus principios y su juicio es según verdad.
El tercer capitán se humilló y se arrojó a la misericordia de Dios y de Elías. No hay nada que ganar contendiendo con Dios; y son sabios los que aprenden la sumisión por el fin fatal de la obstinación de otros.
El valor de la fe a menudo ataca de terror el corazón del pecador más orgulloso. Tan estupefacto está Ocozías con las palabras del profeta, que ni él ni nadie de los suyos le opone resistencia. ¿Quién puede dañar a los que Dios ampara? -Muchos que piensan prosperar en el pecado, son llamados, como Ocozías, cuando menos lo esperan. Todo nos advierte que busquemos al Señor mientras puede ser hallado.</p>
<br/>




</div>
