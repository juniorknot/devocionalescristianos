<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Amós 9</h2>
<p class="text-justify">Vv. 1-10.El profeta vio en visión al Señor de pie sobre el altar idólatra de Betel. Dondequiera los pecadores huyan de la justicia de Dios, los alcanzará. Los que Dios lleva al cielo por su gracia nunca serán desechados, pero los que tratan de subir allá por la vana confianza en sí mismos, serán derribados y llenos de vergüenza. Lo que hace imposible el escape y segura la destrucción, es que Dios pondrá sus ojos sobre ellos para mal, no para bien.
El Señor esparcirá a los judíos y los visitará con calamidades, como el trigo zarandeado en una criba; pero salvará a algunos de ellos. Aquí parece predecirse la asombrosa preservación de los judíos como pueblo distinto.
Si los profesantes hacen como el mundo, Dios los nivelará con el mundo. Los pecadores que así se halagan, hallarán que su profesión de religiosidad no los protegerá.</p>
<br/>
<p class="text-justify">Vv. 11-15.Cristo murió para reunir a los hijos de Dios que estaban esparcidos y aquí se dice que son los llamados por su nombre. El Señor dijo esto, hace esto, puede hacerlo, ha decidido hacerlo, el poder de cuya gracia está comprometido en hacerlo. Los versículos 13 al 15 pueden referirse a los primeros tiempos del cristianismo, pero recibirán un cumplimiento más glorioso en los sucesos que todos los profetas anunciaron, más o menos, y pueden entenderse como el estado de dicha cuando la plenitud de los judíos y de los gentiles entre a la Iglesia. Continuemos fervorosos orando por el cumplimiento de estas profecías, en la paz, pureza, y belleza de la Iglesia.
Dios preserva maravillosamente al elegido en medio de las confusiones y miserias más aterradoras. Cuando todo parece desesperado, Él revive maravillosamente a su Iglesia, y la bendice con todas las bendiciones espirituales en Cristo Jesús. Y grande será la gloria de ese período en que nada de lo bueno prometido quedará sin cumplimiento.</p>
<br/>




</div>
