<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Timoteo 1</h2>
<p class="text-justify">Vv. 1-4.Jesucristo es la esperanza del cristiano; todas nuestras esperanzas de vida eterna están edificadas en Él; Cristo es en nosotros la esperanza de gloria. El apóstol parece haber sido el medio para la conversión de Timoteo, que sirvió con él en su ministerio como un hijo cumplido con un padre amante.
Lo que suscita interrogantes no es edificante; porque da ocasión a debates dudosos, demuele la iglesia en vez de edificarla. La santidad de corazón y vida puede mantenerse y aumentarse sólo por el ejercicio de la fe en la verdad y las promesas de Dios por medio de Jesucristo.</p>
<br/>
<p class="text-justify">Vv. 5-11.Todo lo que tiende a debilitar el amor a Dios o el amor a los hermanos, tiende a derrotar la finalidad del mandamiento. Se responde a la intencionalidad del evangelio cuando los pecadores, por el arrepentimiento para con Dios y la fe en Jesucristo, son llevados a ejercer el amor cristiano. La ley no está en contra de los creyentes que son personas justas en la forma establecida por Dios. Pero a menos que seamos hechos justos por la fe en Cristo, si no nos arrepentimos realmente y abandonamos el pecado, seguimos aún bajo la maldición de la ley, aun conforme al evangelio del bendito Dios, y somos ineptos para participar de la santa dicha del cielo.</p>
<br/>
<p class="text-justify">Vv. 12-17.El apóstol sabía que hubiese perecido justamente si el Señor hubiera llegado al extremo para señalar lo que estaba mal; y si su gracia y misericordia, cuando estaba muerto en pecado, no hubiesen abundado para él obrando la fe y amor a Cristo en su corazón. Este es un dicho fiel; estas son palabras verdaderas y fieles en las cuales se puede confiar: que el Hijo de Dios vino al mundo, voluntaria e intencionalmente, a salvar pecadores. Nadie, con el ejemplo de Pablo ante sí, puede cuestionar el amor y el poder de Cristo para salvarle, si realmente desea confiarse a Él como Hijo de Dios, que murió una vez en la cruz, y que ahora reina en el trono de gloria, para salvar a todos los que vayan a Dios por medio de Él. Entonces, admiremos y alabemos la gracia de Dios nuestro Salvador; y por todo lo hecho en nosotros, por nosotros, y para nosotros, démosle la gloria al Padre, Hijo y Espíritu Santo, tres Personas en la unidad de la Deidad.</p>
<br/>
<p class="text-justify">Vv. 18-20.El ministerio es una guerra contra el pecado y contra Satanás, la cual es librada bajo el mando del Señor Jesús que es el Capitán de nuestra salvación. Las buenas esperanzas que otras personas hayan tenido de nosotros, deben instarnos a cumplir el deber. Seamos rectos en nuestra conducta en todas las cosas. La intención de las censuras más elevadas de la iglesia primitiva fue prevenir más el pecado y reclamar al pecador. Todos los que estén tentados a eliminar la buena conciencia y a abusar del evangelio, recuerden también que este fue el camino al naufragio en la fe.</p>
<br/>




</div>
