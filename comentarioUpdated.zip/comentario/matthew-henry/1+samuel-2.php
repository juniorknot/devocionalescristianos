<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Samuel 2</h2>
<p class="text-justify">Vv. 11-26.Por estar consagrado al Señor de manera especial, Samuel fue desde niño empleado en el santuario para los servicios que era capaz de realizar. Como hizo esto con una santa disposición mental, fue llamado a ministrar al Señor. Recibió una bendición del Señor. Él capacita a los jóvenes que sirven a Dios lo mejor que pueden, para que mejoren y le sirvan mejor.
Elí evitaba los problemas y el esfuerzo, cosa que lo llevó a educar mal a sus hijos y no usó la autoridad paternal para restringirlos y corregirlos cuando eran niños. Hacía la vista gorda ante los abusos del servicio del santuario hasta que se le volvió costumbre, lo que condujo a abominaciones; sus hijos, que debieron ser ejemplo de lo que era bueno a quienes estaban dedicados al servicio del santuario, los llevaban a la maldad. La ofensa alcanzaba aun a la ofrenda de los sacrificios por los pecados, ¡que eran un tipo de la expiación hecha por el Salvador! Los pecados contra el remedio, la expiación misma, son los más peligrosos, porque pisotean la sangre del pacto.
La reprensión de Elí era demasiado suave y amable. En general, nadie más abandonado que los hijos degenerados de las personas santas cuando rompen todos los frenos.</p>
<br/>
<p class="text-justify">Vv. 27-36.Quienes permiten que sus hijos anden en todo camino malo sin usar su autoridad para refrenarlos y castigarlos, en realidad los honran a ellos más que a Dios. Que el ejemplo de Elí anime a los padres a luchar fervientemente contra los primeros indicios de maldad, y a educar a sus hijos en la disciplina y amonestación del Señor.
En medio de la condena sentenciada contra la casa de Elí, se promete misericordia a Israel. La obra de Dios nunca caerá al suelo por falta de manos para ejecutarla.
Cristo es el Sumo Sacerdote misericordioso y fiel a quien Dios levantó cuando el sacerdocio levítico fue depuesto, y es quien en todas las cosas hizo la voluntad de su Padre y para quien Dios edificará una casa segura, cimentada sobre una roca de modo que el infierno no pueda prevalecer contra ella.</p>
<br/>




</div>
