<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Ester 2</h2>
<p class="text-justify">Vv. 21-23.Los buenos súbditos no deben ocultar ningún mal designio contra el príncipe o contra la paz pública. Mardoqueo no fue recompensado en el momento, pero se escribió una memoria del hecho. De esta manera, de los que sirven a Cristo, aunque su recompensa no sea hasta la resurrección de los justos, se conserva un registro de su obra de fe y de su obra de amor, las cuales Dios no es injusto para olvidar. Si parece olvidado ahora, se recordará en el más allá.
Ninguna de nuestras acciones puede olvidarse; hasta nuestros pensamientos más secretos están escritos en registros eternos, Apocalipsis xx, 12.</p>
<br/>




</div>
