<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Proverbios 17</h2>
<p class="text-justify">V. 1.Estas palabras recomiendan el amor y la paz familiar como necesarias para el bienestar de la vida humana.</p>
<br/>
<p class="text-justify">V. 2.El siervo sabio es más merecedor que el hijo dispendioso y es más probable que parezca uno de la familia.</p>
<br/>
<p class="text-justify">V. 3.Dios prueba el corazón por la aflicción. Así ha demostrado a menudo el pecado remanente en el corazón del creyente.</p>
<br/>
<p class="text-justify">V. 4.Los aduladores, especialmente los falsos maestros, son bienvenidos para quienes viven en pecado.</p>
<br/>
<p class="text-justify">V. 5.Los que se ríen de la pobreza tratan con desdén a la providencia y los preceptos de Dios.</p>
<br/>
<p class="text-justify">V. 6.Honor para los hijos es tener padres piadosos y sabios que siguen con ellos, aun después de haber crecido y haberse establecido en el mundo.</p>
<br/>
<p class="text-justify">V. 7.El necio de los Proverbios de Salomón representa al impío, al cual no corresponde discurso excelente porque su conversación lo contradice.</p>
<br/>
<p class="text-justify">V. 8.Los que ponen en el dinero su corazón, harán cualquier cosa por tenerlo. ¡Qué influencia deben tener las dádivas de Dios en nuestro corazón!</p>
<br/>
<p class="text-justify">V. 9.La manera de conservar la paz es sacar lo mejor de todo: no fijarse en lo que se ha dicho o hecho contra nosotros.</p>
<br/>
<p class="text-justify">V. 10.La reprensión suave entrará no sólo en la cabeza del sabio sino en su corazón.</p>
<br/>
<p class="text-justify">V. 11.Satanás, y los mensajeros de Satanás, quedarán libres ante el impío.</p>
<br/>
<p class="text-justify">V. 12.Vigilemos nuestras pasiones y evitemos la compañía de hombres furiosos.</p>
<br/>
<p class="text-justify">V. 13.Devolver mal por bien es diabólico. El que hace eso acarrea maldición a su familia.</p>
<br/>
<p class="text-justify">V. 14.¡Qué peligro hay en el comienzo de la discordia! Resiste sus primeros indicios, y de ser posible, apártate antes de empezar.</p>
<br/>
<p class="text-justify">V. 15.Ofende a Dios exonerar al culpable o condenar a los inocentes.</p>
<br/>
<p class="text-justify">V. 16.La negligencia del hombre en cuanto al favor de Dios y su propio interés, es muy absurda.</p>
<br/>
<p class="text-justify">V. 17.Ningún cambio de las circunstancias externas debe abatir el afecto por nuestras amistades o parientes. Pero ningún amigo, salvo Cristo, merece confianza ilimitada. Este texto recibió, y aún recibe, su más glorioso cumplimiento en Él.</p>
<br/>
<p class="text-justify">V. 18.Que nadie haga mal a su familia. Cristo al hacerse fiador de los hombres es una muestra glorioso de la sabiduría divina, porque Él pudo cancelar la deuda.</p>
<br/>
<p class="text-justify">V. 19.Si queremos mantener la conciencia limpia y la mente en paz, debemos evitar todas las incitaciones a la ira. El hombre que pretende un estilo de vida por encima de sus medios, va camino a la ruina.</p>
<br/>
<p class="text-justify">V. 20.Nada se obtiene con malas intenciones. Muchos han pagado caro por una lengua desenfrenada.</p>
<br/>
<p class="text-justify">V. 21.Esto habla muy simplemente que muchos hombres sabios y buenos sienten con mucha intensidad cuán penoso es tener un hijo necio e impío.</p>
<br/>
<p class="text-justify">V. 22.Gran misericordia es que Dios nos permita estar contentos y que cause nuestro contentamiento, si por su gracia nos da corazón para estar contentos.</p>
<br/>
<p class="text-justify">V. 23.El impío está listo para separarse de su dinero, aunque lo ama, para no tener que sufrir por su delito.</p>
<br/>
<p class="text-justify">V. 24.El hombre prudente tiene siempre presente la palabra de Dios. Pero el necio no puede fijar sus pensamientos ni perseguir ningún propósito con constancia.</p>
<br/>
<p class="text-justify">V. 25.Los hijos malos desprecian la autoridad de su padre y la ternura de su madre.</p>
<br/>
<p class="text-justify">V. 26.Muy malo es encontrar culpa en el cumplimiento del deber.</p>
<br/>
<p class="text-justify">Vv. 27, 28.El hombre se demuestra sabio por el buen temperamento de su mente y por el buen gobierno de su lengua. Es cuidadoso cuando habla, para hablar conforme al propósito. Dios conoce su corazón y la necedad que está allí ligada; por tanto no puede ser engañado en su juicio como suelen serlo los hombres.</p>
<br/>




</div>
