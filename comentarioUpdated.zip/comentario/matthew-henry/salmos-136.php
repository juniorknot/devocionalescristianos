<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Salmos 136</h2>
<p class="text-justify">Vv. 1-9.Olvidadizos como somos, las cosas deben sernos repetidas a menudo. Por “misericordia”entendemos la disposición del Señor a salvar a aquellos cuyo pecado ha vuelto miserables y viles, y toda la provisión que ha hecho para la redención de los pecadores por Jesucristo. Los consejos de esta misericordia han sido desde la eternidad y los efectos de ella durarán por siempre, para todos los que estén interesados en ella. El Señor continúa estando igualmente preparado para mostrar misericordia a todos los que la buscan, y esta es la fuente de toda nuestra esperanza y consuelo.</p>
<br/>
<p class="text-justify">Vv. 10-22.Las grandes cosas que Dios hizo por Israel cuando los sacó de Egipto, fueron misericordias que les duraron por mucho tiempo; nuestra redención por Cristo, tipificada por aquellas, dura por siempre. Bueno es entrar en la historia de los favores de Dios y en cada uno observar y reconocer, que su misericordia dura por siempre. Los puso en posesión de una tierra buena; es figura de la misericordia de nuestro Señor Jesucristo.</p>
<br/>
<p class="text-justify">Vv. 23-26.La misericordia eterna de Dios es aquí alabada por la redención de su iglesia; en todas sus glorias y todos sus dones. Bendito sea Dios, que nos ha provisto y dado a conocer la salvación a través de su Hijo. Que nos conceda que conozcamos y sintamos su poder redentor, para que le sirvamos en justicia todos nuestros días. Que Aquel que da alimento a toda carne, alimente nuestras almas para vida eterna, y vivifique nuestros afectos por su gracia, para que le agradezcamos y alabemos su santo nombre, porque su misericordia dura para siempre. Remontemos todos los favores recibidos a esta verdadera fuente y ofrezcamos alabanza continuamente.</p>
<br/>




</div>
