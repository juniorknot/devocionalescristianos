<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Isaías 7</h2>
<p class="text-justify">Vv. 1-9.Los impíos suelen ser castigados por otros tan malos como ellos. Estando en gran angustia y confusión los judíos dieron todo por perdido. Habían hecho a Dios su enemigo y no sabían cómo hacerlo su amigo.
El profeta debe enseñarles a despreciar a sus enemigos teniendo fe en Dios y dependiendo de Él. Acaz, temeroso, dijo que eran dos poderosos príncipes. No, dice el profeta, ellos no son sino cabos de tizón humeantes, ya quemados. Los reinos de Siria e Israel estaban casi expirados. Mientras Dios tiene trabajo para los tizones de la tierra, ellos consumen todo lo que tengan por delante; pero, completado su trabajo, serán extinguidos como humo.
Lo que Acaz consideraba formidable es hecho terreno de la derrota de ellos, porque han seguido consejo malo contra ti, lo cual es una ofensa a Dios que se burla de los burladores, y da su palabra de que el intento no triunfará. El hombre propone, pero Dios dispone.
Era necedad que los cercanos a la destrucción estén tratando de arruinar a su prójimo. Isaías debe instar a los judíos a que confíen en las seguridades dadas a ellos. La fe es absolutamente necesaria para aquietar y componer la mente que pasa por pruebas.</p>
<br/>
<p class="text-justify">Vv. 10-16.La secreta falta de afecto por Dios suele ser disfrazada con el color del respeto por Él y los que están resueltos a no confiar en Dios pretenden aún que ellos no le tentarán . El profeta reprende a Acaz y a su corte por el poco valor que dan a la revelación divina. Nada es más triste para Dios que la desconfianza, pero la incredulidad del hombre no invalidará la promesa de Dios; el mismo Señor dará la señal. Por grande que sea su angustia y peligro, de ti nacerá el Mesías, y no podéis ser destruidos mientras esa bendición esté con vosotros. Ocurrirá de manera gloriosa; y las consolaciones más fuertes en época de problemas derivan de Cristo, nuestra relación con Él, nuestro interés en Él, nuestras expectativas de Él y de parte de Él.
Crecería como los demás niños, por el uso de la dieta de esos países, pero al contrario de los otros niños, rehusaría el mal y escogería el bien de manera coherente. Aunque su nacimiento fuera por el poder del Espíritu Santo, de todos modos Él no iba a ser nutrido con la comida de los ángeles.
Entonces, sigue una señal de la pronta destrucción de los príncipes, ahora terror para Judá. “Antes de que este niño”, léase, “este niño que ahora tengo en mis brazos”(Sear-jasub, el hijo del profeta, versículo 3), tenga tres o cuatro años de edad, estas fuerzas enemigas serán abandonadas por ambos reyes.
La profecía es tan solemne, la señal es tan marcada, como dadas por el mismo Dios después de que Acaz rechaza la oferta, que debe de haber suscitado esperanzas mucho más allá de lo que sugería la ocasión presente. Y, si la perspectiva de la venida del Salvador divino era un apoyo que nunca falla para las esperanzas de los creyentes antiguos, ¡qué razón tenemos para agradecer que la Palabra fuera hecha carne! Confiemos en Él y amémosle, imitemos su ejemplo.</p>
<br/>
<p class="text-justify">Vv. 17-25.Los que no quieren creer las promesas de Dios, esperen oír la alarma de sus amenazas, porque, ¿quién puede resistir o escapar de sus juicios? El Señor eliminará todo; y pagará a los que emplee en cualquier servicio para Él.
Todo habla de un triste cambio de la faz de esa tierra agradable, pero, ¿qué triste cambio hay que el pecado no haga en un pueblo? La agricultura se terminaría.
Penas de toda clase sobrevendrán a todos los que desprecian la gran salvación. Si seguimos sin dar fruto bajo los medios de la gracia, el Señor dirá: Nunca jamás nazca de ti fruto, desde ahora en adelante y para siempre.</p>
<br/>




</div>
