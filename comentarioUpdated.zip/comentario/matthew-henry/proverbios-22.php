<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Proverbios 22</h2>
<p class="text-justify">V. 1.Debiéramos ser cuidadosos para hacer lo que nos permite obtener y mantener un buen nombre, más que para formar un gran patrimonio o aumentarlo.</p>
<br/>
<p class="text-justify">V. 2.La providencia divina lo ha ordenado de tal manera, que algunos son ricos y otros pobres, pero todos son culpables ante Dios; y ante el trono de la gracia de Dios los pobres son tan bienvenidos como los ricos.</p>
<br/>
<p class="text-justify">V. 3.La fe prevé el mal que viene sobre los pecadores y mira a Jesucristo como el refugio seguro contra la tormenta.</p>
<br/>
<p class="text-justify">V. 4.Donde está el temor de Dios, habrá humildad. Mucho hay para disfrutar por el temor de Dios: riquezas espirituales y, al final, la vida eterna.</p>
<br/>
<p class="text-justify">V. 5.El camino del pecado es ofensivo y peligroso. Pero el camino del deber es seguro y fácil.</p>
<br/>
<p class="text-justify">V. 6.Educa a los niños, no en el camino en que quisieran ir, el de sus corazones corruptos, sino en el camino en que deben ir, por el cual, si los amas, usted quiere que anden. Tan pronto como sea posible cada niño debe ser guiado al conocimiento del Salvador.</p>
<br/>
<p class="text-justify">V. 7.Esto muestra cuán importante es que todo hombre se mantenga sin deudas. En cuanto a las cosas de esta vida hay una diferencia entre el rico y el pobre; pero que el pobre recuerde que es el Señor quien hizo la diferencia.</p>
<br/>
<p class="text-justify">V. 8.El poder de que muchos abusan pronto les faltará.</p>
<br/>
<p class="text-justify">V. 9.El que procura aliviar las necesidades y miserias del prójimo será bendecido.</p>
<br/>
<p class="text-justify">V. 10.Los escarnecedores y abusadores profanos perturban la paz.</p>
<br/>
<p class="text-justify">V. 11.Dios es el Amigo del hombre en cuyo espíritu no hay culpa; este honor tienen todos los santos.</p>
<br/>
<p class="text-justify">V. 12.Dios vuelve los consejos y designios de los hombres traicioneros para su propia confusión.</p>
<br/>
<p class="text-justify">V. 13.El hombre perezoso habla de un león afuera, pero no considera que su peligro real viene del diablo, ese león rugiente adentro, y de su propia pereza, que lo mata.</p>
<br/>
<p class="text-justify">V. 14.El vil pecado del libertinaje corrientemente entorpece irremediablemente la mente.</p>
<br/>
<p class="text-justify">V. 15.El pecado es necedad, está en el corazón, hay una inclinación interior a pecar; los niños la traen al mundo con ellos; y se fija muy cerca del alma. Todos necesitamos que nos corrija nuesto Padre celestial.</p>
<br/>
<p class="text-justify">V. 16.Sólo somos mayordomos y debemos administrar lo que Dios confía a nuestro cuidado, conforme a su voluntad.</p>
<br/>
<p class="text-justify">Vv. 17-21.A estas palabras, a este conocimiento, debe inclinarse el oído y el corazón, aplicado por fe y amor. Vivir una vida de gozo en Dios y de dependencia de Él, es el fundamento de toda religión práctica. El camino para conocer la certeza de la palabra de verdad es tomar conciencia de nuestro deber.</p>
<br/>
<p class="text-justify">Vv. 22, 23.El que roba y oprime al pobre lo hace a su propio riesgo. Y si los hombres no comparecen por sí, Dios lo hará.</p>
<br/>
<p class="text-justify">Vv. 24, 25.Nuestros corazones corruptos tienen tanta yesca en ellos que es peligroso meterse con los que andan arrojando las chispas de su pasión.</p>
<br/>
<p class="text-justify">Vv. 26, 27.Todo hombre debiera ser justo consigo mismo y su familia; no son así los que, por necedad u otra negligencia, despilfarran lo que tienen.</p>
<br/>
<p class="text-justify">V. 28.Se nos enseña a no transgredir el derecho de otro hombre. Cuesta encontrar un hombre verdaderamente industrioso. Tal hombre se levantará. ¿Ves a un hombre diligente en la religión? Probablemente se destaque. Entonces, seamos diligentes en la obra de Dios.</p>
<br/>




</div>
