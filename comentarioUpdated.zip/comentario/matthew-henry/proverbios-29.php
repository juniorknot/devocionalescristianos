<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Proverbios 29</h2>
<p class="text-justify">V. 1.¿Quién puede sanar si Dios hiere? La palabra de Dios advierte a todos que huyan de la ira venidera a la esperanza puesta ante nosotros en Jesucristo.</p>
<br/>
<p class="text-justify">V. 2.La gente tiene causa para regocijarse o lamentarse según sus gobernantes sean justos o impíos.</p>
<br/>
<p class="text-justify">V. 3.La sabiduría divina es lo que mejor nos resguarda de las lujurias destructoras.</p>
<br/>
<p class="text-justify">V. 4.El Señor Jesús es el Rey que ministrará el juicio verdadero a la gente.</p>
<br/>
<p class="text-justify">V. 5.Los aduladores ponen fuera de su guardia a los hombres, lo que los traiciona haciéndolos en mala conducta.</p>
<br/>
<p class="text-justify">V. 6.Las transgresiones siempre terminan en vejaciones. Los hombres justos andan en libertad y caminan en seguridad.</p>
<br/>
<p class="text-justify">V. 7.Este versículo es aplicable a la compasión por la angustia del pobre, y el desprecio sin sentimientos que muestra el impío.</p>
<br/>
<p class="text-justify">V. 8.El burlador se mofa de las cosas sagradas y serias. Los hombres que fomentan la religión, que es la sabiduría verdadera, alejan la ira de Dios.</p>
<br/>
<p class="text-justify">V. 9.Si un hombre sabio disputa el rencilloso y engreído, será tratado con ira o ridiculizado; y no hace ningún bien.</p>
<br/>
<p class="text-justify">V. 10.Cristo dijo a sus discípulos que iban a ser odiados por todos los hombres. El justo, a quien odian los sanguinarios, hace alegremente cualquier cosa por la salvación de ellos.</p>
<br/>
<p class="text-justify">V. 11.Necio es el que dice todo lo que sabe, y no puede retener el consejo.</p>
<br/>
<p class="text-justify">V. 12.El que ama a los aduladores y escucha a los calumniadores, hace que sus siervos se vuelvan mentirosos y falsos acusadores.</p>
<br/>
<p class="text-justify">V. 13.Algunos son pobres, otros tienen gran cantidad de riquezas engañadoras. Ellos se encuentran en los negocios de este mundo; el Señor da a ambos las comodiades de esta vida. Para algunos de ambas clases Él da su gracia.</p>
<br/>
<p class="text-justify">V. 14.El rico mirará a sí mismo, pero el príncipe debe defender al pobre y necesitado, y alegar a su favor.</p>
<br/>
<p class="text-justify">V. 15.Los padres deben tomar en cuenta el provecho de la debida corrección, y la maldad de la indulgencia indebida.</p>
<br/>
<p class="text-justify">V. 16.Que el justo no tenga su fe y esperanza abrumada por el aumento del pecado y de los pecadores, sino espere con paciencia.</p>
<br/>
<p class="text-justify">V. 17.No se debe tolerar que los hijos vivan sin reprensión cuando se portan mal.</p>
<br/>
<p class="text-justify">V. 18.¡Cuán desnudo parece un lugar sin Biblias ni ministros! ¡Y qué fácil presa es para el enemigo de las almas! El evangelio que presenta a Cristo es una visión abierta que humilla al pecador y exalta al Salvador, fomentando la santidad de la vida y la conversación; estas son verdades preciosas que mantienen viva el alma e impiden que perezca.</p>
<br/>
<p class="text-justify">V. 19.Aquí hay un siervo malo, perezoso e inútil; uno que sirve, no por conciencia ni amor, sino por miedo.</p>
<br/>
<p class="text-justify">V. 20.Cuando el hombre es engreído, precipitado y dado a las rencillas, hay más esperanza para el ignorante y despilfarrador.</p>
<br/>
<p class="text-justify">V. 21.El buen trato a un siervo no significa indulgencia, que arruinaría hasta un niño. El cuerpo es siervo del alma; quienes le siguen la corriente y son muy tiernos con aquél, hallarán que se olvida de su lugar.</p>
<br/>
<p class="text-justify">V. 22.Una disposición iracunda y apasionada hace que los hombres se provoquen unos a otros y provoquen a Dios.</p>
<br/>
<p class="text-justify">V. 23.Sólo los que se humillan serán exaltados y establecidos.</p>
<br/>
<p class="text-justify">V. 24.El que recibe es tan malo como el ladrón.</p>
<br/>
<p class="text-justify">V. 25.Muchos se avergüenzan de reconocer ahora a Cristo; Él no los reconocerá en el día del juicio. Pero el que confía en el Señor será salvado de la trampa.</p>
<br/>
<p class="text-justify">V. 26.El rumbo más sabio es mirar a Dios y buscar el favor del Rey de reyes porque toda criatura es para nosotros lo que Dios la hace ser.</p>
<br/>
<p class="text-justify">V. 27.El justo aborrece los pecados del impío y evita su compañía. Cristo expuso la maldad de los hombres, pero oró por los malos cuando lo crucificaron. El odio al pecado en nosotros mismos y el prójimo es una rama necesaria del temperamento cristiano, pero todo los réprobos tienen arraigado el odio por la piedad.</p>
<br/>




</div>
