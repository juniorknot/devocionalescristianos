<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Salmos 149</h2>
<p class="text-justify">Vv. 1-5.Las misericordias nuevas demandan nuevos cánticos de alabanza en la tierra y en el cielo. Y los hijos de Sion no sólo tienen que bendecir el nombre de Dios que los hizo, sino regocijarse en Él por haberlos creado en Cristo Jesús para buenas obras, y haberlos formado santos y hombres. El Señor se complace en su pueblo; ellos deben regocijarse en Él. Cuando hace que los pecadores sientan su necesidad e indignidad, el Señor los adorna con las gracias de su Espíritu, y hace que lleven su imagen y se regocijen en su felicidad por siempre. Que los santos empleen sus horas de vigilia en sus lechos cantando alabanzas. Que se regocijen aun en el lecho de muerte, seguros de que van al reposo y la gloria eterna.</p>
<br/>
<p class="text-justify">Vv. 6-9.Algunos de los antiguos siervos de Dios fueron comisionados para ejecutar venganza conforme a su palabra. No lo hicieron por venganza personal o política terrenal, sino en obediencia al mandamiento de Dios. La honra concebido para todos los santos de Dios, consiste en su triunfo sobre los enemigos de la salvación. Cristo nunca concibió que su evangelio fuera difundido a sangre y fuego, o su justicia por la ira del hombre. Pero dejemos que las excelsas alabanzas a Dios estén en nuestra boca mientras esgrimimos la espada de la palabra de Dios, y el escudo de la fe, en la guerra contra el mundo, la carne y el diablo. Los santos serán más que vencedores de los enemigos de sus almas por medio de la sangre del Cordero y la palabra de su testimonio. Esto se completará en el juicio del gran día. Entonces será ejecutado el juicio.
He aquí a Jesús y su iglesia del evangelio, principalmente en su estado milenial. Él y su pueblo se regocijan uno en el otro; por sus oraciones y esfuerzos obran con Él, mientras Él va adelante en los carros de la salvación, conquistando pecadores por su gracia o en los carros de la venganza, destruyendo a sus enemigos.</p>
<br/>




</div>
