<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Éxodo 40</h2>
<p class="text-justify">Vv. 1-15.Cuando empieza un año nuevo debemos procurar servir mejor a Dios que el año anterior.
El tabernáculo se terminó en medio año. Cuando los corazones de la gente se dedican seriamente a una buena causa, se puede hacer mucho en poco tiempo; y cuando se presta atención continuamente a los mandamientos de Dios, como regla de trabajo, todo se hará bien.
El sumo sacerdocio estuvo en la familia de Aarón hasta la venida de Cristo y en él sigue para siempre la sustancia de todas estas sombras.</p>
<br/>
<p class="text-justify">Vv. 16-33.Cuando el tabernáculo y sus utensilios estuvieron terminados, no dejaron de erigirlo hasta que llegaron a Canaán, pero obedeciendo la voluntad de Dios, lo armaban en medio del campamento. Quienes no están establecidos en el mundo no deben pensar que eso es excusa para la falta de religión; como si bastara comenzar a servir a Dios cuando empiezan a establecerse en el mundo. No; un tabernáculo para Dios es muy necesario aun en el desierto, especialmente dado que podemos estar en el otro mundo antes de llegar a establecernos en éste. Y debemos temer, no sea que nos engañemos a nosotros mismos con una apariencia de piedad. El pensamiento de que fueron tan pocos los que entraron en Canaán debe ser una advertencia especialmente para la gente joven, para no postergar el cuidado de su alma.</p>
<br/>
<p class="text-justify">Vv. 34-38.La nube cubrió el tabernáculo aun en el día más claro; no era una nube que el sol desvanece. La nube era una señal de la presencia de Dios para ser vista día y noche por todo Israel, para que nunca volvieran a preguntarse, ¿está o no el Señor entre nosotros? Dirigió el campamento de Israel a través del desierto. Mientras la nube estaba sobre el tabernáculo, ellos descansaban; cuando se levantaba, ellos la seguían.
La gloria del Señor llenaba el tabernáculo. La shekiná se hacía visible en forma de luz y fuego: Dios es Luz; nuestro Dios es Fuego consumidor. Pero tan deslumbrante era la luz y tan temible el fuego, que Moisés no podía entrar a la tienda de la reunión hasta que disminuía el resplandor. Pero lo que Moisés no pudo hacer, nuestro Señor Jesús lo hizo a quien Dios hizo acercarse; Él nos ha invitado a entrar confiadamente al trono de la gracia. Enseñados por el Espíritu Santo a seguir el ejemplo de Cristo, y a depender de Él, a participar de sus ordenanzas y obedecer sus preceptos, seremos guardados de perder el camino, y seremos guiados en medio de las sendas de juicio, hasta que lleguemos al cielo, la habitación de su santidad. ¡Bendito sea Dios por Jesucristo!</p>
<br/>




</div>
