<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Salmos 14</h2>
<br/>
<div class="alert callout">
<p>La Versión(Comentario Bíblico de Matthew Henry) no posee información para el capítulo Salmos 14. </p>

<p class="text-justify">Le recomendamos que consulte en nuestra lista de comentarios bíblicos uno distinto para obtener más información. Gracias por usar " BibliaDC Comentarios".</p>




</div>
