<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Jeremías 1</h2>
<p class="text-justify">Vv. 1-10.Se declara el temprano llamamiento de Jeremías a la obra y oficio de profeta. Iba a ser profeta, no sólo a los judíos; también a las naciones limítrofes. Sigue siendo profeta para todo el mundo y es bueno atender a sus advertencias. El Señor que nos formó sabe para qué servicio y propósito particular nos concibió. Sin embargo, a menos que nos santifique por su Espíritu que nos crea de nuevo, no seremos aptos para su santo servicio en la tierra ni para la santa dicha del cielo.
Nos conviene pensar con humildad de nosotros mismos. Los jóvenes deben considerar que ellos son así y no aventurarse más allá de sus poderes. Aunque el sentido de nuestra propia debilidad e insuficiencia debiera hacernos humildes acerca de nuestro trabajo, no debe hacernos retroceder cuando Dios nos llama. Los que tienen mensajes que entregar de parte de Dios no deben temer el rostro del hombre. Por una señal el Señor dio a Jeremías el don según era necesario. El mensaje de Dios debe ser entregado en sus propias palabras. Sea lo que sea que piensen los sabios o políticos del mundo, la seguridad del mundo se decide según el propósito y la palabra de Dios.</p>
<br/>
<p class="text-justify">Vv. 11-19.Dios dio a Jeremías una visión de la destrucción de Judá y Jerusalén en manos de los caldeos. El almendro, que está más maduro en la primavera que cualquier otro árbol, representa el veloz acercamiento de los juicios. Dios mostró también de donde surgiría la ruina concebida. Jeremías vio una olla hirviendo, que representaba a Jerusalén y Judá en gran conmoción. La boca o cara del horno o fogón daba hacia el norte; desde donde iban a venir el fuego y el combustible. Las potencias del norte se unirían. La causa de estos juicios era el pecado de Judá. Hay que declarar todo el consejo de Dios. El temor de Dios es el mejor remedio contra el temor al hombre. Mejor es tener por enemigos a todos los hombres y no a Dios; los que están seguros de tener a Dios consigo, no temen, no deben temer no importa quién esté en contra. Oremos por disposición para ceder los intereses personales y para que nada nos aparte de nuestro deber.</p>
<br/>




</div>
