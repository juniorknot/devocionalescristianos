<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Crónicas 1</h2>
<p class="text-justify">Vv. 1-27. Este capítulo, y muchos que siguen, repiten las genealogías o listas de padres e hijos de la historia bíblica, y los reúnen con muchos agregados. Cuando se compara con otros pasajes, se encuentran algunas diferencias, pero no debemos por eso tropezar en la Palabra, sino bendecir a Dios que las cosas necesarias para la salvación sean bastante claras.
Aquí el origen de la nación judía se remonta al primer hombre que Dios creó y, por eso, se distingue de los orígenes oscuros, fabulosos y absurdos atribuidos a otras naciones. Pero ahora todas las naciones está tan mezcladas entre sí, que ninguna nación, ni la mayor de ellas traza su origen a ninguna de estas fuentes. Sólo de esto estamos seguros, que Dios creó de una sangre a todas las razas de los hombres; todos son descendientes de un Adán, de un Noé. ¿No tienen todos un padre? ¿No nos ha creado un Dios? Malaquías ii, 10.</p>
<br/>
<p class="text-justify">Vv. 28-54.La genealogía de aquí en adelante se limita a la posteridad de Abraham.
Que tengamos ocasión de pensar, al leer estas listas de nombres, en las multitudes que han pasado por este mundo, han hecho su parte en él y luego se fueron. Cuando una generación, hasta de hombres pecadores, pasa y se va, otra viene, Eclesiastés i, 4; Números xxxii, 14, y así será mientras permanezca la tierra. Corto es nuestro paso por el tiempo hacia la eternidad. Que seamos distinguidos como pueblo del Señor.</p>
<br/>




</div>
