<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Reyes 16</h2>
<p class="text-justify">Vv. 1-9.Pocos y malos fueron los días de Acaz.
Aquellos cuyos corazones los condenan, recurrirán a cualquier parte, en tiempos difíciles, en vez de acudir a Dios. El pecado fue su propio castigo. Habitualmente los que se meten en angustias por un pecado, tratan de ayudarse a salir del aprieto con otro pecado.</p>
<br/>
<p class="text-justify">Vv. 10-16.Hasta ahora se había mantenido el altar de Dios en su lugar y en uso, pero Acaz puso otro en la sala.
La consideración natural de la mente del hombre por cierto tipo de religión no se extingue fácilmente; y, salvo que sea reglamentada por la Palabra y por el Espíritu de Dios, produce supersticiones absurdas o idolatrías detestables; en el mejor de los casos, acalla la conciencia del pecador con ceremonias insensatas. Los infieles se han destacado por creer falsedades ridículas.</p>
<br/>
<p class="text-justify">Vv. 17-20.Acaz despreció el día de reposo y, de esa forma , abrió una amplia entrada a toda clase de pecado. Hizo esto por el rey de Asiria. Cuando los que han tenido una entrada lista a la casa del Señor, se vuelven a otro camino para complacer a su prójimo, ruedan cuesta abajo hacia la destrucción.</p>
<br/>




</div>
