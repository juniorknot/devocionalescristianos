<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Jueces 3</h2>
<p class="text-justify">Vv. 1-7.Como los israelitas eran tipo de la iglesia de la tierra, no tenían que estar ociosos ni ser perezosos. Agradó al Señor probarlos con el resto de las naciones que ellos perdonaron. Las tentaciones y las pruebas detectan la iniquidad del corazón de los pecadores; y refuerzan las gracias de los creyentes en sus conflictos diarios con Satanás, el pecado y con este mundo malo. Deben vivir en este mundo, pero no son de este mundo y tiene prohibido conformarse a él. Esto marca la diferencia entre los seguidores de Cristo y los profesantes. La amistad del mundo es más fatal que la enemistad ; esta sólo puede matar el cuerpo, pero aquella asesina a muchas almas preciosas.</p>
<br/>
<p class="text-justify">Vv. 8-11.Otoniel fue el primer juez; empezó a hacerse famoso ya en la época de Josué. Poco después de establecerse en Canaán, la pureza de Israel empezó a corromperse y a perturbarse su paz.
Pero la aflicción hace que clamen a Dios los que antes escasamente hablaban a Él. Dios volvió a ellos por misericordia para liberarlos. El Espíritu de Jehová descendió sobre Otoniel: El Espíritu de sabiduría y valor que lo capacita para el servicio y el Espíritu de poder lo estimula para ello. Primero juzgó a Israel, lo reprendió y lo reformó, y luego fue a la guerra. Derrotad el pecado en casa, el peor de los enemigos, y los enemigos de fuera serán más fácilmente vencidos. Así, que Cristo sea nuestro Juez y Legislador, luego nos salvará.</p>
<br/>
<p class="text-justify">Vv. 12-30.Cuando Israel vuelve a pecar, Dios levanta un nuevo opresor. Los israelitas hicieron el mal, y los moabitas hicieron peor; puesto que Dios castiga en este mundo los pecados de su pueblo, Israel es debilitado, y Moab fortalecido contra ellos. Si las tribulaciones menores no hacen la obra, Dios las enviará mayores.
Cuando Israel vuelve a orar, Dios levanta a Aod. Como juez o ministro de la justicia divina, Aod mata a Eglón, rey de Moab, y, de ese modo, ejecuta los juicios de Dios contra él como enemigo de Dios y de Israel. Pero la ley de someterse a principados y potestades en todas las cosas lícitas es la regla de nuestra conducta. Ahora no se dan cometidos como estos; pretender tenerlos es blasfemar a Dios.
Nótese el discurso de Aod a Eglón. ¿Qué mensaje de Dios, sino uno de venganza, puede esperar un soberbio rebelde? Ese mensaje está contenido en la palabra de Dios; sus ministros osadamente la declaran sin temer el ceño fruncido ni hacer acepción de las personas de los pecadores. Pero, bendito sea Dios, ellos tienen que entregar un mensaje de misericordia y salvación gratuita; el mensaje de la venganza es sólo para los que rechazan la oferta de la gracia. La consecuencia de esta victoria fue que la tierra tuvo descanso por ochenta años. Fue un gran intervalo para que reposara la tierra, pero qué es eso para el descanso eterno de los santos en la Canaán celestial.</p>
<br/>
<p class="text-justify">V. 31.El lado del país que yacía al suroeste estaba infestado de filisteos. Dios levantó a Samgar para liberarlos; no teniendo espada ni lanza, tomó una aguijada de bueyes, el instrumento que tenía más a mano. Dios puede hacer útiles para su gloria y para el bien de su iglesia a personas humildes y oscuras por nacimiento, educación y ocupación. No importa el arma si Dios dirige y fortalece el brazo. A menudo Él obra por medios inverosímiles para que la excelencia del poder sea de Dios.</p>
<br/>




</div>
