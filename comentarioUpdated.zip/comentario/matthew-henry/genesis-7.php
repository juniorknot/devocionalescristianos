<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 7</h2>
<p class="text-justify">Vv 21-24.Murieron todos los hombres, mujeres y niños que había en el mundo, excepto los que estaban en el arca. Podemos imaginar fácilmente el terror que los embargó. Nuestro Salvador nos dice que hasta el mismo día en que llegó el diluvio, ellos estaban comiendo y bebiendo, Lucas xvii, 26, 27; estaban sordos y ciegos a todas las advertencias divinas. La muerte los sorprendió en esta postura. Ellos se convencieron de su necedad cuando ya era demasiado tarde. Podemos suponer que intentaron todos los medios posibles para salvarse, pero todo fue en vano. Los que no se encuentran en Cristo, el Arca, ciertamente serán destruidos, destruidos para siempre. -¡Hagamos una pausa y consideremos este tremendo juicio! ¿Qué puede prevalecer delante del Señor cuando él está airado? El pecado de los pecadores será su ruina, temprano o tarde, si no se arrepienten. El Dios justo sabe llevar la ruina al mundo de los impíos, 2 Pedro iii, 5. ¡Qué terrible será el día del juicio y de la perdición de los hombres impíos! Felices los que son parte de la familia de Cristo y que como tales están a salvo con Él; ellos pueden esperar sin desmayo y regocijarse de que triunfarán cuando el fuego queme la tierra y todo lo que en ella hay. Podemos suponer algunas distinciones favorables en nuestro propio caso o carácter, pero, si descuidamos, rechazamos o abusamos de la salvación de Cristo, pese a las imaginadas ventajas, seremos destruidos en la ruina común de un mundo incrédulo.</p>
<br/>




</div>
