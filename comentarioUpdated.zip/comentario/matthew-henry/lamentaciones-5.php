<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Lamentaciones 5</h2>
<p class="text-justify">Vv. 1-16.¿Está alguno afligido? Que ore; y que en oración derrame su queja ante Dios. El pueblo de Dios hace eso aquí; se quejan, no de los males temidos, sino de los males sentidos. Si nos arrepentimos y tenemos paciencia por lo que sufrimos por los pecados de nuestros padres, podemos tener la expectativa de que Aquel que castiga, volverá a nosotros con misericordia.
Ellos reconocen: ¡Ay de nosotros que hemos pecado! Todos nuestros ayes se deben a nuestro pecado y a nuestra necedad. Aunque nuestros pecados y el justo descontento de Dios causan nuestros sufrimientos, podemos tener esperanza de su misericordia que perdona, su gracia que santifica y su buena providencia. Pero los pecados de toda la vida de un hombre serán castigados con venganza al final, a menos que ponga interés en Aquel que llevó nuestros pecados en su cuerpo sobre el madero.</p>
<br/>
<p class="text-justify">Vv. 17-22.El pueblo de Dios expresa profunda preocupación por las ruinas del templo, más que por cualquiera otra de sus calamidades. Pero sea lo que sea que cambie aquí en la tierra, Dios es aún el mismo y sigue siendo por siempre sabio y santo, justo y bueno; en Él no hay cambio ni sombra de variación.
Ellos oran con fervor a Dios por misericordia y gracia, Vuélvenos a ti, oh Señor. Dios nunca deja a nadie hasta que ellos lo dejan a Él primero; si los hace volver a sí mismos por el camino del deber, sin duda que Él se volverá a ellos con prontitud por un camino de misericordia. Si Dios por su gracia renueva nuestros corazones, renovará por su favor nuestros días. Los trastornos pueden hacer que nuestros corazones desfallezcan, y que se nublen nuestros ojos, pero está abierto el camino al trono de la gracia de nuestro Dios reconciliado. En todas nuestras pruebas pongamos toda nuestra confianza y fe en su misericordia; confesemos nuestros pecados y derramemos nuestros corazones ante Él. Velemos contra los afanes y el desaliento; porque seguramente sabemos que al final todo será bueno para todos los que confían en el Señor, le temen, le aman y le sirven. -¿No son los juicios del Señor en la tierra los mismos que en la época de Jeremías? Entonces, que Sion sea recordada por nosotros en nuestras oraciones y su bienestar sea buscado por encima de todo goce terrenal. Salva, Señor, salva a tu pueblo, y no des tu herencia al reproche para que el pagano no reine sobre ellos.</p>
<br/>




</div>
