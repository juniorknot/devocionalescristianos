<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Salmos 54</h2>
<p class="text-justify">Versículos 1-3. David se queja de la maldad de sus enemigo. 4-7. Seguridad del favor y protección divina.</p>
<br/>
<p class="text-justify">Vv. 4-7.He aquí, Dios es el que me ayuda. Si estamos por Él, Él está por nosotros; y si Él está por nosotros, no tenemos qué temer. Toda criatura es para nosotros lo que Dios hace que sea, no más. El Señor salvará a su pueblo en el momento oportuno y mientras tanto lo sustenta y lo tolera, para que no desfallezca el espíritu que ha hecho. Hay verdad en las amenazas de Dios y en sus promesas; los pecadores que no se arrepienten, así lo hallarán a su propio costo.
La presente liberación de David fue una arras de su posterior liberación. Habla de completar su liberación como cosa hecha, aunque todavía le quedaban por delante muchas tribulaciones; porque teniendo la promesa de Dios se sentía tan seguro como si ya estuviera hecho. El Señor lo liberaría de todas sus tribulaciones. Él nos ayude a llevar nuestras cruces sin afanarnos y, en el largo plazo, nos lleve a compartir sus victorias y su gloria.
Los cristianos nunca deben tolerar que cese la voz de alabanza y de acción de gracias en la Iglesia de los redimidos.</p>
<br/>




</div>
