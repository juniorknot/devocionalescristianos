<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Números 36</h2>
<p class="text-justify">Vv. 1-4.Los jefes de la tribu de Manasés representan lo malo que podría sobrevenir si las hijas de Zelofehad se casaran con hombres de cualquier otra tribu. Ellas procuraban preservar la designación divina de las heredades, y que no surgieran contiendas ni peleas entre quienes vinieran después. Es sabiduría y deber de quienes tienen propiedades en el mundo, regularizarlos y disponer de ellos de modo que no surjan discordias ni disputas.</p>
<br/>
<p class="text-justify">Vv. 5-12.Los que consultan los oráculos de Dios sobre la manera de asegurar su heredad celestial , no sólo se les dirá lo que deben hacer, también sus preguntas serán bondadosamente aceptadas. Dios no permite que una tribu se enriquezca a expensas de otra. Cada tribu tenía que preservar su heredad. Las hijas de Zelofehad se sometieron a este designio. ¿Cómo podrían dejar de casarse bien, si el mismo Dios las dirigía? -Que el pueblo de Dios aprenda cuán bueno y conveniente es unirse solamente a su propio pueblo, como las hijas de Israel. ¿No debiera todo verdadero creyente en Jesús estar muy atento a las relaciones cercanas y tiernas de la vida, para unirse solamente con quienes están unidos al Señor? Todas nuestras intenciones e inclinaciones deben sujetarse a la voluntad de Dios, cuando esta se nos ha dado a conocer, y especialmente cuando se trata de contraer matrimonio. Aunque la palabra de Dios permite el afecto y la preferencia en esta importante relación, no da su aprobación a la pasión necia, ingobernable e idólatra, que no se preocupa por cual sea el fin, sino que, desafiando la autoridad, determina su propia satisfacción. Toda conducta de esta clase es contraria al sentido común, a los intereses de la sociedad, a la felicidad de la relación matrimonial y, lo que es peor aun, contra la religión de Cristo.</p>
<br/>
<p class="text-justify">V. 13.Estos son los juicios que el Señor mandó en los campos de Moab. La mayoría de ellos dicen la relación con la ocupación de Canaán, donde iban a entrar ahora los israelitas. Cualquiera sea la nueva condición que Dios nos ponga en su providencia, tenemos que rogarle que nos enseñe los deberes correspondientes y nos capacite para ello, a fin de que podamos hacer la obra del día en su día, el deber de un lugar en su lugar.</p>
<br/>




</div>
