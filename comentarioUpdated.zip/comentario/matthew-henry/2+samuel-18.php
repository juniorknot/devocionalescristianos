<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Samuel 18</h2>
<p class="text-justify">Vv. 1-8.¡Cómo devuelve David bien por mal! Absalón sólo habría dado muerte a David; David sólo habría salvado a Absalón. Esto es semejante a la maldad del hombre para con Dios, y la misericordia de Dios para con el hombre, de lo cual cuesta mucho decir cuál es más asombrosa. Ahora los israelitas ven el resultado de ponerse contra Jehová y su ungido.</p>
<br/>
<p class="text-justify">Vv. 9-18.Jóvenes, mirad a Absalón, colgando de un árbol, maldecido, abandonado por el cielo y la tierra; leed en esto cuánto aborrece el Señor la rebelión contra los padres. Nada puede resguardar a los hombres de la desgracia y desprecio, sino la sabiduría de lo alto y la gracia de Dios.</p>
<br/>
<p class="text-justify">Vv. 19-33.Ahimaas preparó a David para la noticia de la muerte de su hijo guiándolo a dar gracias a Dios por su victoria. Mientras más se prepara y engrandece nuestro corazón para agradecer a Dios sus misericordias, mejor dispuestos estaremos a soportar con paciencias las aflicciones que vienen con ellas.
Algunos piensan que el deseo de David surgió de la preocupación por el estado eterno de Absalón; pero pareciera que más bien él habló sin pensar debidamente. Debe culpársele por mostrar gran cariño por un hijo carente de bondad; además, por pelear con la justicia divina y oponerse a la justicia nacional que tenía que administrar en su calidad de rey, y la cual debió preferir por sobre el afecto natural. Los mejores no siempre tienen el enfoque correcto; somos dados a entristecernos excesivamente por lo que amamos con exageración. Pero aunque de este ejemplo aprendamos a velar y orar contra la indulgencia pecaminosa o el descuido de nuestros hijos, ¿no podemos notar en David una sombra del amor del Salvador que lloró, oró y hasta sufrió la muerte por la humanidad, aunque esta estaba compuesta de rebeldes y viles enemigos?</p>
<br/>




</div>
