<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Josué 1</h2>
<p class="text-justify">Vv. 1-4.Josué había atendido a Moisés. Él que era llamado a ser honrado, había sido usado por mucho tiempo para la empresa. Nuestro Señor Jesús asumió la forma de siervo. José estaba entrenado para obedecer órdenes. Los más aptos para gobernar son los que han aprendido a obedecer.
El cambio de situación de los hombres útiles debe estimular a los sobrevivientes para ser más diligentes en hacer el bien.
Levántense y vayan a cruzar el Jordán. Los bajíos de la zona estaban en ese momento anegados. Josué no tenía puente ni botes pero debía creer que Dios abriría un camino al haber mandado que el pueblo pasara al otro lado.</p>
<br/>
<p class="text-justify">Vv. 5-9.Josué va a hacer que la ley de Dios sea su gobierno. Se le manda meditar en ella día y noche para que pueda comprenderla. Cualesquiera sean los asuntos del mundo que tengamos en mente, no debemos desechar la única cosa necesaria. Todas las órdenes de Josué al pueblo, y sus juicios, deben estar conforme a la ley de Dios. Él mismo debe someterse a los mandamientos; la dignidad o el dominio de ningún hombre lo coloca por encima de la ley de Dios. -Él tiene que alentarse a sí mismo con la promesa y la presencia de Dios. Que sentir sus propias enfermedades no lo desanimen a usted; Dios es todo suficiente. Yo te he mandado, llamado y comisionado para hacerlo y ten la seguridad que te sostendré en, y sacaré de, eso. Cuando estamos en la senda del deber, tenemos razón para ser fuertes y muy osados. Nuestro Señor Jesús, como aquí Josué, fue sostenido en sus sufrimientos por considerar la voluntad de Dios y el mandamiento de su Padre.</p>
<br/>
<p class="text-justify">Vv. 10-15.Josué dice al pueblo que cruzarán el Jordán y poseerán la tierra porque Dios se lo había dicho. Nosotros honramos la verdad de Dios cuando no vacilamos a la promesa de Dios. Las dos tribus y media tenían que cruzar el Jordán con sus hermanos. Cuando Dios nos ha dado reposo, por Su providencia, debemos considerar que servicio podemos hacer a nuestros hermanos.</p>
<br/>
<p class="text-justify">Vv. 16-18.El pueblo de Israel se compromete a obedecer a Josué: Haremos todo lo que nos has mandado, sin murmurar ni disputar, y adondequiera que nos envíes, iremos. Lo mejor que podemos pedir a Dios para nuestros magistrados es que ellos puedan tener la presencia de Dios; eso hará que ellos sean bendiciones para nosotros, de modo que al pedir eso para ellos, tengamos en cuenta nuestro propio interés. Que seamos capacitados para enrolarnos bajo la bandera del Capitán de nuestra salvación, que seamos obedientes a sus mandamientos y que peleemos la buena batalla de la fe, con toda esa confianza y amor en y por Su nombre, contra todo lo que se oponga a Su autoridad; pues quienquiera que rehuse obedecerle, debe ser destruido.</p>
<br/>




</div>
