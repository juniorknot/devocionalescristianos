<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Nehemías 2</h2>
<p class="text-justify">Vv. 1-8.Nuestras oraciones deben ser secundadas con esfuerzos serios, de otro modo nos burlamos de Dios. No estamos limitados a ciertos momentos en nuestras audiencia con el Rey de reyes; tenemos la libertad de ir a Él en todo momento; acercarse al trono de la gracia nunca pasa de moda. Pero la sensación del desagrado de Dios y de las aflicciones de su pueblo son causa de tristeza para los hijos de Dios, de las cuales no los consuelan los placeres terrenales.
El rey animó a Nehemías para que dijera que pensaba. Esto le dio confianza para hablar; mucho más puede animarnos la invitación que Cristo nos ha dado para orar, y la promesa de que nos irá bien, para ir directamente ante el trono de la gracia.
Nehemías oró al Dios del cielo, infinitamente superior aun de este monarca poderoso. Elevó su corazón al Dios que entiende el lenguaje del corazón. Nunca debemos buscar ni esperar la dirección, la asistencia ni la bendición divina cuando emprendemos algo que es malo para nosotros. Hubo una respuesta inmediata a su oración, porque la simiente de Jacob nunca buscó en vano al Dios de Jacob.</p>
<br/>
<p class="text-justify">Vv. 9-18.Cuando Nehemías hubo considerado el asunto, dijo a los judíos que Dios había puesto en su corazón edificar los muros de Jerusalén. No se pone a hacerlo sin ellos. Estimulándonos nosotros mismos y unos a otros en lo bueno, nos fortalecemos mutuamente. Somos débiles en nuestro deber cuando somos fríos e indiferentes.</p>
<br/>
<p class="text-justify">Vv. 19, 20.La enemistad de la simiente de la serpiente contra la causa de Cristo no está limitada a una época o nación. La aplicación para nosotros es clara. La iglesia de Dios pide nuestra ayuda. ¿No está desolada y expuesta a ataques? ¿Le causa triteza considerar su bajo estado? Que ningún negocio, placer o apoyo de un partido atrape tanto su atención como para que Sion y su bienestar no le interesen.</p>
<br/>




</div>
