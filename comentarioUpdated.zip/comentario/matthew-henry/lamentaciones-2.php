<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Lamentaciones 2</h2>
<p class="text-justify">Vv. 1-9.Aquí se hace una triste representación del estado de la Iglesia de Dios, de Jacob e Israel; pero la noticia parece referirse mayormente a la mano del Señor en sus calamidades, aunque Dios no es enemigo de su pueblo, cuando está airado con él y lo corrige. Cuando Dios retira su protección no hay puertas ni rejas que tomen su lugar. Es justo que Dios derribe con juicios a los que se rebajan a sí mismos por el pecado; y que prive del beneficio y consuelo de los días de reposo y de sus ordenanzas, a los que no los han valorado debidamente ni obedecido. ¿Qué harán con las Biblias los que no las aprovechan? Los que abusan de los profetas de Dios los pierden con justicia.
Se hace necesario, aunque doloroso, volver los pensamientos del afligido a la mano de Dios alzada contra ellos, y a sus pecados, como la fuente de sus miserias.</p>
<br/>
<p class="text-justify">Vv. 10-22.Se describen causas para los lamentos. Las multitudes perecen de hambre. Hasta los pequeños murieron por mano de sus madres, y se los comieron, según la amenaza de Deuteronomio xxviii, 53. Multitudes caen a espada. Sus falsos profetas los engañaron. Sus vecinos se ríen de ellos. Gran pecado es burlarse de la desgracia de otros y añade mucha aflicción al afligido. Sus enemigos triunfaron sobre ellos. Los enemigos de la Iglesia son dados a tomar sus temores por ruina, pero se engañan a sí mismos.
Se hacen llamados a lamentar; y se busca consuelo para la cura de los lamentos. La oración es un bálsamo para cada llaga, aún la más grave; remedio para toda enfermedad, aún la más penosa. Nuestra actividad en oración es referir nuestra causa al Señor y dejarla en sus manos. Su voluntad sea hecha. Temamos a Dios, y andemos humildemente ante Él y obedezcamos, no sea que caigamos.</p>
<br/>




</div>
