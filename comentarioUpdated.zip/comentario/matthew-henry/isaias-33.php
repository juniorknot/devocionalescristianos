<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Isaías 33</h2>
<p class="text-justify">Vv. 1-14.Aquí tenemos al destructor soberbio y falso justamente tenido en cuenta por todo su fraude y violencia. El Dios justo suele pagar a los pecadores con su propia moneda.
Los que por fe esperan humildemente en Dios, hallarán que los trata con gracia; como el día, así será la fuerza. Si Dios nos deja solos cualquier mañana, somos deshechos; cada mañana debemos encomendarnos a Él y seguir adelante en su poder para hacer la obra del día.
Cuando Dios se levanta se dispersan sus enemigos. La sabiduría y el conocimiento verdadero guían a la fuerza de la salvación que nos hace constantes en los caminos de Dios; y la piedad verdadera es el único tesoro que nunca puede ser saqueado o gastado.
Se describe la angustia que Jerusalén se estaba acarreando. El tiempo de Dios para comparecer en favor de su pueblo es cuando fallan todas las demás ayudas. Todos los que oigan lo que Dios ha hecho, reconozcan que todo lo puede hacer. Los pecadores de Sion tendrán mucho por qué responder, más que los demás pecadores. Los que se rebelan contra los mandamientos de la palabra no pueden hallar su consuelo en los momentos de necesidad.
Su ira quemará eternamente a los que se hacen pasto para ella. Es un fuego que nunca será sofocado ni se extinguirá; es la ira del Dios eterno que hace presa en la conciencia del alma que nunca muere.</p>
<br/>
<p class="text-justify">Vv. 15-24.El creyente verdadero vela contra todas las ocasiones de pecado. El poder divino lo mantiene a salvo y su fe en ese poder lo conserva en paz. Nada necesario le falta. Toda bendición de salvación la da gratuitamente a todos los que piden con oración humilde y en fe; y el creyente está a salvo en el tiempo y por la eternidad. Los que andan rectamente no sólo recibirán pan regalado y tendrán asegurada el agua; por fe, verán al Rey de reyes en su belleza, la belleza de la santidad. El recuerdo del terror en que estuvieron será agregado al placer de su liberación. Deseable es estar quietos en nuestras casas, pero mucho más es estar tranquilos en la casa de Dios; en toda época Cristo tendrá una simiente que le sirva.
Jerusalén no tenía un río que la surcara, pero la presencia y el poder de Dios compensan todas las necesidades. Tenemos todo en Dios, todo lo que necesitamos o podemos necesitar. Por fe tomamos a Cristo como nuestro Príncipe y Salvador; Él reina sobre su pueblo redimido. Todos los que rehusen a tenerlo a Él reinando sobre ellos, hacen zozobrar su alma.
La enfermedad la quita por misericordia, cuando el fruto de ella es quitar el pecado. Si se quita la iniquidad, tenemos poca razón para quejarnos de la aflicción externa. Este último versículo guía nuestros pensamientos, no sólo al estado más glorioso de la Iglesia del evangelio en la tierra, sino al cielo donde no pueden entrar la enfermedad ni la aflicción. El que borra nuestras transgresiones sanará nuestras almas.</p>
<br/>




</div>
