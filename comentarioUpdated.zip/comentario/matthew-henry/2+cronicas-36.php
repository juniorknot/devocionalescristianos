<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">2 Crónicas 36</h2>
<p class="text-justify">Vv. 1-21.La ruina de Judá y Jerusalén fue gradual. Los métodos que Dios adopta para llamar de regreso a los pecadores por su Palabra, por medio de los ministros, por la conciencia, por providencias, son todos ejemplos de su compasión hacia ellos, y de su deseo de que ninguno perezca. Véase aquí qué caos terrible produce el pecado y, a medida que valoramos el consuelo y continuidad de nuestras bendiciones terrenales, mantengamos alejado ese gusano de sus raíces.
Ellos habían arado y sembrado muchas veces su tierra en el séptimo año, cuando debiera haber reposado, y ahora había estado sin arar y ni sembrar durante diez veces siete años. Dios no saldrá perdiendo su gloria al final por la desobediencia de los hombres. Si ellos se negaron a dejar que la tierra reposara, Dios la haría descansar. ¿A qué lugar, oh Dios, perdonará tu justicia si Jerusalén ha perecido? Si esa delicia tuya fuese cortada por mala, no seamos altivos, temamos.</p>
<br/>
<p class="text-justify">Vv. 22, 23.Dios había prometido restaurar a los cautivos y reconstruir Jerusalén al final de setenta años, y, el tiempo fijado, el tiempo de favorecer a Sion, llegó por fin. Aunque la iglesia de Dios fuera derribada no es expulsada ; aunque su pueblo sea corregido, no es abandonado; aunque arrojado al horno, no se pierde ahí, ni es dejado más tiempo de lo necesario para separar lo espurio. Aunque Dios contienda por mucho tiempo no contenderá para siempre.
Antes de cerrar los libros de las Crónicas, que contienen el fiel registro de los hechos, pensad qué desolación introdujo el pecado en el mundo y, sí, hasta en la iglesia de Dios. Temblemos por lo que aquí se narra, aunque en el carácter de algunas pocas almas bondadosas descubramos que el Señor no se queda sin testigos. Y cuando hayamos mirado este fiel retrato de la naturaleza del hombre, comparémoslo con la misma naturaleza renovada por la gracia del Todopoderoso, por medio de la justicia de Cristo, nuestro Salvador que justifica y adorna el alma.</p>
<br/>




</div>
