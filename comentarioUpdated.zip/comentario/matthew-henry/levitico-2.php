<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Levítico 2</h2>
<p class="text-justify">Vv. 1-11.Las ofrendas vegetales pueden ser tipo de Cristo, que se ofreció a Dios por nosotros, como el Pan de vida para nuestras almas; pero más bien parecen significar nuestra obligación para con Dios por las bendiciones de la providencia, y las buenas obras aceptables para Dios. La oblación era comestible y ese nombre abarcaba, y aún comprende, cualquier clase de provisión; la mayor parte de esta ofrenda era para comerla, y no para quemarla. Estas ofrendas se mencionan después de los holocaustos: estos servicios no pueden ser aceptados sin que haya interés en el sacrificio de Cristo, y dedicación a Dios de todo corazón.
La levadura es el emblema del orgullo, la maldad, hipocresía, y la miel del placer sensual. Lo primero se opone directamente a las virtudes de la humildad, el amor y la sinceridad, que Dios aprueba; lo segundo aparta a los hombres de los ejercicios de devoción y de la práctica de las buenas obras. Cristo, en su carácter y sacrificio, estaba totalmente libre de las cosas representadas por la levadura; y su vida de sufrimientos y sus dolores de muerte eran exactamente lo opuesto del placer mundano. Su pueblo ha sido llamado a seguirle, y a ser como Él.</p>
<br/>
<p class="text-justify">Vv. 12-16.La sal se necesita en todas las ofrendas. Aquí Dios les insinúa que sus sacrificios, en sí mismos, son insípidos. Todos los servicios religiosos deben estar sazonados con la gracia. El cristianismo es la sal de la tierra.
Se dan instrucciones sobre la ofrenda de las primicias en la cosecha. Si un hombre, con gratitud por la bondad de Dios al darle una cosecha abundante, estaba dispuesto a presentar una ofrenda a Dios, que traiga los primeros frutos maduros y espigas. Lo que se llevara a Dios debía ser lo mejor de su clase, aunque solo fueran espigas verdes de trigo.
Sobre ellos había que poner aceite e incienso . La sabiduría y la humildad suavizan y endulzan el espíritu y el servicio de la gente joven, y así sus espigas verdes de trigo serán aceptables. Dios se agrada en las primicias maduras del fruto del Espíritu y en las expresiones de temprana piedad y devoción. El amor santo a Dios es el fuego en que deben hacerse todas nuestras ofrendas. El incienso denota la mediación e intercesión de Cristo, por medio de quien es aceptado nuestro servicio. Bendito sea Dios que tenemos la sustancia, de la cual estas observancias eran solo sombras. Hay una excelencia en Cristo y en su obra como Mediador, que ningún tipo ni sombra pueden representar plenamente. Nuestra dependencia en esto debe ser tan completa que nunca lo perdamos de vista en lo que hagamos, si hemos de ser aceptos a Dios.</p>
<br/>




</div>
