<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Jueces 17</h2>
<p class="text-justify">Vv. 1-6.Lo que se relata en este capítulo y los restantes hasta el final de este libro, ocurrió poco después de la muerte de Josué, véase capítulo xx, 28. Para destacar lo feliz que era la nación bajos los Jueces, se muestra cuán desdichados eran cuando no había juez. El amor del dinero hizo tan irresponsable a Micaía hacia su madre que le robó y ella se volvió tan mala con su hijo como para maldecirlo. Las pérdidas externas guían a la gente buena a orar, pero a los malos a maldecir. La plata de esta mujer ya era su dios antes que fuera hecha imagen esculpida o fundida.
Micaía y su madre se pusieron de acuerdo para convertir su dinero en un ídolo e instauraron el culto a los ídolos en su familia.
Nótese la causa de esta corrupción. Cada uno hacía lo que bien le parecía, y pronto hicieron lo malo ante los ojos del Señor.</p>
<br/>
<p class="text-justify">Vv. 7-13.Micaía interpretó como señal del favor de Dios para él y sus imágenes la llegada de un levita a su puerta. De esta manera, los que se complacen en sus engaños, si la providencia trae inesperadamente a sus manos algo que los adentra más en su mal camino, son dados a pensar que Dios está complacido con ellos.</p>
<br/>




</div>
