<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Amós 2</h2>
<p class="text-justify">Vv. 1-5.Las malas pasiones del corazón surgen en varias formas, pero el Señor mira nuestros motivos y nuestra conducta. Quienes tratan cruelmente, serán tratados con crueldad.
Otras naciones fueron tratadas por las injurias infligidas a los hombres; Judá es tratada por deshonrar a Dios. Judá despreció la ley del Señor y Él los entregó justamente a fuertes engaños; tampoco fue excusa de sus pecados que fueran las mentiras, los ídolos tras los cuales anduvieron sus padres. Las peores abominaciones y las opresiones más penosas han sido cometidas por algunos de los adoradores profesantes del Señor. Tal conducta lleva a muchos a la incredulidad y a la vil idolatría.</p>
<br/>
<p class="text-justify">Vv. 6-16.A menudo necesitamos que se nos recuerden las misericordias que hemos recibido; lo cual agrega mucho al mal de los pecados que hemos cometido. Ellos tuvieron ayuda para sus almas, que les enseñó a usar bien sus goces terrenales y, por tanto, fueron más valiosos. Los ministros fieles son gran bendición para todo pueblo, pero es Dios quien los levanta para que sean así. Las propias conciencias de los pecadores darán testimonio que Él no les ha faltado a ellos en los medios de gracia.
Ellos hicieron lo que pudieron para desviar a los creyentes. Satanás y sus agentes están ocupados en corromper la mente de la juventud que mira al cielo; vencen a muchos llevándolos a que amen la alegría y el placer y la compañía de ebrios. Multitudes de jóvenes que andaban bien como profesantes de la religión, han errado por beber mucho, y han sido desechados para siempre. El Señor se queja del pecado, especialmente de los pecados de su pueblo profesante, como carga para Él. Aunque su paciencia se canse, no así su poder y así lo descubrirá el pecador a su costo. Cuando los hombres rechazan la palabra de Dios, y agregan obstinación al pecado, y esto se convierte en el carácter general de un pueblo, serán entregados a la miseria, a pesar de todo su ostentación de poder y de recursos. Entonces, humillémonos ante el Señor por toda nuestra ingratitud e infidelidad.</p>
<br/>




</div>
