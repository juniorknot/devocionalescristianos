<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Sofonías 1</h2>
<p class="text-justify">Vv. 1-6.La ruina viene, la ruina total; destrucción de parte del Todopoderoso. Todos los siervos de Dios proclaman: No hay paz para el impío. Las expresiones son figuradas, hablando de desolación por doquier; la tierra quedará sin habitantes.
Los pecadores que serán consumidos son los idólatras confesos, y los que adoran a Jehová y a los ídolos, o que juran al Señor y a Milcom. Los que piensan que pueden dividir sus afectos y adoración entre Dios y los ídolos, no alcanzarán la aceptación de Dios, porque, ¿qué comunión puede haber entre la luz y las tinieblas? Si Satanás tiene la mitad, tendrá todo; si el Señor tiene la mitad, no tendrá nada. Rechazar a Dios demuestra impiedad y desprecio. Que ninguno de nosotros esté entre los que vuelven a la perdición, sino entre los que creen para salvación del alma.</p>
<br/>
<p class="text-justify">Vv. 7-13.El día de Dios está cerca; el castigo de los pecadores presuntuosos es un sacrificio a la justicia de Dios. A la familia real judía se le llamará a cuentas por su orgullo y vanidad; y también a los que saltan al umbral, invadiendo los derechos de sus vecinos y tomando sus pertenencias. La gente que comercia y los mercaderes ricos son llamados a rendir cuentas. Se llama a cuentas al pueblo seguro e indolente. Ellos están seguros y cómodos; dicen en su corazón: el Señor no hará el bien ni hará el mal; esto es, ellos niegan sus recompensas y castigos. Pero en el día del juicio del Señor, se manifestará claramente que los que perecen, caen como sacrificio a la justicia divina por quebrantar la ley de Dios, y porque no tienen un interés, por fe, en el sacrificio expiatorio del Redentor.</p>
<br/>
<p class="text-justify">Vv. 14-18.Esta advertencia de la cercana destrucción es suficiente para hacer que tiemblen los pecadores de Sión; se refiere al gran día de Jehová, el día en que Él se mostrará vengándose de ellos. Este día de Jehová está muy cerca; es el día de la ira de Dios, ira al extremo. Será día de angustia y aflicción para los pecadores. Que no se queden dormidos por la paciencia de Dios. ¿Qué le aprovecha al hombre si gana todo el mundo y pierde su alma? ¿Qué recompensa dará el hombre por su alma? Huyamos de la ira venidera y elijamos la buena parte que no nos será quitada; entonces estaremos preparados para todo acontecimiento; nada nos separará del amor de Dios en Cristo Jesús Señor nuestro.</p>
<br/>




</div>
