<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Reyes 5</h2>
<p class="text-justify">Vv. 1-9.Aquí está la determinación de Salomón para construir un templo. No hay adversario, no hay un Satanás, esta es la palabra: ningún instrumento del diablo para oponerse ni para desviar esto. Satanás hace todo lo que puede por estorbar la obra del templo.
Cuando no hay mal alrededor, estemos listos y activos en lo que es bueno y vamos adelante. Que las promesas de Dios vivifiquen nuestros esfuerzos. Que toda destreza y ventaja externa sean puestas al servicio de los intereses del reino de Cristo.
Si Tiro abastece a Israel con obreros, Israel suplirá de trigo a Tiro, Ezequiel xxvii, 17. Así, pues, por la sabia disposición de la Providencia, un país necesita del otro y se beneficia de otro para que haya interdependencia entre ellos para gloria de Dios.</p>
<br/>
<p class="text-justify">Vv. 10-18.El templo fue edificado principalmente con las riquezas y trabajos de los gentiles, lo que tipifica el llamarlos a ser parte de la iglesia. Salomón mandó y ellos trajeron piedras costosas para el cimiento. Cristo que es puesto como el fundamento, es una piedra escogida y preciosa. Nosotros debemos echar nuestro fundamento con firmeza, y depositar la mayor parte de las penas en aquella parte de nuestra fe que yacen fuera de la vista de los hombres. Bienaventurados los que, como piedras vivas, van siendo edificados en una casa espiritual para habitación de Dios en el Espíritu. ¿Quién de nosotros edificará la casa del Señor?</p>
<br/>




</div>
