<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Nahum 3</h2>
<p class="text-justify">Vv. 1-7.Cuando son derribados los pecadores soberbios, los demás debieran aprender a no elevarse a sí mismos. La caída de esta gran ciudad debe ser una lección para las personas particulares que aumentan riqueza por el fraude y la opresión. Están preparando enemigos contra sí mismos; y si place al Señor castigarlos en este mundo, no tendrán a nadie que los compadezca. Todo hombre que busca su propia prosperidad, seguridad y paz, no sólo actuará en forma recta y honorable, sino con bondad hacia todos.</p>
<br/>
<p class="text-justify">Vv. 8-19.Las fortalezas, aun las más poderosas, no tienen defensa contra los juicios de Dios. Serán incapaces de hacer nada a su favor.
Los caldeos y los medos devorarían la tierra como gusanos carcomedores. Los asirios también serían comidos por sus numerosos soldados contratados, lo que parece estar indicado por la palabra que se traduce “mercaderes”. Los que han hecho el mal a su prójimo, encontrarán que el mal se vuelve contra ellos. Nínive, y muchas otras ciudades, estados e imperios, han sido destruidos, y debieran servirnos de advertencia. ¿Somos mejores, excepto que hay unos cuantos cristianos verdaderos entre nosotros, que son la mayor seguridad y una defensa más fuerte, que todas las ventajas de la situación o de poder? Cuando el Señor se muestra contra un pueblo, todo aquello en que confíen debe fallar o resultar desventajoso; pero Él sigue haciendo el bien a Israel. Él es una fortaleza para todo creyente en tiempos difíciles, la cual no puede ser asaltada ni tomada; y conoce a los que confían en Él.</p>
<br/>




</div>
