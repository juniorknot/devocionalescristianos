<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Esdras 2</h2>
<p class="text-justify">Vv. 1-35.Se llevó un registro de las familias que regresaron del cautiverio. Véase cuánto reduce el pecado a una nación, ¡pero cuánto la exalta la justicia!</p>
<br/>
<p class="text-justify">Vv. 36-53.Quienes menosprecian su relación con el Señor en tiempos de reprensión, persecución o angustia, no tendrán beneficios de ella cuando se vuelva honorable o provechosa. Los que no tienen evidencia de ser sacerdotes espirituales para Dios, por el nuevo nacimiento por medio de Jesucristo, no tienen derecho a las consolaciones y privilegios de los cristianos.</p>
<br/>
<p class="text-justify">Vv. 64-70.Que nadie se queje de los gastos necesarios de su religión. Buscad primero el reino de Dios, su favor y su gloria, entonces todas las otras cosas os serán añadidas. Sus ofrendas eran nada, comparadas con las ofrendas de los príncipes de la época de David; pero, siendo proporcionales a su capacidad, fueron igualmente aceptables para Dios. El Señor nos conducirá por todas las empresas que comencemos conforme a su voluntad, si el objetivo es su gloria y dependemos de su ayuda. Quienes, al llamado del evangelio, renuncian al pecado y se vuelven al Señor, serán guardados y guiados a través de todos los peligros del camino, y llegarán a salvo a las mansiones provistas en la santa ciudad de Dios.</p>
<br/>




</div>
