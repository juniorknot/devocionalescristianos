<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Job 10</h2>
<p class="text-justify">Vv. 1-7.Estando cansado de la vida Job resuelve quejarse, pero no acusa a Dios de injusticia. Aquí hay una oración pidiendo que él sea librado del aguijón de sus aflicciones, que es el pecado. Dios contiende con nosotros cuando nos aflige; cuando contiende con nosotros siempre hay una razón, siendo deseable conocer la razón para arrepentirnos y abandonar el pecado por el cual Dios contiende con nosotros. Pero cuando, como Job, hablamos con amargura de nuestra alma aumentamos la culpa y el sufrimiento. No abriguemos malos pensamientos contra Dios; de ahí en adelante veremos que no había causa para ellos.
Job está seguro de que Dios no descubre las cosas ni las juzga como lo hacen los hombres; por tanto, piensa que es extraño que Dios lo siga afligiendo como si debiera tomarse tiempo para inquirir sobre su pecado.</p>
<br/>
<p class="text-justify">Vv. 8-13.Job parece discutir con Dios como si sólo lo hubiera formado y preservado para la desgracia. Dios nos hizo, no nosotros. ¡Cuán triste es que esos cuerpos sean instrumentos de injusticia, siendo capaces de ser templos del Espíritu Santo! Pero el alma es la vida, el alma es el hombre y esta es dádiva de Dios. Si argumentamos con nosotros mismos como inducción al deber, Dios me hizo y me sostiene, podríamos argumentar en pro de la misericordia: Tú me hiciste, hazme de nuevo; yo soy tuyo, sálvame.</p>
<br/>
<p class="text-justify">Vv. 14-22.Job no niega que como pecador merece sus sufrimientos; sólo piensa que la justicia se ejecuta en él con rigor peculiar. Su desaliento, incredulidad y malos pensamientos acerca de Dios, se pueden atribuir a tentaciones internas de parte de Satanás, y a la angustia de su alma, sometida a la sensación del desagrado de Dios, a sus pruebas externas, y a vestigios de su depravación. Nuestro Creador, hecho también nuestro Redentor en Cristo, no destruirá la obra de sus manos en ningún creyente humilde; sino lo renueva para santidad a fin de que pueda disfrutar la vida eterna. Si la angustia en la tierra hace que la tumba sea un refugio deseable, ¿cuál será el estado de los que están condenados a la negrura de las tinieblas para siempre? Que todo pecador busque la liberación de ese estado espantoso, y cada creyente agradezca a Jesús que lo haya librado de la ira venidera.</p>
<br/>




</div>
