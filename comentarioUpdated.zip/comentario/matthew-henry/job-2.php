<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Job 2</h2>
<p class="text-justify">Vv. 1-6.¡Qué bueno para nosotros que los hombres ni los diablos sean nuestros jueces! sino que todo nuestro enjuiciamiento venga del Señor que nunca yerra. Job esgrime firme su integridad como arma suya. Dios habla con placer del poder de su propia gracia.
El amor a sí mismo y la conservación de sí mismo son muy fuertes en los corazones humanos. Pero Satanás acusa a Job presentándolos como completamente egoísta sin que nada le importe salvo su propio bienestar y seguridad. De este modo el pueblo de Dios y sus caminos son falsamente acusados a menudo por el diablo y sus agentes. Se le da permiso a Satanás para que haga pruebas pero con límites. Si Dios no encadenara al león rugiente, ¡qué pronto nos devoraría! -Job, asi calumniado por Satanás, fue un tipo de Cristo, cuya primera profecía fue que Satanás le heriría el calcañar y sería aniquilado.</p>
<br/>
<p class="text-justify">Vv. 7-10.El diablo tienta a sus propios hijos y los lleva a pecar y, luego, los atormenta, cuando los ha conducido a la ruina; pero atormentó con aflicción a este hijo de Dios y, luego, le tentó para que usara malamente su aflicción. Él provocó a Job para que maldijera a Dios.
La enfermedad era muy penosa. Si somos probados en cualquier momento con dolencias penosas y dolorosas, no pensemos que somos tratados de otro modo con que Dios trata a veces a lo mejor de Sus santos y siervos. Job se humilló bajo la poderosa mano de Dios y niveló su mente con su estado.
Su esposa le fue conservada para que le produjera problemas y lo tentara. Satanás todavía trata de quitarle hombres a Dios, como lo hizo con nuestros primeros padres, sugiriendo fuertes pensamientos de tentación. -¿Nosotros , criaturas culpables, contaminadas, indignas, recibiremos tantas bendiciones inmerecidas de un Dios santo y justo, y nos rehusaremos a aceptar el castigo de nuestros pecados, cuando sufrimos tanto menos de lo que merecemos? Terminemos por siempre con las quejas como asimismo con la jactancia. Hasta ahora Job ha soportado la prueba y apareció más brillante en el horno de la aflicción. Puede que hubiera marejadas de corrupción en su corazón pero la gracia siempre venció.</p>
<br/>
<p class="text-justify">Vv. 11-13.Los amigos de Job parecían ser personas connotadas por sus rangos como asimismo por su sabiduría y piedad. Gran parte del consuelo de esta vida radica en la amistad con el prudente y virtuoso. Yendo a lamentarse con él, ellos manifestaron la pena que realmente sentían. Yendo a consolarlo, se sentaron con él. Pareciera que sospechaban que sus problemas sin precedentes eran juicios por algunos delitos que él (Job) había velado bajo su profesada santidad. Muchos consideran que es un cumplido ir a visitar a sus amigos afligidos; debemos considerarlo como deber: si la religión vive en el corazón, esto será un fruto de la vida. Y si no basta con el ejemplo de los amigos de Job para llevarnos a compadecer al afligido, busquemos la mente que estaba en Cristo.</p>
<br/>




</div>
