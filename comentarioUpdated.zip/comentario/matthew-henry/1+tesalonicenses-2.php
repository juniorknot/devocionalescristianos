<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Tesalonicenses 2</h2>
<p class="text-justify">Vv. 1-6.El apóstol no tenía motivación mundana para predicar. Sufrir en una buena causa debe aguzar la santa resolución. El evangelio de Cristo encontró primero mucha resistencia y fue predicado con contención, con esfuerzo al predicar, y en contra de la oposición. Como el tema de la exhortación del apóstol era verdadero y puro, su manera de hablar era sin maldad. El evangelio de Cristo está concebido para mortificar los afectos corruptos, y para que los hombres puedan ser llevados a someterse al poder de la fe. Debemos recibir nuestra recompensa de este Dios que prueba nuestros corazones. Las pruebas de la sinceridad del apóstol era que él evitaba el halago y la codicia. Evitaba la ambición y la vanagloria.</p>
<br/>
<p class="text-justify">Vv. 7-12.La suavidad y la ternura dan mucho prestigio a la religión y están en armonía con el trato bondadoso de Dios con los pecadores en el evangelio y por el evangelio. Esta es la manera de ganar gente. No sólo debemos ser fieles a nuestra vocación cristiana sino a nuestros llamados y relaciones particulares. Nuestro gran privilegio en el evangelio es que Dios nos ha llamado a su reino y gloria. El gran deber del evangelio es que andemos en forma digna de Dios. Debemos vivir como corresponde a los llamados con tan elevada y santa vocación. Nuestra gran actividad es honrar, servir y complacer a Dios y procurar ser dignos de Él.</p>
<br/>
<p class="text-justify">Vv. 13-16.Debemos recibir la palabra de Dios con afectos que armonicen con su santidad, sabiduría, verdad y bondad. Las palabras de los hombres son frágiles y perecederas, como ellos mismos, y a veces, falsas, necias y triviales, pero la palabra de Dios es santa, sabia, justa y fiel. Recibámosla y considerémosla de manera concordante.
La palabra obró en ellos para ser para los demás ejemplo de fe y buenas obras, y de paciencia en los sufrimientos, y en las pruebas por amor del evangelio.
El asesinato y la persecución son odiosos para Dios y ningún celo por nada de la religión pueden excusarlos. Nada tiende más a que una persona o un pueblo llene la medida de sus pecados que oponerse al evangelio y obstaculizar la salvación de almas. El puro evangelio de Cristo es aborrecido por muchos y su predicación fiel es estorbada de muchas maneras. Pero los que prohíben que se le predique a los pecadores, a hombres muertos en pecados, no complacen con esto a Dios. Los que niegan la Biblia a la gente, tienen corazones crueles y son enemigos de la gloria de Dios, y de la salvación de su pueblo.</p>
<br/>
<p class="text-justify">Vv. 17-20.Este mundo no es lugar donde estaremos juntos para siempre o por mucho tiempo. Las almas santas se encontrarán en el cielo y nunca más se separarán. Aunque el apóstol no pudiera ir a visitarlos aún, y aunque nunca pudiese ir, sin embargo, nuestro Señor Jesucristo vendrá; nada lo impedirá. Que Dios dé ministros fieles a todos los que le sirven con su espíritu en el evangelio de su Hijo, y los envíe a todos los que están en tinieblas.</p>
<br/>




</div>
