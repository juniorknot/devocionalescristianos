<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">1 Reyes 16</h2>
<p class="text-justify">Vv. 1-14.Este capítulo se relaciona totalmente con el reino de Israel y las revoluciones de ese reino. Dios aún llama a Israel su pueblo, aunque desgraciadamente corrompido. Jehú anuncia que vendría sobre la familia de Baasa, la misma destrucción que ese rey había traído sobre la familia de Jeroboam. Quienes se parecen a otros en sus pecados, pueden esperar parecérseles en las plagas que sufren, especialmente los que parecen celosos de pecados en otros que son como los que se permiten a sí mismos.
El mismo Baasa muere en paz y es enterrado con honor. Aquí se ve claramente que hay castigo después de la muerte, que es lo que más hay que temer.
Que Ela sea una advertencia para los borrachos que sólo saben que la muerte puede sorprenderlos. La muerte viene fácilmente a los hombres cuando están ebrios. Además de las enfermedades que se acarrean los hombres cuando beben, cuando se hallan en ese estado, los hombres son fácilmente vencidos por un enemigo y proclives a graves accidentes. La muerte viene en forma terrible a los hombres en tal estado, los halla en el acto del pecado e inútiles para un acto de devoción. Ese día les llega sin que se den cuenta. La Palabra de Dios se cumplió y se tomó cuenta de los pecados de Baasa y Ela porque con ellos provocaron a Dios. Sus ídolos son llamados vanidades, porque los ídolos no aprovechan ni socorren; miserables son quienes tienen como dioses sus vanidades.</p>
<br/>
<p class="text-justify">Vv. 15-28.Cuando los hombres abandonan a Dios son entregados a una plaga tras otra. Los hombres soberbios se arruinan mutuamente. Omri luchó con Tibni durante unos años. Aunque no siempre entendemos las reglas por las cuales Dios gobierna las naciones e individuos en su providencia, podemos aprender lecciones útiles de la historia que tenemos ante nosotros. Cuando los tiranos se suceden unos a otros y hay masacres, conspiraciones y guerras civiles, podemos tener toda la seguridad de que el Señor tiene una controversia con el pueblo por sus pecados; ellos son llamados a gran voz al arrepentimiento y a reformarse.
Omri se hizo infame por su maldad. Muchos hombres malos han sido hombres de poder y renombre; han construido ciudades y sus nombres se hallan en la historia, pero no tienen su nombre en el libro de la vida.</p>
<br/>
<p class="text-justify">Vv. 29-34.Acab hizo lo malo más que todos los que reinaron antes que él, y lo hizo con particular encono contra Jehová e Israel. No se satisfizo con romper el segundo mandamiento adorando imágenes; también quebrantó el primero adorando otros dioses: tomar a la ligera los pecados menores, abre el camino para los mayores.
Casarse con otros ofensores atrevidos también acrecienta la maldad y apresura a los hombres a ir a los más grandes excesos.
Uno de los súbditos de Acab, siguiendo el ejemplo de su osadía se aventuró a reconstruir Jericó. Como Acán, se metió con el anatema; tomó para uso propio lo que estaba dedicado a la honra de Dios: empezó a edificar desafiando la maldición bien conocida en Israel; pero nunca alguien endureció su corazón contra Dios y prosperó.
Que la lectura de este capítulo nos haga notar el fin horroroso de todos los hacedores de iniquidad. ¿Y qué entrega la historia de todos los hombres impíos, cualquiera haya sido el rango o situación en que se movieron, sino tristes ejemplos de lo mismo?</p>
<br/>




</div>
