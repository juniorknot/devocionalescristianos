<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Mateo 2</h2>
<p class="text-justify">[1] Note que el Hijo de YHWH era para gobernar para siempre sobre Israel, no como una &quot;entidad separada,&quot; o iglesia gentil.
[2] La destrucción de los hijos de Judah se encuadra con los hijos de Efrayím que fueron asesinados, o dispersados unos 700 años antes. Las lágrimas de Rajel son para todo Israel que vuelve de la muerte, como es visto en Jer 31:17.
[3] Isaías.</p>
<br/>




</div>
