<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Mateo 27</h2>
<p class="text-justify">[1] No-Israelitas.
[2] Referencia Shem Tov y Peshitta.
[3] Referencia Shem Tov.
[4] Desde un punto de vista positivo y no anti Semita, pueda YHWH contestar esta oración que la sangre de Moshiaj sea sobre toda Judah para Su amorosa redención.
[5] Referencia Shem Tov.
[6] Monte de los Olivos.
[1] YHWH - Yahshua Hanotzrei Wemelej HaYahudim.
[2] Ciertamente un cuadro de los dos hijos de YHWH, Judah y Efrayím.
[3] Referencia Shem Tov.
[4] Encaja con el Arameo pero no con el Griego. En el Arameo Yahshua está principalmente cuestionando el porque el sufrimiento dura tanto. El no está acusando a YHWH de haberlo olvidado, ni tampoco está confundido en pensando en que El haya sido olvidado, ya que El es YHWH y conoce los planes de El Padre. El Mismo, que declaró que podía llamar a 12 legiones de angeles para que Lo liberaran, y El Mismo, que dicho que El Padre nunca Lo dejaría sólo aún cuando todos los discípulos lo hicieron, El nunca sostendría el haber sido abandonado. Puesto que no puede significar abandonado, la palabra shabakthani ya que puede también signficar guardarme, o preservarme. En este contexto, ésto es el significado obvio. Puesto que Yahshua nunca acusaría, o creería que YHWH Lo había abandonado, Salmo 22 puede ser visto todavía como una narrativa de El Siervo Sufriente, pero las palabras literales del Sal 22:1-2 nunca saldrían de la boca de Yahshua. En este caso, la evidencia del significado Arameo es claramente superior a la del Griego, y sostiene que la petición de Yahshua es una impronta de Su sufrimiento (en Sus seis horas), en oposición a una acusación contra El haber sido olvidado por YHWH.
[5] Mar 15:34.
[6] Puesto que Eli-Yahu-Weh suena como Eli-Yahu.
[7] El velo al Lugar Apartado (Lugar Santo), no el velo del Lugar más Apartado (Lugar Santísimo).</p>
<br/>




</div>
