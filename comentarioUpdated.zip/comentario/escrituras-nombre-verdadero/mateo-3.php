<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Mateo 3</h2>
<p class="text-justify">[4] En la Peshitta Aramea se lee “profeta” no profetas, como lo hace la Griega. Esto es un cumplimiento de Isa 11:1-2, Donde el Moshiach es llamado el Natzer, o Vara del plantel de YHWH. Así que en lo natural El vino y habitó en la ciudad llamada Natzeret, de la raíz de la palabra Hebrea para vástago- Natzer, o Netzer dependiendo de la pronunciación.
[5] El tan esperado Rey Celestial, y Su solución al exilio de Israel y de la división de las dos casas.
[6] Keruvah en Hebreo significa &quot;ofrecido,&quot; como en hacerse muy cercano.
[7] Referencia del Hebreo del Shem Tov.
[1] Mashiaj vendrá para refinar las dos casas en una, a través de quitar todos los malos frutos.
[2] Referencia del Shem Tov.
[3] Una clara referencia a Israel.</p>
<br/>




</div>
