<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 1</h2>
<p class="text-justify">Dios Habla Hoy 1996 Notes:
[1] 1.1 Este primer relato presenta, en el marco de una semana, el origen del universo, culminando con la creación del género humano: todo procede de Dios y todo es bueno.
[2] 1.6 Y así fue: según la versión griega (LXX) y la estructura literaria del relato (cf. Gn 1.9,11, etc.). En el texto hebreo la frase aparece al final del v. 7.
[3] 1.20 Y así fue: según la versión griega (LXX). En el texto hebreo no aparece esta frase.
[4] 1.27 Hombre: heb. adam, designa aquí a todo el género humano; en otros pasajes, este mismo término tiene el valor de un nombre propio (Adán). Cf. Gn 4.25.
[5] 1.28 Que se arrastran: otra posible traducción: que se mueven, en referencia a todos los seres terrestres.</p>
<br/>




</div>
