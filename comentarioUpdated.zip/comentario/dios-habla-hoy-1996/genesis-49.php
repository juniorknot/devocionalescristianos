<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 49</h2>
<p class="text-justify">Dios Habla Hoy 1996 Notes:
[1] 49.3-4 Gn 35.22; Dt 33.6.
[2] 49.5 Antes de llegar a ser la tribu sacerdotal de Israel (cf. Nm 3.6-10), la tribu de Leví era una tribu como las demás, con su territorio cercano al de Simeón (cf. Gn 34.25).
[3] 49.6 Gn 34.24-30.
[4] 49.10 Hasta que venga el dueño del cetro: traducción poco segura de un texto muy oscuro. Con una ligera modificación en la ortografía del texto hebreo, y con el apoyo de varias versiones antiguas, algunos traducen: hasta que a él le llegue el tributo.
[5] 49.12 Sus ojos... que la leche: otra posible traducción: Sus ojos relucen a causa del vino; sus dientes están blancos a causa de la leche.
[6] 49.13 Dt 33.18-19; Jos 19.10-16.
[7] 49.14 Que descansa en sus establos: otra posible traducción: que está echado entre su par de alforjas (sin que pueda levantarse).
[8] 49.16 Gobernará: Aquí hay un juego de palabras con el nombre de Dan (véase 30.6-13 n.) y el término hebreo yadín, que significa él gobernará o él hará justicia.
[9] 49.20 Abundancia de pan: otra posible traducción: alimentos sustanciosos. Evidente alusión a los terrenos fértiles de Aser, en las laderas del monte Carmelo
[10] 49.30 Gn 23.1-20.
[11] 49.31 Gn 25.9-10; 35.27-29.</p>
<br/>




</div>
