<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 3</h2>
<p class="text-justify">Dios Habla Hoy 1996 Notes:
[1] 3.1 La tradición posterior vio en la serpiente un símbolo del diablo: Cf. Sab 2.24; Jn 8.44; Ap 12.9.
[2] 3.20 En hebreo, el nombre Eva y la palabra que significa vida o viviente tienen un sonido semejante
[3] 3.24 Estos seres alados, lit. querubines, eran considerados en el antiguo Oriente como guardianes de los templos y de los lugares sagrados. Véase Ex 25.18 n.</p>
<br/>




</div>
