<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 2</h2>
<p class="text-justify">Dios Habla Hoy 1996 Notes:
[1] 2.2 Descansó: El verbo hebreo, que significa lit. cesar o terminar, se relaciona con el nombre shabat (= sábado, día de reposo ). Cf. Ex 20.11.
[2] 2.4 El segundo relato se centra en la pareja humana, en su destino y descendencia y en su relación con Dios.
[3] 2.4 El Señor: traducción de Yahvé, el nombre propio del Dios de Israel.
[4] 2.7 El texto hebreo hace un juego de palabras entre los vocablos adam, que significa hombre, y adamá, que significa suelo o tierra cultivable (véase el mismo procedimiento en Gn 3.19). Así se destaca la estrecha vinculación que existe entre el hombre y la tierra.
[5] 2.8 Edén es una palabra hebrea que significa delicia (cf. Is 51.3; Ez 31.8-9).
\par [6] 2.9 El árbol de la vida: es decir, cuyos frutos dan la vida. Cf. Gn 3.22.
\par [7] 2.9 El árbol del conocimiento del bien y del mal: es decir, tener plena autonomía en el campo moral. Cf. Gn 3.22.
[8] 2.24 Mt 19.5; Mc 10.7-8; 1 Co 6.16; Ef 5.31. Este v. pone de relieve la dignidad y el sentido profundo de la unión matrimonial.</p>
<br/>




</div>
