<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 50</h2>
<p class="text-justify">Dios Habla Hoy 1996 Notes:
[1] 50.5 Gn 47.29-31.
[2] 50.11 Abel-misraim: sitio no identificado, cuyo nombre significa pradera de los egipcios. Este nombre tiene un sonido semejante al de las palabras hebreas que significan luto de los egipcios.
[3] 50.18 Una vez más, los hermanos hacen lo que habían preanunciado los sueños de José (Gn 37.5-11; 42.6).
[4] 50.25 Ex 13.19; Jos 24.32.</p>
<br/>




</div>
