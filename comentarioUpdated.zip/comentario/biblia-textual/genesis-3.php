<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 3</h2>
<p class="text-justify">&apos;Elohim. Nótese la omisión del nombre personal de Dios.</p>
<br/>
<p class="text-justify">comer. Nótese la omisión g2.16.</p>
<br/>
<p class="text-justify">toquéis. Nótese la adición g2.16.
3.3 muráis. Nótese la alteración g2.17.</p>
<br/>
<p class="text-justify">En reminiscencia a gIsa 14:14.</p>
<br/>
<p class="text-justify">comer. Lit. comida.</p>
<br/>
<p class="text-justify">LXX y Tárgum registran el plural hojas.
3.7 ceñidores. Heb. jagorot = cintos, delantales.</p>
<br/>
<p class="text-justify">contestó. Lit. dijo.</p>
<br/>
<p class="text-justify">Heb. nasha = dar falsas esperanzas.</p>
<br/>
<p class="text-justify">É</p>
<br/>
<p class="text-justify">tierra. Lit. suelo.</p>
<br/>
<p class="text-justify">eres. Lit. tú.</p>
<br/>
<p class="text-justify">Eva. Heb. javah, similar a jay = viviente.</p>
<br/>




</div>
