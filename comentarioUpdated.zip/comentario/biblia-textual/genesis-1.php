<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 1</h2>
<p class="text-justify">principio g §33
1.1 &apos;Elohim g §2.</p>
<br/>
<p class="text-justify">desolada g §34.
1.2 revoloteaba g §35.</p>
<br/>
<p class="text-justify">separación idéntico a gNúm 16:9.</p>
<br/>
<p class="text-justify">Comp. el número cardinal g1.5 con Mat 28:1 nota.</p>
<br/>
<p class="text-justify">LXX omite Y fue así.</p>
<br/>
<p class="text-justify">solemnidades (heb. moadim) Aplicable a tiempos específicos divinos gLev 23:2.</p>
<br/>
<p class="text-justify">Bullan. Es decir, produzcan abundantemente.
1.20 seres. Heb. nefesh = persona, alma, mente, vida.</p>
<br/>
<p class="text-justify">Heb. taninim = monstruos marinos. Se refiere a dinosaurios y otras especies, tanto marinas como terrestres. Aparece solo una vez en el TM.</p>
<br/>
<p class="text-justify">hombre (heb. adam). Aquí no es nombre propio sino sustantivo. Por tratarse del primer ser humano, la palabra adam también se aplica en el sentido de humanidad.
1.26 hombre... ejerzan. Notese el singular y el plural.</p>
<br/>
<p class="text-justify">dijo. Dios bendice y le dice al hombre, en contraste con los animales gv. 22 que los bendice diciendo. A diferencia de estos, Dios establece una relación personal con el hombre, conversa con g3.9, 35.9-10 y lo conoce por nombre gMat 16:18.</p>
<br/>
<p class="text-justify">Nótese el artículo.</p>
<br/>




</div>
