<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 49</h2>
<p class="text-justify">Heb. Mejerot. Prob. cuchillos cortos de doble filo para circuncidar gGn. 34.25.</p>
<br/>
<p class="text-justify">Simeón fue pronto absorbido por Judá, y Leví no tuvo territorio propio.</p>
<br/>
<p class="text-justify">El vocablo Siloh tiene un significado incierto. Algunas versiones lo traducen por tributo, otras por un nombre propio aplicado al Mesías. También se ha propuesto la grafía shelo = que es suyo. LXX traduce: las cosas reservadas para él.</p>
<br/>
<p class="text-justify">Esta tribu se habría de asentare en la costa, al S de Fenicia.</p>
<br/>
<p class="text-justify">LXX : Isacar ha deseado lo que es bueno... descansa entre las heredades.</p>
<br/>
<p class="text-justify">Asentado en zonas mu y fértiles, entre el Carmelo y Tiro.</p>
<br/>
<p class="text-justify">Lit. pueblos.</p>
<br/>




</div>
