<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 50</h2>
<p class="text-justify">Esto es, la era de la esquina.</p>
<br/>
<p class="text-justify">Esto es, duelo de egipcios.</p>
<br/>
<p class="text-justify">g37.10.</p>
<br/>
<p class="text-justify">Constituye la mitad de la tribu de Manases, la cual habitó al Oriente del Jordán.
50.23 Es decir, fueron adoptados por José.</p>
<br/>
<p class="text-justify">-24-25 Es decir, determinará vuestro destino.</p>
<br/>




</div>
