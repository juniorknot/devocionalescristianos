<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 2</h2>
<p class="text-justify">ejército. El vocablo heb. tsaba se aplica tanto a elementos físicos (astros, soldados) como a espirituales (ángeles).</p>
<br/>
<p class="text-justify">descansó (heb. shabbat = descansar, cesar). No solo se refiere descanso físico sino también indica la cesación de una obra. De shabbat procede la palabra sábado.</p>
<br/>
<p class="text-justify">YHVH g §3.
2.4 cielos. Nótese el cambio en el orden: los cielos y la tierra... tierra y cielos.</p>
<br/>
<p class="text-justify">Es decir, aún no se había iniciado el ciclo de condensación y precipitación.</p>
<br/>
<p class="text-justify">Jidequel. Esto es, el río Tigris.
2.14 Éufrates. Heb. Perat.</p>
<br/>
<p class="text-justify">libremente. Lit. comiendo comerás. Indica énfasis.</p>
<br/>
<p class="text-justify">ciertamente. Lit. muriendo morirás. Indica énfasis.</p>
<br/>
<p class="text-justify">hizo. Heb. banah = edificó, construyó.</p>
<br/>
<p class="text-justify">Varona. Heb. &apos;ishshah, femenino de &apos;ish = varón.</p>
<br/>




</div>
