<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 49</h2>
<p class="text-justify">[4] O: “Hubo precipitada licencia como de aguas impetuosas”.
[5] “Búhos reales; hienas”, según otros puntos vocálicos.
[5] “Armas de degüello.” Algunos consideran que la palabra heb. correspondiente a esta frase todavía es inexplicable. El v. 5 en LXXBagster: “Simeón y Leví, hermanos, realizaron la injusticia de cortarlos [de la vida]”.
[6] “Gloria mía”, MVg; LXX: “hígado mío”. Véase VT, vol. II, 1952, pp. 358-362.
[6] O: “un hombre”. Heb.: ’isch, posiblemente en sentido colectivo.
[9] “Como león.” Heb.: ke’ar·yéh, el león africano.
[9] “Y, como león.” Heb.: u·kjela·ví’, el león asiático.
[10] “Cetro.” Heb.: sché·vet; lat.: scép·trum; gr.: ár·kjon, “gobernante”.
[10] O: “ni un comandante”. Heb.: lo’ [...] u·mejo·qéq.
[10] O: “de delante de él”. Compárese con Jue 5:27.
[10] “Siló.” O: “aquel de quien es”. Heb.: Schi·lóh, que significa: “Aquel de Quien Es”, o: “Aquel a Quien Pertenece”; LXX: “las cosas reservadas para él”; Vg: “aquel que ha de ser enviado”.
[10] “Y él será la expectativa de naciones”, LXXVg.
[11] O: “una vid con uvas de color rojo vivo”.
[13] O: “donde las naves desembarcan”.
[15] O: “llegará a ser esclavo bajo trabajos forzados”.
[18] O: “he esperado”.
[18] “Salvación de parte tuya.” Heb.: li·schu·`oth·kjá; esta es la primera vez que aparece este sustantivo. La palabra heb. yeschu·`áh, “salvación”, tiene la misma raíz que los nombres bíblicos Jesúa, Josué y Jesús.
[21] O: “ágil”.
[21] O: “Está echando astas ramificadas”.
[22] Lit.: “Hijo”.
[22] Lit.: “hijas”.
[24] Lit.: “los brazos”.
[24] O: “ligera”.
[25] “Del Dios de.” Heb.: me·’Él.
[25] O: “las aguas agitadas”. Vg: “abismo”, como en 1:2.
[26] O: “deseo; a la morada”.
[26] “Singularizado.” Heb.: nezír; en Nú 6:2, 13, 18-20 se tradujo “nazareo”, que significa: “Uno Singularizado; Uno Dedicado; Uno Separado”.
[32] Lit.: “La compra del campo”.</p>
<br/>




</div>
