<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 3</h2>
<p class="text-justify">[2] Lit.: “árbol”, sing., pero en sentido colectivo, para significar una arboleda o bosque.
[4] “Positivamente no morirán.” Lit.: “no muriendo morirán”. Heb.: lo’-móhth temu·thún. Compárese con 2:17.
[5] “Como Dios.” Heb.: kE’·lo·hím, sin el artículo definido. Este título está en pl. para denotar majestad o excelencia.
[6] “Para contemplarlo”, LXXSyVg. Lit.: “para impartir sabiduría (inteligencia; prudencia)”.
[6] O: “a su hombre”. Heb.: le’i·scháh.
[8] O: “el sonido”.
[8] Lit.: “relativo a la brisa de”. Heb.: lerú·aj, la misma palabra básica traducida “fuerza activa” en 1:2.
[8] O: “el hombre terrestre”. Heb.: ha·’a·dhám; LXXSyVg: “y Adán”.
[12] O: “a quien pusiste”.
[14] Heb.: Yeho·wáh. El primero de varios casos en BHS donde el nombre divino tiene el punto vocálico adicional para la “o”. Véanse 2:4, n: “Jehová”; Ap. 1A.
[14] O: “se te maldice como a ningún otro de”.
[14] O: “morderás”.
[15] O: “prole; posteridad; simiente”.
[15] “Él”, M(heb.: hu’)LXXSyVgmss.
[15] Esta traducción concuerda con la referencia que se hace a esta expresión divina en Ro 16:20, donde la palabra gr. empleada significa “aplastar” o “magullar”.
[15] “Le”, MLXXSy; es decir, la “descendencia” (masc. en heb.) de la mujer.
[16] Lit.: “Aumentaré [...] tu dolor y tu preñez”. Esta es una figura de endíadis en la que se coordinan dos palabras con la conjunción “y”, pero se hace referencia a un solo concepto.
[20] Que significa: “Una Viviente”, fem. Heb.: Jaw·wáh; gr.: Zo·é, “Vida”; Vgc(lat.): Hé·va.
[23] Véase 2:4, n: “Dios”.
[24] Lit.: “hizo que residieran”. Véanse Sl 7:5; 78:55; Eze 32:4.</p>
<br/>




</div>
