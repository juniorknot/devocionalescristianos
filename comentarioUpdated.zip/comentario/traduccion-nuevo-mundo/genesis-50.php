<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 50</h2>
<p class="text-justify">[7] O léase: “hombres mayores”.
[10] Lit.: “el Arbusto Espinoso”. Heb.: ha·’A·tádh.
[11] Que significa: “Duelo de los Egipcios”. “Mizraim” es el nombre heb. para egipcios. Véase 10:13.
[15] “Los hermanos de José vieron que su padre había muerto y tuvieron miedo”, Sy; Vg: “Ahora que él estaba muerto, sus hermanos tenían miedo”.
[18] O: “siervos”.
[21] Lit.: “habló al corazón de ellos”.
[23] Lit.: “hijos de los terceros [generados]”.
[24] O: “tierra que él prometió bajo juramento”.</p>
<br/>




</div>
