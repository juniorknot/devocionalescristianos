<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 2</h2>
<p class="text-justify">[7] Todos los días fueron creados por YAHWEH, pero sólo uno fue apartado o dedicado como Kadosh, el Shabbat.
[8] Referencia a la Toráh, Pro 3:18 : &quot; Ella es árbol de vida para aquellos que la agarran; cualquiera que se aferre a ella será feliz.&quot; Deu 32:45 : Por medio de ella [la Toráh] ustedes tendrán larga vida en La Tierra que están cruzando el Yarden para poseer.&quot;
[9] Primera alusión de que hay que trabajar, aun el primer hombre que YAHWEH creó le ordenó &quot;cultivarlo y cuidarlo&quot;, de ahí: 2Th 3:10b: &quot;si alguno no quiere trabajar, no debe comer.&quot;</p>
<br/>




</div>
