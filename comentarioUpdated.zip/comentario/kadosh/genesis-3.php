<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 3</h2>
<p class="text-justify">[10] La mayoría de los pecados vienen por los ojos y fue como el pecado entró en el mundo: 1Jo 2:16 : porque todas las cosas del mundo: … los deseos de los ojos, y las pretensiones de la vida, no son del Padre, sino del mundo.
[11] No es extraño que los humanos no quieran aceptar a Yahshúa y quieran esconderse de El, porque el pecado quiere permanecer en ellos.
[12] Primera promesa del Mesías que vendría. También habla de la nación de Yisra&apos;el que derrotará a la serpiente.</p>
<br/>




</div>
