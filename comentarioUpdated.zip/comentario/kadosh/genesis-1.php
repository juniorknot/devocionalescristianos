<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 1</h2>
<p class="text-justify">[1] Todos los nombres de los libros de la Toráh han sido cambiados y manipulados por los traductores, sin embargo, cada libro lleva el nombre que está en la primera oración del libro, a saber &quot;En el Principio/Bereshit&quot; y no Génesis.
[2] Podemos ver que Elohim Alef Tav que creó los Cielos y la Tierra es claramente Yahshúa (Elohim Hijo o YAHWEH Menor) Heb. &quot;Bereshít bará Elohím &quot;álef-tav&quot; hashamáyim veet haáretz.&quot; Rev 22:12-13. &quot;¡Presten atención!&quot; Dice Yahshúa: &quot;Yo vengo pronto, y mis recompensas están conmigo, para dar a cada persona de acuerdo con sus obras. Yo soy el &apos;Alef&apos; y la &apos;Tav,&apos; El Primero y el Ultimo, el Principio y el Fin.&quot; Heb 1:2b: El nos ha hablado por medio de su Hijo, a quien ha constituido dueño de todo, y por medio de El Creó el universo. (Heb 1:1-3) Abba YAHWEH es el Diseñador-Arquitecto de la Creación. YAHWEH Crea a través de Su Hijo, de acuerdo a Pro 30:4 y 8:22-23-26.
[3] ¿Cómo puede haber luz si YAHWEH creó las luces en el firmamento en el cuarto día ( vv 14-19)? Rev 21:23. La ciudad no tiene necesidad del sol ni de la luna que resplandezcan sobre ella; porque la Shejinah de YAHWEH le da lu z, y su lámpara es el Cordero. Joh 8:12a : Yahshúa les habló de nuevo: &quot;Yo soy la luz del mundo&quot; y Joh 1:4-11.
[4] Aquí vemos la unidad &quot;ejad&quot; entre Padre YAHWEH e Hijo Yahshúa, echad significa una unidad compuesta o una pluralidad en la unidad.
[5] Tárgum de Jonatan de Yerushalayim dice aquí: &quot;La Palabra de Elohim…&quot; Y la Palabra de Elohim es Yahshúa.
[6] En los seis días de la Creación, se creó la noche primero y después el día, por el calendario Lunar, el cual es el Escritural, la humanidad lo ha cambiado todo y ahora usamos un calendario hecho por un papa de Roma, calendario Gregoriano.</p>
<br/>




</div>
