<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 3</h2>
<p class="text-justify">[1] No se ha hablado hasta ahora de la caída de los ángeles rebeldes; pero se la supone en esta narración, porque la serpiente representa un instrumento del mal.
[4] 2 Cor 11, 3.
[5] Puede traducirse Seréis como Dios.
[6] Eclo 25, 33; 1 Tim 2, 14.
[8] Es creíble que durante el estado de la inocencia Dios se dejaba ver de nuestros primeros padres bajo alguna figura acomodada a su condición y que esta aparición del Señor era precedida de algún ligero y suave viento que los avisaba.
[9] No ignoraba Dios en dónde estaba Adán; mas, a manera de un padre lleno de misericordia, invita al hombre a que vuelva en sí. Como si dijera: ¿Por qué huyes ahora de mi presencia?
[14] Aunque arrastrarse por tierra y comer de ella es propio de la serpiente, quiso Dios que fuese en adelante una señal de oprobio e ignominia, que se considerase como pena. Pero debemos tener presente que esta maldición, aunque comprende a la serpiente material, se dirige especialmente a la serpiente infernal o espíritu maligno.
[15] He aquí la primera evidente promesa del Mesías, esto es, de un salvador. Es el primer anuncio de salvación o protoevangelio. Esta mujer es María y su descendiente es Cristo. El hijo de la mujer, Jesucristo, hijo de Dios, quebrantará tu cabeza.
[16] 1 Cor 14, 34.
[22] Es una ironía. Por las palabras uno de nosotros se entienden las tres divinas personas.
[22] Los dos pecaron y fueron expulsados. La expulsión del paraíso implica la pérdida de la inmortalidad y la felicidad terrenal.</p>
<br/>




</div>
