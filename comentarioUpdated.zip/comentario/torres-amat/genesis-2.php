<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 2</h2>
<p class="text-justify">[2] Eclo 20, 11; 31, 17; Deut 5, 14; Hebr 4, 4.
[3] Disponiendo que se dedicase este día al descanso y al culto del Creador, como después lo ordenó a su pueblo por medio de Moisés. Al sábado ha sucedido después el día del Señor o el domingo. Hebr 4, 3.
[4] Una primera narración de la creación la presenta como origen del cielo y de la tierra; otra tradición lo hace como ambiente donde es colocado el hombre.
[6] Un vapor según el texto hebreo, que condensado caía en forma de lluvia sobre la tierra.
[7] Es decir, creó el alma racional y la unió al cuerpo para darle vida y movimiento. Nuestra alma no es hija de la materia, sino obra del poder creador de Dios. 1 Cor 15, 45.
[9] La Escritura calla la especie del árbol, aunque lo llama del bien y del mal porque le hizo conocer al hombre el bien que había perdido y el mal en que se había precipitado desobedeciendo a Dios.
[12] Cerca de la Armenia está la Cólquida, tan celebrada por la calidad y abundancia de su oro. El bedelio es voz poco conocida, y puede significar la perla, o una especie de goma odorífera. Eclo 24, 35.
[15] Para que le cultivase. No quiere Dios que el hombre, aunque provisto de todo, pase el tiempo en la ociosidad.
[22] No sacó el Señor a la mujer de la cabeza del hombre ni tampoco de los pies, como para dar a entender que no debe ser la señora ni la esclava del hombre, sino la compañera.
[23] 1 Cor 11, 9.
[24] Una sola carne. Jesucristo se sirvió de estas palabras para probar a los fariseos la indisolubilidad del matrimonio. San Pablo enseña que la unión íntima y estrecha de Adán y Eva, que eran como dos almas en un solo cuerpo, significa la de Cristo y su Iglesia. Mat 19, 5; Mar 10, 7; Ef 5, 31; 1 Cor 7, 16.</p>
<br/>




</div>
