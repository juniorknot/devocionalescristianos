<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 49</h2>
<p class="text-justify">[4] El primogénito tenía una autoridad similar a la de un príncipe sobre sus hermanos, pero aquí vemos transferidos estos derechos a José en razón de la falta de Rubén. Deut 33, 6; Gen 27, 29; 35, 22; 1 Cro 5, 1.
[7] Gen 34, 25.
Jos 19, 1; 21, 1.
[8] De esta tribu nacieron David, Salomón y demás reyes, Zorobabel y finalmente Jesucristo.
9. 1 Cro 5, 2.
[10] En estas palabras hay una profecía del Mesías y una época infalible de su venida. Consta eso de la tradición, no sólo de la Iglesia cristiana, sino también de la Sinagoga. Así vemos que la tribu de Judá gozó siempre de especial preeminencia sobre las otras. Num 10, 14; - 11, 3; Jos 16. Después del retorno de la cautividad de Babilonia tuvo tal predominio, que dio nombre a toda la nación de los hebreos, pues los restos de las demás tribus se unieron e incorporaron en la de Judá. Sus magnates tuvieron la autoridad superior en el sanedrín, aunque limitada por los romamos. Así puede decirse siempre que el cetro, o autoridad suprema, quedó en Judá hasta que vino Jesucristo. Mat 2, 6; Juan 1, 45.
[11] El Mesías atará con el vínculo de la fe al pueblo gentil (su pollino), a su Iglesia (la viña) y al pueblo judío, (su asna por la costumbre al yugo) a su propia persona, que es la vid verdadera reuniendo en su Iglesia al pueblo gentil y al judío, lavados en la sangre de Cristo. Jn 15, 1.
[12] Expresiones que significan la soberana belleza de Jesucristo, especialmente después de la resurrección.
[13] Doscientos años antes de la conquista de la tierra de Canaán predice Jacob el lugar que le tocará en suerte a sus descendientes.
[14] Homero comparaba a uno de sus héroes con un asno, por su fortaleza y paciencia en los trabajos.
[18] La salud que nos traerá tu Enviado.
[22] Es decir, José crecerá y se multiplicará más y más. Jacob desahoga su afecto al bendecir a José, que es figura de Jesucristo en las penas y en las glorias. También profetiza el ardor con que las naciones irán en pos de Jesucristo. Sal 45 (44); 1. Cro 5, 1.
[27] Se describe el natural indómito y fiero de la tribu de Benjamín.
[30] Gen 23, 7.</p>
<br/>




</div>
