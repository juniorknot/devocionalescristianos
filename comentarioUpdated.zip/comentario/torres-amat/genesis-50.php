<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 50</h2>
<p class="text-justify">[2] La práctica de embalsamar fue muy común en Egipto.
[13] Hech 7, 16; Gén 23, 16.
[19] José quiere que sus hermanos, al acordarse de su delito, sólo consideren que la divina providencia permitió que lo vendieran, para ser después la salud de muchos pueblos, y de sus perseguidores. También en esto figura de Jesucristo.
[20] Gen 45, 5.
[22] Num 32, 39.
[23] Hebr 11, 12.
[24] Ex 13, 19; Jos 24, 32.</p>
<br/>




</div>
