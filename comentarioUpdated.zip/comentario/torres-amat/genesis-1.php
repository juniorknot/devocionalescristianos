<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 1</h2>
<p class="text-justify">[1] Dios es el creador de todas las cosas; es una verdad fundamental del orden religioso, de la cual se derivan nuestros deberes para con Dios. Sal 33 (32), 6; 136 (135), 5; Eclo 18, 1; Hech 14, 14.
[3] Según el texto hebreo se debería traducir Sea la luz. Y la luz fue; o también Haya luz. Y hubo luz.
[5] La palabra día tiene diferentes sentidos en casi todas las lenguas; por tanto, no se sabe si son días naturales o más bien ciertas épocas o períodos en los cuales Moisés divide el tiempo en que Dios creó, formó y adornó el universo. La narración presenta a Dios como un buen trabajador, que en una semana lleva a cabo la obra de la creación.
[7] Sal 136 (135), 6; 148, 4; Dan 3, 60.
[7] Por firmamento debe entenderse todo el espacio que hay desde la superficie de la tierra hasta las estrellas fijas, en una bóveda.
[10] Job 38; Sal 33 (32); 89 (88); 136 (135).
[14] Sal 136 (135), 7.
[26] En este modo de hablar han reconocido los santos padres y doctores el misterio de la unidad de Dios en la trinidad de personas. Había creado Dios el mundo para el hombre, ahora quiere crear al hombre para sí y le crea a imagen suya, con el alma incorpórea, inmortal, dotada de entendimiento, voluntad y libre albedrío. Puede oscurecerse esta imagen por el pecado, mas no borrarse.
[26] Gen 5,1; 9, 6; 1 Cor 11, 7; Col 3, 10.
[27] Sab 2, 23; Eclo 17, 1; Mat 19, 4.
[28] Gen 8, 17; 9, 1.
[28] Promete Dios al hombre y a la mujer la fecundidad, que es un don de Dios. 1 Cor.
[29] Gen 9, 3.
[31] Eclo 39, 21; Mar 7, 37.</p>
<br/>




</div>
