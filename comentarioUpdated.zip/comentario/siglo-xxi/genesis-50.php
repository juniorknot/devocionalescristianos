<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 50</h2>
<p class="text-justify">El embalsamamiento de Jacob muestra su alta posición alcanzada en Egipto. 10 La era de Atad estaba en algún lugar cercano a la frontera de Canaán, quizás cercano a Gaza o Jericó. Si el último, esto implicaría que la procesión funeraria tomó la misma ruta de los israelitas en el éxodo. 15-17 Se supone generalmente que los hermanos de José inventaron este último mensaje de Jacob, pero no podemos estar seguros.
G. J. Wenham</p>
<br/>
<p class="text-justify">El embalsamamiento de Jacob muestra su alta posición alcanzada en Egipto. 10 La era de Atad estaba en algún lugar cercano a la frontera de Canaán, quizás cercano a Gaza o Jericó. Si el último, esto implicaría que la procesión funeraria tomó la misma ruta de los israelitas en el éxodo. 15-17 Se supone generalmente que los hermanos de José inventaron este último mensaje de Jacob, pero no podemos estar seguros.
G. J. Wenham</p>
<br/>
<p class="text-justify">El embalsamamiento de Jacob muestra su alta posición alcanzada en Egipto. 10 La era de Atad estaba en algún lugar cercano a la frontera de Canaán, quizás cercano a Gaza o Jericó. Si el último, esto implicaría que la procesión funeraria tomó la misma ruta de los israelitas en el éxodo. 15-17 Se supone generalmente que los hermanos de José inventaron este último mensaje de Jacob, pero no podemos estar seguros.
G. J. Wenham</p>
<br/>




</div>
