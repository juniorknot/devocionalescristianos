<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 2</h2>
<p class="text-justify">El Eterno: El nombre יהוה (El Eterno) se forma al sobreponer las siguientes palabras ָהָיה (HAIÁ = fue), ׂהֶיה (HOVÉ = es) y ִיְהֶוה (IHIÉH = será), aludiendo al carácter eterno de Dios.</p>
<br/>
<p class="text-justify">Bedelio y ónice: Piedras preciosas.</p>
<br/>
<p class="text-justify">Jidékel y Perát: Según la tradición Jidékel es el Tigris y Perát es el Éufrates.</p>
<br/>
<p class="text-justify">Adám: El nombre ָאָדם (ADÁM) representa el origen del hombre: la tierra, que en hebreo es ֲאָדָמה (ADAMÁH).</p>
<br/>
<p class="text-justify">Costillas: Dios durmió al hombre para que no vea el corte en su carne (del cual fue creada la mujer) evitando así, que éste la desprecie.</p>
<br/>
<p class="text-justify">Isháh: La palabra hebrea para mujer ִאָֺשה (ISHÁH) alude también a su origen: el hombre, palabra que en hebreo es ִאיש (ISH).</p>
<br/>
<p class="text-justify">Serán una sola carne: El hombre y la mujer se convierten en una sola carne cuando alcanzan su máximo nivel de unión: al engendrar un hijo.</p>
<br/>




</div>
