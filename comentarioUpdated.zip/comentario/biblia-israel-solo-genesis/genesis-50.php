<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 50</h2>
<p class="text-justify">Embalsamaron a Israel: La costumbre egipcia de embalsamar a los difuntos es totalmente ajena a la visión de la Toráh. Según la ley, el cuerpo debe descomponerse naturalmente sin impedimento y debe volver a su origen como dice el versículo: “pues polvo eres, y al polvo volverás” (ver 3.19). Sin embargo, puesto que los egipcios velaban a sus muertos durante treinta días y que Iaäkób iba a ser sepultado en la tierra de Kenáän, Ioséf tomó la decisión de embalsamar a su padre para así evitar su pronta descomposición.</p>
<br/>
<p class="text-justify">Setenta días: Cuarenta días tomaba el proceso de embalsamamiento y treinta días el periodo de luto. El pueblo egipcio lloró a Iaäkób, pues la hambruna que habría de durar siete años terminó luego de dos años gracias a la bendición de éste.</p>
<br/>
<p class="text-justify">Abél-Mitzráim: De (ABÉL = Duelo) y (MITZRÁIM = Egipto).</p>
<br/>
<p class="text-justify">¿acaso estoy yo en lugar de Dios?: ¿Acaso soy yo el juez de la tierra para hacerles bien o mal?.</p>
<br/>
<p class="text-justify">E hizo jurar Ioséf: Aunque Ioséf había vivido gran parte de su vida en Egipto participando activamente como líder, su lazo con la tierra prometida nunca se debilitó. Los restos de Ioséf fueron llevados más tarde por los israelitas y fue sepultado en Shejém (verIehoshúa-Josué-24:32).&quot;&quot;&quot;&quot;&quot;&quot;&quot;</p>
<br/>




</div>
