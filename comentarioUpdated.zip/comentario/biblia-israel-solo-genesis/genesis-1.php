<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 1</h2>
<p class="text-justify">En el principio:La primera letra de la Toráhes la ב(Bet). La forma de esta letra -la cual posee una apertura delantera- nos enseña que sólo podemos entender desde la creación hacia adelante, antes de esto la mente humana no puede comprender.
Creó Dios:La Toráhcomienza con el relato de la creación para que la persona comprenda que Dios es dueño de todo lo que existe.</p>
<br/>
<p class="text-justify">Separe las aguas: Dios separó las aguas inferiores de las superiores.</p>
<br/>
<p class="text-justify">Firmamento: Se refiere a la atmósfera que circunda a la tierra.</p>
<br/>
<p class="text-justify">A imagen de Dios lo creó: De todas las criaturas, sólo el hombre está dotado –como su Creador- de razón y libre elección.</p>
<br/>




</div>
