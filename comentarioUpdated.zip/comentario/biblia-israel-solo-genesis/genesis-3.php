<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 3</h2>
<p class="text-justify">¿Dónde estás tú?: Desde los comienzos de la historia Dios nos pregunta constantemente: “¿Hacia dónde estás dirigiendo tu vida?”, “¿Hacia dónde estás corriendo?”, es decir, supérate y corrige tus acciones.</p>
<br/>
<p class="text-justify">Me engañó, y comí: Esta nunca debe ser nuestra actitud, pues debemos comportarnos como personas responsables y no culpar a otros por nuestros errores.</p>
<br/>
<p class="text-justify">Con el sudor de tu rostro: De este versículo aprendemos que el trabajo es una maldición. Por esta razón, debemos estar siempre conscientes de que éste corresponde sólo a un medio para sustentarnos y no un fin en sí mismo.</p>
<br/>
<p class="text-justify">El nombre de su mujer, Javáh: חַוָּה (JAVÁH) viene de la palabraחַיָּה (JAYÁH) que es vida, pues ella es la madre de la humanidad.</p>
<br/>
<p class="text-justify">Kerubím: Es un tipo de ángel. En este contexto se refiere a ángeles de destrucción.</p>
<br/>




</div>
