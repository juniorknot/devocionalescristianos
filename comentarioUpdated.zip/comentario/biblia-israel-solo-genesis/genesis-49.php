<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 49</h2>
<p class="text-justify">Acontecer en los días venideros: Iaäkób quiso revelarles el final de los días pero en ese momento la presencia divina se apartó de él, pues no era propio que sus hijos conociesen esta información. Entonces, aunque los había congregado para otro propósito, comenzó a darle las últimas palabras a sus hijos.</p>
<br/>
<p class="text-justify">Principio de mi vigor; principal en dignidad, principal en poder: Dado que eres mi primer hijo tenías el potencial de ser superior a tus hermanos en categoría y poder.</p>
<br/>
<p class="text-justify">Impulsivo como las aguas, no serás el principal: Reubén perdió su puesto como líder del pueblo de Israel –que le correspondía por ser primogénito- por su carácter impulsivo a la hora de tomar decisiones.</p>
<br/>
<p class="text-justify">En su conspiración no entre mi alma: “No quiero estar involucrado en nada que tenga que ver con la mentira” (ver comentario 34.30).
Han destrozado toros: Cuando atacaron Shejém mataron a personas y ganado.</p>
<br/>
<p class="text-justify">Maldito su furor: No maldijo a sus hijos sino a su furor.
Y los esparciré en Israel: Shimön y Leví van a ser separados, pues Leví no va a ser contado dentro de las tribus en la repartición de la tierra.</p>
<br/>
<p class="text-justify">Te alabarán tus hermanos: De tu descendencia saldrán los reyes de Israel.</p>
<br/>
<p class="text-justify">Cachorro de león, Iehudáh: En el momento de recibir la bendición, Iehudáh era un cachorro. Con el tiempo Iehudáh pasaría a ser un león, es decir, el rey de la nación.
De la presa te elevaste: Ascendiste de la mala acción de matar a Ioséf, aconsejándole a tus hermanos que no lo hiciesen.
Se encorvó... ¿Quién lo levantará?: Así será en el futuro: se instalará en el reinado y nadie podrá intimidarlo para levantarle su autoridad.</p>
<br/>
<p class="text-justify">Rojos del vino... blancos de la leche: Iaäkób profetizó que la tierra de Iehudáh será rica en viñedos y en pasturas para la cría de ganados los cuales producirán leche.</p>
<br/>
<p class="text-justify">Isajár, asno fuerte...: Ambos versículos aluden al rol de Isajár como sustentador de los tesoros espirituales de la Toráh.</p>
<br/>
<p class="text-justify">Dan vengará a su pueblo: Su descendiente Shimshón (Sansón) vengará el agravio de los pelishtím (filisteos) contra su pueblo (ver Shofetím – Jueces 13).</p>
<br/>
<p class="text-justify">Serpiente junto al camino: Tal como la serpiente muerde el talón del caballo sin siquiera tocar al jinete, sus descendientes utilizarán tácticas de guerrilla para tomar por sorpresa a sus enemigos.</p>
<br/>
<p class="text-justify">Tu salvación espero, oh El Eterno: Iaäkób visualizó la caída y muerte de Shimshón (Sansón) y rogó a El Eterno que redimiera al pueblo de Israel por algún otro medio.</p>
<br/>
<p class="text-justify">Deleites al rey: El territorio de Ásher producirá aceite de oliva y delicadezas apetecidas por los reyes.</p>
<br/>
<p class="text-justify">Naftalí, cierva mensajera: Sus descendientes serán ágiles en el cumplimiento de los mandamientos de El Eterno.</p>
<br/>
<p class="text-justify">Hijo agraciado: Ioséf era muy atractivo.</p>
<br/>
<p class="text-justify">Le causaron amargura: Tanto sus hermanos como la esposa de Pótifar.
Le odiaron los arqueros: Las calumnias son consideradas flechas y los arqueros son los difamadores.</p>
<br/>
<p class="text-justify">Mas su arco se mantuvo firme: Se mantuvo fuerte para resistir los ataques de sus enemigos.
Con oro: En referencia al anillo que le entregó el Faraón al coronarlo virrey.
Pastor de la Roca de Israel: Siendo virrey de Egipto se convirtió en el pastor, sustentador de la casa de Iaäkób.</p>
<br/>
<p class="text-justify">Lobo predador: Alude a la destreza y valentía de sus descendientes en batalla.</p>
<br/>
<p class="text-justify">Fue reunido con sus padres: Ver comentario 25.8.</p>
<br/>




</div>
