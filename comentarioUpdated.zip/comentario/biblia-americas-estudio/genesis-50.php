<div id="close_comentario"><span>×</span></div><div class="small-12 columns">
<h2 class="text-center">Génesis 50</h2>
<p class="text-justify">los médicos embalsamaron a Israel. Era costumbre en el antiguo Egipto momificar los cadáveres de la realeza y la nobleza. Se les removían las vísceras y las guardaban en jarras. Luego deshidrataban el cuerpo con natrón, lo untaban con especias y ungüentos y lo envolvían en lienzos para la sepultura. En el caso de Jacob, y más tarde en el de José, el cadáver se embalsamaría para que fuera posible llevarlo a Canaán.</p>
<br/>
<p class="text-justify">la era de Atad. El grano era generalmente trillado en la parte plana de un lugar elevado. Golpeaban la mies para separar el grano de la paja y luego la aventaban para que el viento se llevara la paja y el grano cayera en alguna vasija. Esta era estaba probablemente en una región bien conocida al este del Jordán, cuya topografía la hizo apropiada para la trilla.</p>
<br/>
<p class="text-justify">pensasteis hacerme mal…Dios lo tornó en bien. Esta es una clara expresión de cómo entendía José la providencia soberana de Dios. Como ha ocurrido a lo largo de toda la narración, está claro que la promesa de Dios se cumplirá. El esfuerzo del hombre no afectaría ni estorbaría esa promesa. Dios cambia aún las malas intenciones y las usa para cumplir sus propósitos irrevocables.
se preservara la vida de mucha gente. Esto bien puede incluir más personas que las de la familia de Jacob. Si así es, es un ejemplo más de la manera en que todas las familias de la tierra serán benditas (12:3) mediante los descendientes de Israel.</p>
<br/>
<p class="text-justify">llevaréis mis huesos de aquí. La fe de José en la promesa de Dios a Abraham se refleja en sus instrucciones para que lleven su cuerpo a Canaán para ser sepultado cuando Dios lleve a los israelitas a la tierra de la promesa (15:13-16).</p>
<br/>
<p class="text-justify">murió José. Génesis empieza con el relato de la creación del hombre y de la mujer por Dios a su imagen y semejanza colocándolos en el Edén. Pero el orgullo rebelde del hombre le trajo separación, sufrimiento y muerte. La respuesta misericordiosa de Dios a la rebelión y el pecado del hombre ofrece esperanza mediante el pacto de la promesa. Génesis termina con un ataúd en Egipto, no como el fin del relato, sino como preludio a la gloriosa redención que se desarrolla en el libro de Exodo cuando Dios libra a su pueblo de la esclavitud en Egipto en preparación para llevarlo a la tierra que Dios había prometido a Abraham.</p>
<br/>




</div>
